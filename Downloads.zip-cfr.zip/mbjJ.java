/*
 * Decompiled with CFR 0.152.
 */
/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class mbjJ
extends Enum<mbjJ> {
    private static long CRACKME_8bf09b01_13b1_47f4_bf48_798917912588_6061754d = 8292294963678554338L;
    private static String[] CRACKME_BITCH;
    public static final /* enum */ mbjJ qHj\u017c;
    public static final /* enum */ mbjJ OxEB;
    private static final /* synthetic */ mbjJ[] AsPC;
    public static final /* enum */ mbjJ W\u01443n;

    public static mbjJ nP_Vb9VWWmkn8Fkn(String string) {
        if (CRACKME_8bf09b01_13b1_47f4_bf48_798917912588_6061754d == -464523932854826556L - -3417322648286259502L) {
            if ((0xB07AB1C4 ^ 0xD0F68D8A ^ (0xB46EDD8D ^ 0xCB912272)) != 0) {
                int n = -6767270214745385520L == -6767270214745385519L ? 1878833856 : 0x38901CE0 ^ 0x38901CE1;
            }
        } else {
            int cfr_ignored_1 = 0x5EECD31E ^ 0x5EECD31E;
        }
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = CRACKME_8bf09b01_13b1_47f4_bf48_798917912588_6061754d - (2955433782705125754L == 2955433782705125755L ? 5485608803951756217L : -8376742352888131269L - 5253913288591980120L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0x2946810D ^ 0x2946810C)) {
                String CRACKME_5b8dff03_14b8_4862_b598_ddac3007f008226a1542;
                return Enum.valueOf(mbjJ.class, CRACKME_5b8dff03_14b8_4862_b598_ddac3007f008226a1542);
            }
            l2 = 0x81A51916 ^ 0x1C20AF5C;
        }
    }

    private static /* synthetic */ mbjJ[] fkSHuYRoieREskAJ() {
        mbjJ[] mbjJArray;
        block11: {
            int n;
            block10: {
                if (CRACKME_8bf09b01_13b1_47f4_bf48_798917912588_6061754d == (0xFF07ADB65F3FD086L ^ 0xA65D2B7F6B2F311L)) {
                    if ((0xC00D55C3 ^ 0xD2316D01 ^ 504487133 - -1642996514) != 0) {
                        int cfr_ignored_2 = 0xC2255474 ^ 0xC2255475;
                    }
                } else {
                    int cfr_ignored_3 = 0xE964D0BE ^ 0xE964D0BE;
                }
                mbjJArray = new mbjJ[-8660836596431940117L == -8660836596431940116L ? 431541264 : 0xAE6364CB ^ 0xAE6364C8];
                int cfr_ignored_4 = 0x30A84F0F ^ 0xD244D48F;
                mbjJArray[845607509921564923L == 845607509921564924L ? -1428190646 : 0x74086625 ^ 0x74086625] = OxEB;
                while (true) {
                    long l;
                    long l2;
                    if ((l2 = (l = CRACKME_8bf09b01_13b1_47f4_bf48_798917912588_6061754d - (-4918767452598089923L == -4918767452598089922L ? -1440462158779027838L : 2101181945876051141L - 8062895085274934234L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                        continue;
                    }
                    if (l2 == (0xDD6B8151 ^ 0xDD6B8150)) {
                        mbjJArray[0x9A319009 ^ 0x9A319008] = W\u01443n;
                        int cfr_ignored_5 = -749265876 >>> "\u0000\u0000".length();
                        if (-6839461737669865847L == -6839461737669865846L) {
                            break;
                        }
                        break block10;
                    }
                    l2 = -1814823996 - 322698193;
                }
                n = 643821134;
                break block11;
            }
            n = 0xB0399267 ^ 0xB0399265;
        }
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = CRACKME_8bf09b01_13b1_47f4_bf48_798917912588_6061754d - (0xCE68A56456090998L ^ 0x67A90A91599906E1L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l3 == (0x2522AEC3 ^ 0x2522AEC2)) {
                mbjJArray[n] = qHj\u017c;
                return mbjJArray;
            }
            l3 = 1325347571 - -1519429559;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block34: {
            block31: {
                block33: {
                    block30: {
                        block32: {
                            block29: {
                                mbjJ.CRACKME_BITCH = new String[13];
                                mbjJ.CRACKME_BITCH[0] = "\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u28e0\u28e4\u28e4\u28e4\u28e4\u28e4\u28c4\u2840\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800";
                                mbjJ.CRACKME_BITCH[1] = "\u2800\u2800\u2800\u2800\u2800\u28b0\u287f\u280b\u2801\u2800\u2800\u2808\u2809\u2819\u283b\u28f7\u28c4\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800";
                                mbjJ.CRACKME_BITCH[2] = "\u2800\u2800\u2800\u2800\u2880\u28ff\u2807\u2800\u2880\u28f4\u28f6\u287e\u283f\u283f\u283f\u28bf\u28ff\u28e6\u2840\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800";
                                mbjJ.CRACKME_BITCH[3] = "\u2800\u2800\u28c0\u28c0\u28f8\u287f\u2800\u2800\u28b8\u28ff\u28c7\u2800\u2800\u2800\u2800\u2800\u2800\u2819\u28f7\u2840\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800";
                                mbjJ.CRACKME_BITCH[4] = "\u2800\u28fe\u285f\u281b\u28ff\u2847\u2800\u2800\u28b8\u28ff\u28ff\u28f7\u28e4\u28e4\u28e4\u28e4\u28f6\u28f6\u28ff\u2807\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u28c0\u2800\u2800";
                                mbjJ.CRACKME_BITCH[5] = "\u2880\u28ff\u2800\u2880\u28ff\u2847\u2800\u2800\u2800\u283b\u28bf\u28ff\u28ff\u28ff\u28ff\u28ff\u283f\u28ff\u284f\u2800\u2800\u2800\u2800\u28b4\u28f6\u28f6\u28ff\u28ff\u28ff\u28c6";
                                mbjJ.CRACKME_BITCH[6] = "\u28b8\u28ff\u2800\u28b8\u28ff\u2847\u2800\u2800\u2800\u2800\u2800\u2808\u2809\u2801\u2800\u2800\u2800\u28ff\u2847\u28c0\u28e0\u28f4\u28fe\u28ee\u28dd\u283f\u283f\u283f\u28fb\u285f";
                                mbjJ.CRACKME_BITCH[7] = "\u28b8\u28ff\u2800\u2818\u28ff\u2847\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u28e0\u28f6\u28fe\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u287f\u2801\u2809\u2800";
                                mbjJ.CRACKME_BITCH[8] = "\u2838\u28ff\u2800\u2800\u28ff\u2847\u2800\u2800\u2800\u2800\u2800\u28e0\u28fe\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u287f\u281f\u2809\u2800\u2800\u2800\u2800";
                                mbjJ.CRACKME_BITCH[9] = "\u2800\u283b\u28f7\u28f6\u28ff\u28c7\u2800\u2800\u2800\u28a0\u28fc\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28db\u28db\u28fb\u2809\u2801\u2800\u2800\u2800\u2800\u2800\u2800\u2800";
                                mbjJ.CRACKME_BITCH[10] = "\u2800\u2800\u2800\u2800\u28b8\u28ff\u2800\u2800\u2800\u28b8\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u2847\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800";
                                mbjJ.CRACKME_BITCH[11] = "\u2800\u2800\u2800\u2800\u28b8\u28ff\u28c0\u28c0\u28c0\u28fc\u287f\u28bf\u28ff\u28ff\u28ff\u28ff\u28ff\u287f\u28ff\u28ff\u287f\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800";
                                mbjJ.CRACKME_BITCH[12] = "\u2800\u2800\u2800\u2800\u2800\u2819\u281b\u281b\u281b\u280b\u2801\u2800\u2819\u283b\u283f\u281f\u280b\u2811\u281b\u280b\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800";
                                if (mbjJ.CRACKME_8bf09b01_13b1_47f4_bf48_798917912588_6061754d == -5810474447421542642L - -750647752066273568L) {
                                    if ((551405347 - 1434771951 ^ 609156833 - -1538326814) != 0) {
                                        2099569789 ^ 2099569788;
                                    }
                                } else {
                                    v0 = -8399016274469075196L == -8399016274469075195L ? -2015099082 : 2067648469 ^ 2067648469;
                                }
                                var1 = new byte[-2079712467 ^ -2079712469];
                                var1[1728065332 ^ 1728065332] = -5872089836765121339L == -5872089836765121338L ? 163528323 : -1010963290 ^ -1010963224;
                                var1[-118347245 ^ -118347247] = 1014435559 ^ 1014435509;
                                var1[964267424 ^ 964267425] = -734934535 ^ -734934602;
                                var1[792457866 ^ 792457871] = -1909643628 ^ -1909643560;
                                var1[1013609469 ^ 1013609465] = 778252697 ^ 778252760;
                                var1[2107652522 ^ 2107652521] = -1221736278 ^ -1221736217;
                                v1 = new String(var1, "UTF-8");
                                v2 = mbjJ.CRACKME_8bf09b01_13b1_47f4_bf48_798917912588_6061754d;
                                if (true) ** GOTO lbl36
                                block12: while (true) {
                                    v2 = v3 / (-856233952586626978L == -856233952586626977L ? 2700693079661243459L : 829015259835380684L - 1550694298482011822L);
lbl36:
                                    // 2 sources

                                    switch ((int)v2) {
                                        case -1766017882: {
                                            v3 = -856269143995043759L ^ 6922807044465807904L;
                                            continue block12;
                                        }
                                        case -1736548423: {
                                            v3 = 3638956540322079542L ^ 2207688496968465529L;
                                            continue block12;
                                        }
                                        case -1026414366: {
                                            break block12;
                                        }
                                        case -717975677: {
                                            v3 = 7094157965652390861L - 8163213115822545025L;
                                            continue block12;
                                        }
                                    }
                                    break;
                                }
                                v4 = new mbjJ();
                                while (true) {
                                    if ((v5 = (cfr_temp_0 = mbjJ.CRACKME_8bf09b01_13b1_47f4_bf48_798917912588_6061754d - (4604481783362365766L == 4604481783362365767L ? 7724998212184169226L : 5622966702729021063L ^ 6072289767015276785L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                                    if (v5 == (-2012195388 ^ -2012195387)) break;
                                    v5 = -74667564 - -1336726885;
                                }
                                mbjJ.OxEB = v4;
                                while (true) {
                                    if ((v6 = (cfr_temp_1 = mbjJ.CRACKME_8bf09b01_13b1_47f4_bf48_798917912588_6061754d - (-3544388142738720202L ^ 3744092264106559660L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                                    if (v6 == (-1575544291917942172L == -1575544291917942171L ? 2042220842 : 174873143 ^ 174873142)) {
                                        var1 = new byte[-1921122437 ^ -1921122440];
                                        if (-5368385607379455199L == -5368385607379455198L) {
                                            break;
                                        }
                                        break block29;
                                    }
                                    v6 = 872093997 - 1877940729;
                                }
                                v7 = -753570691;
                                break block32;
                            }
                            v7 = 1778857004 ^ 1778857006;
                        }
                        var1[v7] = 1885054080 ^ 1885054167;
                        var1[87084744 ^ 87084745] = -903900119 ^ -903900058;
                        var1[-1878030067 ^ -1878030067] = -6074839478047282952L == -6074839478047282951L ? 1232713316 : -678235707 ^ -678235767;
                        v8 = new String(var1, "UTF-8");
                        v9 = 2020011723011463733L == 2020011723011463734L ? 1759999794 : -1445989663 ^ -1445989664;
                        v10 = mbjJ.CRACKME_8bf09b01_13b1_47f4_bf48_798917912588_6061754d;
                        if (true) ** GOTO lbl78
                        block15: while (true) {
                            v10 = v11 / (-7116154188810072236L >>> "\u0000\u0000".length());
lbl78:
                            // 2 sources

                            switch ((int)v10) {
                                case -1026414366: {
                                    break block15;
                                }
                                case 730452446: {
                                    v11 = -8607254663542464204L - 7784345732341896660L;
                                    continue block15;
                                }
                                case 851326151: {
                                    v11 = 3214528287912045709L ^ 7305154174658895885L;
                                    continue block15;
                                }
                                case 1995241422: {
                                    v11 = 6021103767612597728L ^ -5748840438234461270L;
                                    continue block15;
                                }
                            }
                            break;
                        }
                        v12 = new mbjJ();
                        while (true) {
                            if ((v13 = (cfr_temp_2 = mbjJ.CRACKME_8bf09b01_13b1_47f4_bf48_798917912588_6061754d - (8909954890705033275L ^ 1124109593878117070L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                            if (v13 == (-4231608478732929751L == -4231608478732929750L ? 51527092 : -445732850 - -445732849)) {
                                mbjJ.W\u01443n = v12;
                                var1 = new byte[1614190102 ^ 1614190098];
                                if (-6804340895022235005L == -6804340895022235004L) {
                                    break;
                                }
                                break block30;
                            }
                            v13 = 588109113 - 2095038455;
                        }
                        v14 = -1528005133;
                        break block33;
                    }
                    v14 = 1898655926 ^ 1898655927;
                }
                var1[v14] = 3484032007948746733L == 3484032007948746734L ? -2004927561 : -1683147653 ^ -1683147724;
                var1[8258539399217711051L == 8258539399217711052L ? 142772166 : 2021461882 ^ 2021461881] = -1400280579 ^ -1400280648;
                var1[6386615479008414990L == 6386615479008414991L ? 1181538004 : -1867716037 ^ -1867716039] = -1159928116 ^ -1159928190;
                var1[1280296786 ^ 1280296786] = -555760898 ^ -555760976;
                v15 = new String(var1, "UTF-8");
                while (true) {
                    if ((v16 = (cfr_temp_3 = mbjJ.CRACKME_8bf09b01_13b1_47f4_bf48_798917912588_6061754d - (8565160294251655394L ^ -7664042296212245440L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                    if (v16 == (1505761746 ^ 1505761747)) {
                        v17 = new mbjJ();
                        if (-5187488425138217841L == -5187488425138217840L) {
                            break;
                        }
                        break block31;
                    }
                    v16 = 499767540 >>> "\u0000\u0000".length();
                }
                v18 = 2135398697;
                break block34;
            }
            v18 = 2031041726 ^ -1698727922;
        }
        mbjJ.qHj\u017c = v17;
        while (true) {
            if ((v19 = (cfr_temp_4 = mbjJ.CRACKME_8bf09b01_13b1_47f4_bf48_798917912588_6061754d - (-1437165944832009461L - -3983736669396510844L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v19 == (-118660797 ^ -118660798)) {
                mbjJ.AsPC = mbjJ.fkSHuYRoieREskAJ();
                return;
            }
            v19 = 80351920 >>> "\u0000\u0000".length();
        }
    }

    public static mbjJ[] 156HwHs17OrBu7q8() {
        if (CRACKME_8bf09b01_13b1_47f4_bf48_798917912588_6061754d == (5291806747552756199L == 5291806747552756200L ? -8179221730336082290L : 0xD489F4D59EBEC3E4L ^ 0xAF75D7BCE7A328CAL)) {
            if ((0xB073A81E ^ 0x2E97799C ^ (0xFA4C56B ^ 0x705B3A94)) != 0) {
                int n = 5666201748468468800L == 5666201748468468801L ? -1019868953 : 0x35E5A480 ^ 0x35E5A481;
            }
        } else {
            int cfr_ignored_1 = 0x63F0E4E9 ^ 0x63F0E4E9;
        }
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = CRACKME_8bf09b01_13b1_47f4_bf48_798917912588_6061754d - (-720659698149176764L - 2673510290404784469L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0xFCFC5FD1 ^ 0xFCFC5FD0)) {
                int cfr_ignored_2 = 0x5EE535D1 ^ 0x73844F80;
                return (mbjJ[])AsPC.clone();
            }
            l2 = 0x3E65EBA5 ^ 0x820C2D0E;
        }
    }

    private mbjJ() {
        mbjJ CRACKME_87bd534f_aa93_44c9_9dac_4d0c6a42269856cc1b53;
        if (CRACKME_8bf09b01_13b1_47f4_bf48_798917912588_6061754d == 2209280090607214387L - 8015042930988669058L) {
            if (((-8945450649674023673L == -8945450649674023672L ? -1217092952 : 0xAC5578B6 ^ 0x3D086752) ^ (0x20093938 ^ 0x5FF6C6C7)) != 0) {
                int n2 = 6507890298640195239L == 6507890298640195240L ? 1154709969 : 0xFEF20AFE ^ 0xFEF20AFF;
            }
        } else {
            int cfr_ignored_0 = 0xDB5FA17D ^ 0xDB5FA17D;
        }
    }
}
