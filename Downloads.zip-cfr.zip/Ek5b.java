/*
 * Decompiled with CFR 0.152.
 */
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(value={ElementType.FIELD, ElementType.TYPE})
@Retention(value=RetentionPolicy.RUNTIME)
@Documented
public @interface Ek5b {
    private static String[] CRACKME_BITCH = new String[15];

    static {
        Ek5b.CRACKME_BITCH[0] = "\u2282_\u30fd";
        Ek5b.CRACKME_BITCH[1] = "\u3000 \uff3c\uff3c\u3000\u3000\u3000";
        Ek5b.CRACKME_BITCH[2] = "\u3000\u3000 \uff3c( \u0361\u00b0 \u035c\u0296 \u0361\u00b0)\u3000\u3000\u3000";
        Ek5b.CRACKME_BITCH[3] = "\u3000\u3000\u3000 >\u3000\u2312\u30fd\u3000\u3000\u3000";
        Ek5b.CRACKME_BITCH[4] = "\u3000\u3000\u3000/ \u3000 \u3078\uff3c\u3000\u3000\u3000";
        Ek5b.CRACKME_BITCH[5] = "\u3000\u3000 /\u3000\u3000/\u3000\uff3c\uff3c\u3000\u3000\u3000";
        Ek5b.CRACKME_BITCH[6] = "\u3000\u3000 \uff9a\u3000\u30ce\u3000\u3000 \u30fd_\u3064\u3000\u3000\u3000";
        Ek5b.CRACKME_BITCH[7] = "\u3000\u3000/\u3000/\u3000\u3000\u3000";
        Ek5b.CRACKME_BITCH[8] = "\u3000 /\u3000/|\u3000\u3000\u3000";
        Ek5b.CRACKME_BITCH[9] = "\u3000(\u3000(\u30fd\u3000\u3000\u3000";
        Ek5b.CRACKME_BITCH[10] = "\u3000|\u3000|\u3001\uff3c\u3000\u3000\u3000";
        Ek5b.CRACKME_BITCH[11] = "\u3000| \u4e3f \uff3c \u2312)\u3000\u3000\u3000";
        Ek5b.CRACKME_BITCH[12] = "\u3000| |\u3000\u3000) /\u3000\u3000\u3000";
        Ek5b.CRACKME_BITCH[13] = "\u30ce )\u3000\u3000L\uff89\u3000\u3000\u3000";
        Ek5b.CRACKME_BITCH[14] = "(_\uff0f\u3000\u3000\u3000\u3000\u3000\u3000";
    }

    public double value();
}
