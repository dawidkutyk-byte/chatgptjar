/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  0QZ8
 *  2Jq\u0142
 *  5fEW
 *  7Tz7
 *  8A7T
 *  HNBz
 *  HOxR
 *  Hh0c
 *  JxER
 *  Z1X8
 *  cEsW
 *  org.apache.http.client.HttpClient
 *  org.bukkit.Bukkit
 *  org.bukkit.Server
 *  org.bukkit.command.ConsoleCommandSender
 *  org.bukkit.plugin.Plugin
 *  pcyE
 *  zNb\u015b
 *  \u00f3\u0118CE
 */
import java.lang.invoke.LambdaMetafactory;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import org.apache.http.client.HttpClient;
import org.bukkit.Bukkit;
import org.bukkit.Server;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.plugin.Plugin;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class \u0141m1\u0179 {
    private final Set<String> \u015aLd6;
    private final Z1X8 VF\u0179s;
    private final Queue<5fEW> 3gxv;
    private final 7Tz7 QeXl;
    private static String[] CRACKME_BITCH = new String[10];
    private final HNBz \u0105X\u017cA;
    private final \u00f3\u0118CE 7\u017bQH;
    private final pcyE 8t\u015be;
    private final cEsW h\u017abt;
    private final 2Jq\u0142 \u015b9bF;
    private static long CRACKME_a0930d8f_bf6d_4063_826b_498129741f8e_1da8a427 = 5626309329033942000L;
    private final Hh0c ZK\u0118B;
    public static int \u00f3p7V;
    private final 8A7T \u00d3OVs;
    private String B\u0106HZ;
    public static int o1AY;
    private final HOxR XSns;
    private final JxER \u0104Dp0;
    private static HttpClient ClS9;

    /*
     * Exception decompiling
     */
    public \u0141m1\u0179() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 105[SWITCH]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doClass(Driver.java:84)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:78)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompile(CFRDecompiler.java:89)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompileToZip(CFRDecompiler.java:133)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.decompileSaveAll(ResourceDecompiling.java:261)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.lambda$decompileSaveAll$0(ResourceDecompiling.java:111)
         *     at java.base/java.lang.Thread.run(Thread.java:1575)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    static /* synthetic */ Set pzSgepYZili1jWZb(\u0141m1\u0179 \u0142m1\u0179) {
        if (CRACKME_a0930d8f_bf6d_4063_826b_498129741f8e_1da8a427 == (0x9DF00E7ABE8E5361L ^ 0xA2D5517F7EB361C0L)) {
            if ((-2501386 - 1628235447 ^ (6665999771670101205L == 6665999771670101206L ? 492386350 : 0x897485B3 ^ 0xF68B7A4C)) != 0) {
                int cfr_ignored_1 = 0xF05FB3C8 ^ 0xF05FB3C9;
            }
        } else {
            int n = 3885486774319403825L == 3885486774319403826L ? 2080366189 : 0xADA0075A ^ 0xADA0075A;
        }
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = CRACKME_a0930d8f_bf6d_4063_826b_498129741f8e_1da8a427 - (0x660BE4BF5A77B7D2L ^ 0xD6AD0ED3D856D70DL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (-8090209989509974191L == -8090209989509974190L ? -2072890589 : 0xCA1CAAA9 ^ 0xCA1CAAA8)) {
                \u0141m1\u0179 CRACKME_1408f852_a80b_450d_b57a_65cf020fd694ef48b745;
                return CRACKME_1408f852_a80b_450d_b57a_65cf020fd694ef48b745.\u015aLd6;
            }
            l2 = 0xF6A6A1E1 ^ 0x33CCC520;
        }
    }

    static /* synthetic */ Queue YlYBzK0wxzR3V8VQ(\u0141m1\u0179 \u0142m1\u0179) {
        \u0141m1\u0179 CRACKME_67a5c7c5_1542_483f_a7c1_8cf56ad23b8976252bd0;
        if (CRACKME_a0930d8f_bf6d_4063_826b_498129741f8e_1da8a427 == -8524553987825333708L >>> "\u0000\u0000".length()) {
            if ((1967489097 - 963643797 ^ (0x8B2E5235 ^ 0xF4D1ADCA)) != 0) {
                int cfr_ignored_0 = 0x67E5F74A ^ 0x67E5F74B;
            }
        } else {
            int cfr_ignored_1 = 0xE57A4F1F ^ 0xE57A4F1F;
        }
        int cfr_ignored_2 = 0xD24F4C11 ^ 0xC158A668;
        int n = -4329380571144006236L == -4329380571144006235L ? 1930226813 : 0xA09BE63E ^ 0x87626F03;
        long l = CRACKME_a0930d8f_bf6d_4063_826b_498129741f8e_1da8a427;
        block4: while (true) {
            switch ((int)l) {
                case -1108950347: {
                    l = (495623851846299369L - 914315277421486412L) / (0x1B429B567B5FFDB7L ^ 0x26D8DC8C4D7BA45BL);
                    continue block4;
                }
                case 2039010288: {
                    break block4;
                }
            }
            break;
        }
        return CRACKME_67a5c7c5_1542_483f_a7c1_8cf56ad23b8976252bd0.3gxv;
    }

    /*
     * Exception decompiling
     */
    private void fB9oUSAVoe2U6_yk(String var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 10[SWITCH]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doClass(Driver.java:84)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:78)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompile(CFRDecompiler.java:89)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompileToZip(CFRDecompiler.java:133)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.decompileSaveAll(ResourceDecompiling.java:261)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.lambda$decompileSaveAll$0(ResourceDecompiling.java:111)
         *     at java.base/java.lang.Thread.run(Thread.java:1575)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Unable to fully structure code
     */
    static {
        \u0141m1\u0179.CRACKME_BITCH[0] = "....................../\u00b4\u00af/)";
        \u0141m1\u0179.CRACKME_BITCH[1] = "....................,/\u00af../....................";
        \u0141m1\u0179.CRACKME_BITCH[2] = ".................../..../....................";
        \u0141m1\u0179.CRACKME_BITCH[3] = "............./\u00b4\u00af/'...'/\u00b4\u00af\u00af`\u00b7\u00b8....................";
        \u0141m1\u0179.CRACKME_BITCH[4] = "........../'/.../..../......./\u00a8\u00af\\....................";
        \u0141m1\u0179.CRACKME_BITCH[5] = "........('(...\u00b4...\u00b4.... \u00af~/'...')....................";
        \u0141m1\u0179.CRACKME_BITCH[6] = ".........\\.................'...../....................";
        \u0141m1\u0179.CRACKME_BITCH[7] = "..........''...\\.......... _.\u00b7\u00b4....................";
        \u0141m1\u0179.CRACKME_BITCH[8] = "............\\..............(....................";
        \u0141m1\u0179.CRACKME_BITCH[9] = "..............\\.............\\.......................";
        if (\u0141m1\u0179.CRACKME_a0930d8f_bf6d_4063_826b_498129741f8e_1da8a427 == (7841910564066412077L ^ -4860834097808746920L)) {
            v0 = 1209168277 ^ 1209168276;
        } else {
            v1 = -340654281 ^ -340654281;
        }
        v2 = 48240711 ^ 48240711;
        while (true) {
            block9: {
                if ((v3 = (cfr_temp_0 = \u0141m1\u0179.CRACKME_a0930d8f_bf6d_4063_826b_498129741f8e_1da8a427 - (9013160819585223501L - -4586119865380841055L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (v3 != (-1721355594 ^ -1721355593)) break block9;
                \u0141m1\u0179.o1AY = v2;
                v4 = 1163541234 ^ 1163541234;
                v5 = \u0141m1\u0179.CRACKME_a0930d8f_bf6d_4063_826b_498129741f8e_1da8a427;
                if (true) ** GOTO lbl41
            }
            v3 = 577989354 ^ -1850452370;
        }
        block5: while (true) {
            v5 = (2806322011008795893L ^ -4348772927909301543L) / v6;
lbl41:
            // 2 sources

            switch ((int)v5) {
                case 41832019: {
                    v6 = 8602321223891180412L - -7751614506499499999L;
                    continue block5;
                }
                case 2039010288: {
                    break block5;
                }
            }
            break;
        }
        \u0141m1\u0179.\u00f3p7V = v4;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     */
    static /* synthetic */ 7Tz7 A3U6SOPDfLK5uOOn(\u0141m1\u0179 \u0142m1\u0179) {
        \u0141m1\u0179 CRACKME_194d8aa9_9be8_433a_a401_633c05f34e03f8a16297;
        if (CRACKME_a0930d8f_bf6d_4063_826b_498129741f8e_1da8a427 == (0xA0C8C2F6F20B7E66L ^ 0x5369A14EA02EB1D0L)) {
            int n = 0xC648EC99 ^ 0xB9B71366;
            if ((0x1CF21046 ^ 0x6D595302 ^ n) != 0) {
                int cfr_ignored_1 = 0x856A1725 ^ 0x856A1724;
            }
        } else {
            int n = 0x81AA047F ^ 0x81AA047F;
        }
        long l = CRACKME_a0930d8f_bf6d_4063_826b_498129741f8e_1da8a427;
        boolean bl = true;
        block4: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = (-282930917453387527L - -7426466016726068650L) / l2;
            }
            switch ((int)l) {
                case -1922850300: {
                    l2 = 0x5ECF1B64CFA3BFF3L ^ 0x8E0B93573C01E731L;
                    continue block4;
                }
                case 2039010288: {
                    return CRACKME_194d8aa9_9be8_433a_a401_633c05f34e03f8a16297.QeXl;
                }
            }
            break;
        }
        return CRACKME_194d8aa9_9be8_433a_a401_633c05f34e03f8a16297.QeXl;
    }

    /*
     * WARNING - void declaration
     */
    static /* synthetic */ void dPGNOM_gKNhxnPYn(\u0141m1\u0179 \u0142m1\u0179, String string) {
        void CRACKME_d81aaa9a_6ae6_4c93_a09c_6f83d98d3a1869f0b2c5;
        \u0141m1\u0179 CRACKME_d81aaa9a_6ae6_4c93_a09c_6f83d98d3a18c7642c23;
        if (CRACKME_a0930d8f_bf6d_4063_826b_498129741f8e_1da8a427 == (640878547952627896L == 640878547952627897L ? -8900332655286422367L : 0x1B8132E9F61AA74EL ^ 0x23D8AD5B0FB28717L)) {
            if ((1191902088 >>> "\u0000\u0000".length() ^ (6076712555206298337L == 6076712555206298338L ? 1429290225 : -1616443801 - 531039848)) != 0) {
                int cfr_ignored_0 = 0x13A51FAA ^ 0x13A51FAB;
            }
        } else {
            int cfr_ignored_1 = 0xC4B04F7E ^ 0xC4B04F7E;
        }
        CRACKME_d81aaa9a_6ae6_4c93_a09c_6f83d98d3a18c7642c23.fB9oUSAVoe2U6_yk((String)CRACKME_d81aaa9a_6ae6_4c93_a09c_6f83d98d3a1869f0b2c5);
    }

    /*
     * Unable to fully structure code
     */
    private void 1I7DJVUQCIum5Xc6(Map<String, Object> var1_1, String var2_2) {
        block39: {
            block38: {
                block37: {
                    block36: {
                        if (\u0141m1\u0179.CRACKME_a0930d8f_bf6d_4063_826b_498129741f8e_1da8a427 == (2698890790470226149L == 2698890790470226150L ? -5259994529673250455L : 3004234426158857269L ^ 7013361124793018780L)) {
                            if (((1081335851927260437L == 1081335851927260438L ? -1777325979 : -2099677611 ^ 1367166964) ^ (-8931588655214977258L == -8931588655214977257L ? -1657335874 : 1722365605 ^ 425118042)) != 0) {
                                v0 = -5642834023202352572L == -5642834023202352571L ? 627547550 : 346424499 ^ 346424498;
                            }
                        } else {
                            v1 = 925547043226049179L == 925547043226049180L ? -1549592834 : 872635824 ^ 872635824;
                        }
                        v2 = \u0141m1\u0179.CRACKME_a0930d8f_bf6d_4063_826b_498129741f8e_1da8a427;
                        if (true) ** GOTO lbl11
                        block20: while (true) {
                            v2 = v3 / (2168315239537666070L ^ -9199811730832703372L);
lbl11:
                            // 2 sources

                            switch ((int)v2) {
                                case -494881865: {
                                    v3 = 8504676825928787065L - 8029753984990811156L;
                                    continue block20;
                                }
                                case 403762057: {
                                    v3 = -233335963368414545L ^ -7381924437333964835L;
                                    continue block20;
                                }
                                case 2039010288: {
                                    break block20;
                                }
                            }
                            break;
                        }
                        var3_3 = (Runnable)LambdaMetafactory.metafactory(null, null, null, ()V, awMls1rEnAqMahNt(java.util.Map java.lang.String ), ()V)((\u0141m1\u0179)CRACKME_0994bcc4_61bb_4761_8f2f_560fcb3b2fa9c5149413, (Map)CRACKME_0994bcc4_61bb_4761_8f2f_560fcb3b2fa92af515bf, (String)CRACKME_0994bcc4_61bb_4761_8f2f_560fcb3b2fa9bbd1e807);
                        v4 = \u0141m1\u0179.CRACKME_a0930d8f_bf6d_4063_826b_498129741f8e_1da8a427;
                        if (true) ** GOTO lbl31
                        block21: while (true) {
                            v4 = v5 / (5624156002721076444L == 5624156002721076445L ? -1137969885388030124L : -334525351012491794L ^ -3575618836967932168L);
lbl31:
                            // 2 sources

                            switch ((int)v4) {
                                case -213321420: {
                                    v5 = -2049708716640865279L - 5651206156129040949L;
                                    continue block21;
                                }
                                case 700611787: {
                                    v5 = -3597234420897284617L ^ 5961345523786343837L;
                                    continue block21;
                                }
                                case 801564622: {
                                    if (-7180701453360987796L == -7180701453360987795L) {
                                        v5 = 2859081685751848536L;
                                        continue block21;
                                    }
                                    v5 = 4639693189804294669L - 1687378271548609625L;
                                    continue block21;
                                }
                                case 2039010288: {
                                    break block21;
                                }
                            }
                            break;
                        }
                        while (true) {
                            if ((v6 = (cfr_temp_0 = \u0141m1\u0179.CRACKME_a0930d8f_bf6d_4063_826b_498129741f8e_1da8a427 - (4254117012433228557L == 4254117012433228558L ? -2480412552224950533L : 2007811755338959278L ^ 4641530259468400829L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                                continue;
                            }
                            if (v6 == (-2068610580 ^ 2068610579)) {
                                v7 = zNb\u015b.Y\u017btq.getConfig();
                                var5_4 = new byte[945985455 ^ 945985450];
                                if (-2477224024547249500L == -2477224024547249499L) {
                                    break;
                                }
                                break block36;
                            }
                            v6 = -250585114 ^ -1660034877;
                        }
                        v8 = 1482743183;
                        break block37;
                    }
                    v8 = -1872342792 ^ -1872342911;
                }
                var5_4[984836561 ^ 984836563] = v8;
                var5_4[-1419779796 ^ -1419779796] = -1769815075 ^ -1769815108;
                var5_4[-1154239071 ^ -1154239067] = 986984727 ^ 986984820;
                var5_4[388288642 ^ 388288641] = 1953847556 ^ 1953847658;
                var5_4[-336739061 ^ -336739062] = -717684214 ^ -717684103;
                v9 = new String(var5_4, "UTF-8");
                v10 = \u0141m1\u0179.CRACKME_a0930d8f_bf6d_4063_826b_498129741f8e_1da8a427;
                if (true) ** GOTO lbl73
                block23: while (true) {
                    v10 = v11 / (-8291703428654273882L - -5254547159236127380L);
lbl73:
                    // 2 sources

                    switch ((int)v10) {
                        case -1769329469: {
                            v11 = 3411706238583020741L ^ 5822099060178714712L;
                            continue block23;
                        }
                        case -1719923852: {
                            v11 = -6280391579023844022L ^ 8567896074240430921L;
                            continue block23;
                        }
                        case 2039010288: {
                            break block23;
                        }
                    }
                    break;
                }
                if (!v7.getBoolean(v9)) break block38;
                -1182214525 ^ 910276124;
                Bukkit.getScheduler().runTaskAsynchronously((Plugin)zNb\u015b.Y\u017btq, (Runnable)CRACKME_0994bcc4_61bb_4761_8f2f_560fcb3b2fa9aa587097);
                -1006400450 ^ 405918603;
                break block39;
            }
            v12 = Bukkit.getScheduler();
            v13 = \u0141m1\u0179.CRACKME_a0930d8f_bf6d_4063_826b_498129741f8e_1da8a427;
            if (true) ** GOTO lbl125
            block24: while (true) {
                v13 = v14 / (-6131379167116198970L ^ 1315013280830622815L);
lbl125:
                // 2 sources

                switch ((int)v13) {
                    case -463159705: {
                        if (4465234820443694029L == 4465234820443694030L) {
                            v14 = -4286253917336895346L;
                            continue block24;
                        }
                        v14 = -9124954423169683371L ^ 6586070361429656460L;
                        continue block24;
                    }
                    case 2039010288: {
                        break block24;
                    }
                }
                break;
            }
            while (true) {
                if ((v15 = (cfr_temp_1 = \u0141m1\u0179.CRACKME_a0930d8f_bf6d_4063_826b_498129741f8e_1da8a427 - (6270445309897075603L - 4845325103214186638L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (v15 == (-2210968454870392986L == -2210968454870392985L ? 420632415 : -340961812 ^ -340961811)) {
                    v12.runTask((Plugin)zNb\u015b.Y\u017btq, (Runnable)CRACKME_0994bcc4_61bb_4761_8f2f_560fcb3b2fa9aa587097);
                    break;
                }
                v15 = 2131968170 - -123035058;
            }
        }
        1602073475 - -732245728;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     */
    static /* synthetic */ HttpClient kLYFKYGwK44LV6l3(HttpClient httpClient) {
        HttpClient CRACKME_067586e3_1f01_4d52_947e_93a26dc6cebcfd408c1f;
        if (CRACKME_a0930d8f_bf6d_4063_826b_498129741f8e_1da8a427 == (0x54DCD940C1947447L ^ 0x53797A929E3B4F4AL)) {
            if ((-581575216 >>> "\u0000\u0000".length() ^ (0x1D8DF165 ^ 0x62720E9A)) != 0) {
                int cfr_ignored_1 = 0xA6EFF57B ^ 0xA6EFF57A;
            }
        } else {
            int n = 0x32EC3ADD ^ 0x32EC3ADD;
        }
        long l = CRACKME_a0930d8f_bf6d_4063_826b_498129741f8e_1da8a427;
        boolean bl = true;
        block5: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x59C2601662720D80L ^ 0x38B4D267598AC63EL);
            }
            switch ((int)l) {
                case -1634648034: {
                    l2 = -4102113031212748711L - -1917348579858667800L;
                    continue block5;
                }
                case 2039010288: {
                    break block5;
                }
                case 2047716130: {
                    l2 = 0x62A4FE296156FB1L ^ 0x5BBA2DEBC1C7CB22L;
                    continue block5;
                }
            }
            break;
        }
        ClS9 = CRACKME_067586e3_1f01_4d52_947e_93a26dc6cebcfd408c1f;
        return ClS9;
    }

    private static /* synthetic */ void oUi_i8CYy1DbtieS() {
        int n;
        ConsoleCommandSender consoleCommandSender;
        block9: {
            block8: {
                if (CRACKME_a0930d8f_bf6d_4063_826b_498129741f8e_1da8a427 == (0x2A94E5BDFADE714EL ^ 0xAC1182A390EE3F63L)) {
                    if ((-1850837435 - 1736332944 ^ (0x156403C0 ^ 0x6A9BFC3F)) != 0) {
                        int n2 = -5298991484481315765L == -5298991484481315764L ? -1183791519 : 0x1A6BCD63 ^ 0x1A6BCD62;
                    }
                } else {
                    int cfr_ignored_1 = 0x68D034E9 ^ 0x68D034E9;
                }
                Server server = Bukkit.getServer();
                while (true) {
                    long l;
                    long l2;
                    if ((l2 = (l = CRACKME_a0930d8f_bf6d_4063_826b_498129741f8e_1da8a427 - (0x541A79AC98432721L ^ 0x6216BC3A21E4375FL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                        continue;
                    }
                    if (l2 == (0xE70F556F ^ 0xE70F556E)) {
                        consoleCommandSender = server.getConsoleSender();
                        if (7709768171926604027L == 7709768171926604028L) {
                            break;
                        }
                        break block8;
                    }
                    if (438758194580234772L == 438758194580234773L) {
                        l2 = 449037018;
                        continue;
                    }
                    l2 = 573556140 - 1586964424;
                }
                n = -171997522;
                break block9;
            }
            n = 0xB294E086 ^ 0xB294E0A3;
        }
        byte[] byArray = new byte[n];
        byArray[0x3BEA2A30 ^ 0x3BEA2A2B] = 0x3BBB5091 ^ 0x3BBB50F9;
        byArray[0x16B51FD4 ^ 0x16B51FDD] = 0xC4368798 ^ 0xC43687B8;
        byArray[0x218FAFCA ^ 0x218FAFDF] = 0xA22D874B ^ 0xA22D8739;
        byArray[9125993209898832903L == 9125993209898832904L ? 393529864 : 0xEC9D18CF ^ 0xEC9D18D1] = 0x82206AAC ^ 0x82206ACB;
        byArray[0x40AE46B1 ^ 0x40AE46B2] = 1438032224023444822L == 1438032224023444823L ? -2127914759 : 0x8FFB076B ^ 0x8FFB0722;
        byArray[0xFD86B4E1 ^ 0xFD86B4F2] = 0x9088BD58 ^ 0x9088BD2A;
        byArray[0x91687F4F ^ 0x91687F41] = -3994509648610630954L == -3994509648610630953L ? -1227388330 : 0x7E221DC ^ 0x7E221FC;
        byArray[0x5D58262B ^ 0x5D58262A] = 0xF797338F ^ 0xF79733BB;
        byArray[0x8A7B3915 ^ 0x8A7B3913] = 0x1FAF8C49 ^ 0x1FAF8C05;
        byArray[0xE9D71CCD ^ 0xE9D71CCF] = -263394221560570609L == -263394221560570608L ? 1555566285 : 0xF5E97C24 ^ 0xF5E97C7F;
        byArray[0x5FFD2DD7 ^ 0x5FFD2DD8] = 0xEEA1EF1A ^ 0xEEA1EF3C;
        byArray[0x67D6622C ^ 0x67D66226] = 0xB72F7688 ^ 0xB72F76AE;
        byArray[0x5B8ADDF4 ^ 0x5B8ADDD7] = 0x4437BEE2 ^ 0x4437BE83;
        byArray[0xC00DA919 ^ 0xC00DA914] = 0x2AEBB094 ^ 0x2AEBB0AA;
        byArray[0x3953D2AA ^ 0x3953D2A2] = 6659953296311140604L == 6659953296311140605L ? 288928088 : 0xC675096E ^ 0xC6750933;
        byArray[0xD91BD688 ^ 0xD91BD688] = -6923752272813072676L == -6923752272813072675L ? -1618246004 : 0xD197BA4 ^ 0xD197B82;
        byArray[0x67CBC120 ^ 0x67CBC12B] = 0x3C9C0087 ^ 0x3C9C00BF;
        byArray[0x8B20E0DA ^ 0x8B20E0DD] = 5822047468446417932L == 5822047468446417933L ? 1725506472 : 0x11ED3988 ^ 0x11ED39CB;
        byArray[0x6728B204 ^ 0x6728B208] = 0x3BA02EAE ^ 0x3BA02E90;
        byArray[973335019602354062L == 973335019602354063L ? 1851329019 : 0x94EB7BC7 ^ 0x94EB7BE5] = 0x13B65C86 ^ 0x13B65CF2;
        byArray[0x2F22CB13 ^ 0x2F22CB05] = 0xD69DF54E ^ 0xD69DF56E;
        byArray[0x7EA26A51 ^ 0x7EA26A4E] = 7108062174610750524L == 7108062174610750525L ? -1118406117 : 0x191AE7D5 ^ 0x191AE7F5;
        byArray[0xC4D4A307 ^ 0xC4D4A302] = 0x55C3CAC0 ^ 0x55C3CA94;
        byArray[0x9EF7154A ^ 0x9EF71553] = 0x5A7C3290 ^ 0x5A7C32E4;
        byArray[0x6751F1B9 ^ 0x6751F1AD] = 0x3C00319A ^ 0x3C0031F5;
        byArray[0x24D9E46C ^ 0x24D9E47D] = 2867526502691763822L == 2867526502691763823L ? -1600108116 : 0x34AF1ABE ^ 0x34AF1AFB;
        byArray[0xA82EC7C6 ^ 0xA82EC7E6] = -234941126876324760L == -234941126876324759L ? -213575185 : 0xA702BA31 ^ 0xA702BA55;
        byArray[0x6FB8E267 ^ 0x6FB8E27B] = 0xD400A19 ^ 0xD400A70;
        byArray[2557916180392551096L == 2557916180392551097L ? -88314330 : 0x45AC796C ^ 0x45AC7971] = -4440823274231926486L == -4440823274231926485L ? -1687516396 : 0x4F248B9D ^ 0x4F248BF3;
        byArray[0xCF51A67 ^ 0xCF51A75] = -8173430968749870654L == -8173430968749870653L ? 219229428 : 0x342DA1AB ^ 0x342DA1D9;
        byArray[0x5F2CC14B ^ 0x5F2CC15B] = 0xD128C14C ^ 0xD128C12F;
        byArray[0x4888E023 ^ 0x4888E039] = 136019373818709409L == 136019373818709410L ? -2137317260 : 0x24E249D ^ 0x24E24FE;
        byArray[0x2B635545 ^ 0x2B635561] = 0x78797ACA ^ 0x78797AEB;
        byArray[0x175FC18D ^ 0x175FC1AC] = 0x7E8E4F40 ^ 0x7E8E4F21;
        byArray[0xAE3CE847 ^ 0xAE3CE843] = 1631312659147805249L == 1631312659147805250L ? -141562390 : 0x76C62542 ^ 0x76C6256F;
        byArray[0xEDD88DE9 ^ 0xEDD88DF1] = 8029877690239236801L == 8029877690239236802L ? 187099228 : 0xAEB3EB47 ^ 0xAEB3EB22;
        byArray[0x7B178EB3 ^ 0x7B178EA4] = 7517810827290581226L == 7517810827290581227L ? 1483162129 : 0x38ECA334 ^ 0x38ECA352;
        consoleCommandSender.sendMessage(0QZ8.1d9kfLKTTP4TVZYm((String)new String(byArray, "UTF-8")));
    }

    /*
     * Exception decompiling
     */
    private /* synthetic */ void awMls1rEnAqMahNt(Map var1_1, String var2_2) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 40[SWITCH]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1050)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doClass(Driver.java:84)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:78)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompile(CFRDecompiler.java:89)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompileToZip(CFRDecompiler.java:133)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.decompileSaveAll(ResourceDecompiling.java:261)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.lambda$decompileSaveAll$0(ResourceDecompiling.java:111)
         *     at java.base/java.lang.Thread.run(Thread.java:1575)
         */
        throw new IllegalStateException("Decompilation failed");
    }
}
