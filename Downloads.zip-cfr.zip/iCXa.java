/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  0QZ8
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.Sound
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.java_websocket.client.WebSocketClient
 *  org.java_websocket.handshake.ServerHandshake
 *  zNb\u015b
 */
import java.lang.invoke.LambdaMetafactory;
import java.net.URI;
import java.util.function.Consumer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

public class iCXa
extends WebSocketClient {
    public static long CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3 = 6380070538162083451L;
    private static String[] CRACKME_BITCH = new String[10];
    public static String \u0105d\u017c\u0107;

    /*
     * Handled impossible loop by adding 'first' condition
     */
    public void onMessage(String string) {
        String CRACKME_c88d9c0a_4238_4118_a516_7a193fc637fd5dfba8db;
        byte[] byArray;
        block43: {
            if (CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3 == (0xB17DF6DA953BE4D7L ^ 0x3001987A87F67D6CL)) {
                int n = 0x9FC462B8 ^ 0x9FC462B9;
            } else {
                int cfr_ignored_12 = 0x8C8F37BF ^ 0x8C8F37BF;
            }
            byArray = new byte[0xB6BEF4BC ^ 0xB6BEF4B5];
            byArray[0x8B0A90D0 ^ 0x8B0A90D8] = 0x851AD679 ^ 0x851AD60D;
            int n = 0xB64A66FE ^ 0xB64A66FA;
            byArray[n] = 0x99DD2C74 ^ 0x99DD2C1F;
            int n2 = 0x8E6B8AD ^ 0x8E6B8A8;
            byArray[n2] = 0xD653EE9F ^ 0xD653EEF3;
            int n3 = 0x461E4F36 ^ 0x461E4F55;
            byArray[0xE1807523 ^ 0xE1807520] = n3;
            int n4 = 0xCB65F0CC ^ 0xCB65F0A0;
            byArray[0x33787167 ^ 0x33787166] = n4;
            byArray[0xE25246CF ^ 0xE25246C9] = 0xB543412B ^ 0xB5434142;
            byArray[0x9D24B895 ^ 0x9D24B892] = 0xFB6621AF ^ 0xFB6621DC;
            byArray[0xAC2F03B ^ 0xAC2F039] = 0x2D533F02 ^ 0x2D533F63;
            int n5 = 0x212491F7 ^ 0x212491F7;
            byArray[n5] = 0x6587EBCD ^ 0x6587EBAF;
            String string2 = new String(byArray, "UTF-8");
            long l = CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3;
            boolean bl = true;
            block19: while (true) {
                long l2;
                if (!bl || (bl = false) || !true) {
                    l = l2 / (-1699726747514951326L - -8752744640918144869L);
                }
                switch ((int)l) {
                    case -1580494002: {
                        l2 = 0x39D0ACB5EC2D571FL ^ 0x4F66F758EA0F4E1BL;
                        continue block19;
                    }
                    case -183101829: {
                        break block19;
                    }
                    case 489446371: {
                        l2 = 4490339920683565502L - 569622605601113373L;
                        continue block19;
                    }
                    case 1219986211: {
                        l2 = 907009943121414800L - 5138885224742845489L;
                        continue block19;
                    }
                }
                break;
            }
            if (CRACKME_c88d9c0a_4238_4118_a516_7a193fc637fd5dfba8db.contains(string2)) {
                while (true) {
                    long l3;
                    long l4;
                    if ((l4 = (l3 = CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3 - (3322572532014172045L - -7219268861218540205L)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
                    if (l4 == (0xFEC51447 ^ 0xFEC51446)) break;
                    l4 = 2071184853 - -1020112384;
                }
                while (true) {
                    long l5 = 5265165110620626376L >>> "\u0000\u0000".length();
                    long l6 = CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3 - l5;
                    long l7 = l6 == 0L ? 0 : (l6 < 0L ? -1 : 1);
                    if (l7 == false) continue;
                    if (l7 == (0x7B2CE96B ^ 0x7B2CE96A)) break;
                    l7 = 0x1A3DAE1B ^ 0xB3BC794D;
                }
                FileConfiguration fileConfiguration = zNb\u015b.Y\u017btq.getConfig();
                int n6 = 0x3BC8F410 ^ 0x27F66B2C;
                int n7 = 0x62B6C44C ^ 0x62B6C447;
                byArray = new byte[n7];
                int n8 = 0x858D45F6 ^ 0x858D45F2;
                byArray[n8] = 0x378814FF ^ 0x37881490;
                byArray[0x5A0D943D ^ 0x5A0D9438] = 0x1EA0DE03 ^ 0x1EA0DE68;
                byArray[0x420DA3FF ^ 0x420DA3F7] = 0x2D2E1B3F ^ 0x2D2E1B5E;
                int n9 = 0x8985B43 ^ 0x8985B37;
                byArray[0xC559CCBF ^ 0xC559CCBC] = n9;
                int n10 = 0x8D35B4B4 ^ 0x8D35B4DF;
                byArray[0xB0CE1EA2 ^ 0xB0CE1EA0] = n10;
                byArray[0xA1AE48EE ^ 0xA1AE48EF] = 0xC60DF344 ^ 0xC60DF32D;
                byArray[0xA7AD1A65 ^ 0xA7AD1A62] = 0xB3DFA104 ^ 0xB3DFA16A;
                byArray[0x9E734DC ^ 0x9E734DA] = 0xDC26AFE4 ^ 0xDC26AFBB;
                int n11 = 0xD68DD8C1 ^ 0xD68DD8C8;
                byArray[n11] = 0x6E5874D4 ^ 0x6E5874B9;
                byArray[0x3EC3FA19 ^ 0x3EC3FA13] = 0x812F1B9E ^ 0x812F1BFB;
                byArray[0x3449D9F7 ^ 0x3449D9F7] = 0x2547DC74 ^ 0x2547DC00;
                String string3 = new String(byArray, "UTF-8");
                while (true) {
                    long l8;
                    long l9;
                    if ((l9 = (l8 = CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3 - (0xD759F57F9D15B8A6L ^ 0x68060C47638DB969L)) == 0L ? 0 : (l8 < 0L ? -1 : 1)) == false) continue;
                    if (l9 == (0x4D1CAE22 ^ 0x4D1CAE23)) {
                        if (CRACKME_c88d9c0a_4238_4118_a516_7a193fc637fd5dfba8db.contains(fileConfiguration.getString(string3))) {
                            break;
                        }
                        break block43;
                    }
                    l9 = 0xC9FDA84 ^ 0x350C0CBA;
                }
                int n12 = 0xCEEA29B6 ^ 0xCEEA29BF;
                byArray = new byte[n12];
                byArray[0xBF161AFE ^ 0xBF161AFA] = 0x19E72A04 ^ 0x19E72A6F;
                byArray[0x29CBE619 ^ 0x29CBE618] = 0x25F464A6 ^ 0x25F464CA;
                int n13 = 0xB52DEA8 ^ 0xB52DECA;
                byArray[0xEA0BDF22 ^ 0xEA0BDF22] = n13;
                byArray[0xDD927025 ^ 0xDD927023] = 0xD208E995 ^ 0xD208E9FC;
                int n14 = 0x674B9A7A ^ 0x674B9A79;
                byArray[n14] = 0x2A959638 ^ 0x2A95965B;
                int n15 = 0x4395A5C6 ^ 0x4395A5B5;
                byArray[0x9A6980D4 ^ 0x9A6980D3] = n15;
                byArray[0xFC6E8187 ^ 0xFC6E8182] = 0x224433C3 ^ 0x224433AF;
                int n16 = 0x84D73A64 ^ 0x84D73A10;
                byArray[0xF26D2734 ^ 0xF26D273C] = n16;
                int n17 = 0x7F03896 ^ 0x7F038F7;
                byArray[0x1A5519AB ^ 0x1A5519A9] = n17;
                \u0105d\u017c\u0107 = new String(byArray, "UTF-8");
                while (true) {
                    long l10 = 0x295AB62C6A33DFL ^ 0x1182892B7A6104C2L;
                    long l11 = CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3 - l10;
                    long l12 = l11 == 0L ? 0 : (l11 < 0L ? -1 : 1);
                    if (l12 == false) continue;
                    if (l12 == (0x36167D68 ^ 0x36167D69)) {
                        Bukkit.getOnlinePlayers().forEach(player -> {
                            Player CRACKME_d7c3bd4d_1fa5_4855_8d4a_87137b70add375a48fdc;
                            if (CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3 == (0xC0E6E047F0A9211FL ^ 0xE8C066344CB61C8CL)) {
                                int cfr_ignored_3 = 0x13D42F99 ^ 0x13D42F98;
                            } else {
                                int cfr_ignored_4 = 0x997D63CD ^ 0x997D63CD;
                            }
                            int cfr_ignored_5 = -845126507 - -1501848456;
                            int n = 0xC1DFEF16 ^ 0xC1DFEF1D;
                            byte[] byArray = new byte[n];
                            byArray[0x9717239B ^ 0x9717239C] = 0x6B5FE31B ^ 0x6B5FE377;
                            int n2 = 0x1BD487B6 ^ 0x1BD487BF;
                            int n3 = 0x487CB180 ^ 0x487CB1F3;
                            byArray[n2] = n3;
                            byArray[0x1ED43763 ^ 0x1ED43762] = 0x901245BE ^ 0x9012458A;
                            byArray[0xC99918D9 ^ 0xC99918DA] = 0x912E3E8B ^ 0x912E3EE7;
                            byArray[0x13F9CC20 ^ 0x13F9CC2A] = 0xFEADF95D ^ 0xFEADF929;
                            byArray[0x4B5EE7C0 ^ 0x4B5EE7C4] = 0xDB791A0B ^ 0xDB791A6A;
                            int n4 = 0xE296003 ^ 0xE296003;
                            byArray[n4] = 0x82CD9476 ^ 0x82CD9450;
                            int n5 = 0xC26F7DFC ^ 0xC26F7D9F;
                            byArray[0x8A5C628 ^ 0x8A5C62D] = n5;
                            int n6 = 0xFB041432 ^ 0xFB04143A;
                            int n7 = 0xBF21F412 ^ 0xBF21F47B;
                            byArray[n6] = n7;
                            byArray[0x73FB5D36 ^ 0x73FB5D34] = 0x5F4FC7C5 ^ 0x5F4FC787;
                            int n8 = 0x73A72DC5 ^ 0x73A72DC3;
                            byArray[n8] = 0x8321D4FB ^ 0x8321D490;
                            String string = new String(byArray, "UTF-8");
                            long l = CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3;
                            boolean bl = true;
                            block17: while (true) {
                                long l2;
                                if (!bl || (bl = false) || !true) {
                                    l = l2 / (-8676899333277204375L - 4657540186777797360L);
                                }
                                switch ((int)l) {
                                    case -1601598708: {
                                        l2 = -3753644291558308554L - -132559581711298374L;
                                        continue block17;
                                    }
                                    case -183101829: {
                                        break block17;
                                    }
                                    case 1299038113: {
                                        l2 = 0xF29352C9A81ABE94L ^ 0xD2A2FE7FB4BDE8A9L;
                                        continue block17;
                                    }
                                }
                                break;
                            }
                            byArray = new byte[0x15B8DF7F ^ 0x15B8DF68];
                            int n9 = 0x56A6B0DB ^ 0x56A6B0DA;
                            byArray[n9] = 0xEC69F58F ^ 0xEC69F5EC;
                            int n10 = 0xC7385520 ^ 0xC7385545;
                            byArray[0x9FC120C3 ^ 0x9FC120D2] = n10;
                            byArray[0xBC2DEF46 ^ 0xBC2DEF48] = 0x295CF142 ^ 0x295CF177;
                            byArray[0xB948D675 ^ 0xB948D667] = 0xE88AC8E2 ^ 0xE88AC8B6;
                            byArray[0x459EB30C ^ 0x459EB308] = 0xB11D80A8 ^ 0xB11D80DB;
                            byArray[0xA8E3694 ^ 0xA8E3680] = 0xCC1C1607 ^ 0xCC1C1644;
                            byArray[0x31AF3F0A ^ 0x31AF3F03] = 0xCDC88627 ^ 0xCDC88609;
                            int n11 = 0x6758715F ^ 0x67587150;
                            byArray[n11] = 0x78040EC2 ^ 0x78040EBA;
                            int n12 = 0xD463DAB2 ^ 0xD463DAB2;
                            int n13 = 0xC358A003 ^ 0xC358A025;
                            byArray[n12] = n13;
                            byArray[0xF8740DDB ^ 0xF8740DD7] = 0x2B540D62 ^ 0x2B540D4D;
                            byArray[0xA9062868 ^ 0xA906287B] = 0x1D8076C7 ^ 0x1D8076B1;
                            int n14 = 0x5C025246 ^ 0x5C025250;
                            int n15 = 0xF4248558 ^ 0xF424856B;
                            byArray[n14] = n15;
                            byArray[0xAD51B79F ^ 0xAD51B79C] = 0x495ABAFB ^ 0x495ABA92;
                            byArray[0x454FF12D ^ 0x454FF120] = 0x3DEA678A ^ 0x3DEA67D8;
                            byArray[0x7E756CBC ^ 0x7E756CB9] = 0x546BE9C5 ^ 0x546BE9A6;
                            int n16 = 0x5F73E2F5 ^ 0x5F73E29A;
                            byArray[0x29A3C744 ^ 0x29A3C742] = n16;
                            byArray[0xDF64FCF1 ^ 0xDF64FCE4] = 0x56A93229 ^ 0x56A93244;
                            byArray[0x8D6BBC7E ^ 0x8D6BBC74] = 0xA9D13032 ^ 0xA9D13055;
                            int n17 = 0x4565B4B6 ^ 0x4565B4A6;
                            byArray[n17] = 0x65F0C5F6 ^ 0x65F0C5AE;
                            byArray[0x9A0E4A46 ^ 0x9A0E4A4E] = 0x5079E09 ^ 0x5079E6D;
                            byArray[0xB3B31490 ^ 0xB3B3149B] = 0x74F694EE ^ 0x74F69489;
                            byArray[0x106A6824 ^ 0x106A6823] = 0x7BD8457E ^ 0x7BD8450C;
                            byArray[0x2B74413B ^ 0x2B744139] = 0xC6638173 ^ 0xC6638117;
                            CRACKME_d7c3bd4d_1fa5_4855_8d4a_87137b70add375a48fdc.sendTitle(0QZ8.1d9kfLKTTP4TVZYm((String)string), 0QZ8.1d9kfLKTTP4TVZYm((String)new String(byArray, "UTF-8")));
                            Location location = CRACKME_d7c3bd4d_1fa5_4855_8d4a_87137b70add375a48fdc.getLocation();
                            long l3 = CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3;
                            boolean bl2 = true;
                            block18: while (true) {
                                long l4;
                                if (!bl2 || (bl2 = false) || !true) {
                                    long l5 = -2448386174756837699L - 2238487254185991477L;
                                    l3 = l4 / l5;
                                }
                                switch ((int)l3) {
                                    case -1293055596: {
                                        l4 = 0xD550A5664B983B12L ^ 0x4E600A27FF8CFF8DL;
                                        continue block18;
                                    }
                                    case -811571734: {
                                        l4 = 0xADD845FC2B7457F6L ^ 0xE4FA88FBD0EB527CL;
                                        continue block18;
                                    }
                                    case -183101829: {
                                        break block18;
                                    }
                                    case 1474978536: {
                                        l4 = 0x5B1A2C56241F2BFAL ^ 0x510C3A0FB3BC1EA7L;
                                        continue block18;
                                    }
                                }
                                break;
                            }
                            long l6 = CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3;
                            boolean bl3 = true;
                            block19: while (true) {
                                long l7;
                                if (!bl3 || (bl3 = false) || !true) {
                                    long l8 = 0x4652BAEEE1DB4EFL ^ 0xFE9A477DF66C1B56L;
                                    l6 = l7 / l8;
                                }
                                switch ((int)l6) {
                                    case -583351133: {
                                        l7 = 2500173699615000330L - 5863311859777921831L;
                                        continue block19;
                                    }
                                    case -497986801: {
                                        l7 = 0x341A9B01A207164DL ^ 0xAEDD4982121E40A2L;
                                        continue block19;
                                    }
                                    case -183101829: {
                                        break block19;
                                    }
                                    case 95681619: {
                                        l7 = 70936461669450704L - 5084313173536278278L;
                                        continue block19;
                                    }
                                }
                                break;
                            }
                            CRACKME_d7c3bd4d_1fa5_4855_8d4a_87137b70add375a48fdc.playSound(location, Sound.BLOCK_ANVIL_PLACE, 10.0f, 5.0f);
                        });
                        return;
                    }
                    l12 = 0xD5B3E33E ^ 0xA81509B9;
                }
            }
        }
        int cfr_ignored_13 = 0x1C041536 ^ 0xA6909FFD;
        int n = 1861464653 - -1874248979;
        int cfr_ignored_14 = 0x4890563E ^ 0x4FE13670;
        int cfr_ignored_15 = 0x1EAB1E3 ^ 0xE40DF27D;
        FileConfiguration fileConfiguration = zNb\u015b.Y\u017btq.getConfig();
        int cfr_ignored_16 = -1103250747 - -439064675;
        byArray = new byte[0x5BA1CDA9 ^ 0x5BA1CDA2];
        byArray[0x8D9E4463 ^ 0x8D9E446A] = 0x495D70FB ^ 0x495D7096;
        int n18 = 0x6C62AF9E ^ 0x6C62AFF5;
        byArray[0xCCD8EF69 ^ 0xCCD8EF6B] = n18;
        int n19 = 0xE67D549F ^ 0xE67D549C;
        int n20 = 0x8AFBB80E ^ 0x8AFBB87A;
        byArray[n19] = n20;
        int n21 = 0x621BEF34 ^ 0x621BEF3C;
        byArray[n21] = 0x37146147 ^ 0x37146126;
        int n22 = 0xCEC5CE93 ^ 0xCEC5CE95;
        byArray[n22] = 0x998B8DEA ^ 0x998B8DB5;
        byArray[0xB945413A ^ 0xB945413E] = 0x4929D6C2 ^ 0x4929D6AD;
        byArray[0x493D90FC ^ 0x493D90FD] = 0x417DB9B9 ^ 0x417DB9D0;
        byArray[0x3415D769 ^ 0x3415D76E] = 0x355C729A ^ 0x355C72F4;
        byArray[0x9F982FBE ^ 0x9F982FBE] = 0x31564130 ^ 0x31564144;
        int n23 = 0x9A277579 ^ 0x9A277573;
        int n24 = 0x28095BCC ^ 0x28095BA9;
        byArray[n23] = n24;
        byArray[0x3321643B ^ 0x3321643E] = 0xFB6C8879 ^ 0xFB6C8812;
        String string4 = new String(byArray, "UTF-8");
        long l = CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3;
        block24: while (true) {
            switch ((int)l) {
                case -183101829: {
                    break block24;
                }
                case 288481834: {
                    l = (0xE63787180CD5CA08L ^ 0x8FAB0B72A0955A35L) / (-134770246844043985L - -693032648485064748L);
                    continue block24;
                }
            }
            break;
        }
        String string5 = fileConfiguration.getString(string4);
        int cfr_ignored_17 = 0x202EDBB4 ^ 0x758D9EF;
        long l13 = CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3;
        boolean bl = true;
        block25: while (true) {
            long l14;
            if (!bl || (bl = false) || !true) {
                l13 = l14 / (-2095017390260805169L - 7725406416485630525L);
            }
            switch ((int)l13) {
                case -790310268: {
                    l14 = 0xAA736D52F26BD1F1L ^ 0xC5DBE8B1346FD2B5L;
                    continue block25;
                }
                case -183101829: {
                    break block25;
                }
                case 1902971598: {
                    l14 = 0xFBF280A18ACC326FL ^ 0x6D905345AF0D4B80L;
                    continue block25;
                }
            }
            break;
        }
        if (CRACKME_c88d9c0a_4238_4118_a516_7a193fc637fd5dfba8db.contains(string5)) {
            int cfr_ignored_18 = 0x109B1D47 ^ 0x4A3C3DB1;
            int cfr_ignored_19 = 511964069 - 405824221;
            byArray = new byte[0x8C35D992 ^ 0x8C35D99B];
            byArray[0x9DC29B24 ^ 0x9DC29B27] = 0xDB223455 ^ 0xDB22341C;
            int n25 = 0x9ECAACA ^ 0x9ECAACA;
            byArray[n25] = 0x6F556D3E ^ 0x6F556D18;
            int n26 = 0x79B6113F ^ 0x79B61137;
            byArray[n26] = 0x501576E7 ^ 0x501576BA;
            byArray[0x54A6043D ^ 0x54A60439] = 0x9DB476B6 ^ 0x9DB4769B;
            byArray[0x4B3D9AAD ^ 0x4B3D9AA8] = 0x33854E92 ^ 0x33854EC6;
            byArray[0xFC6ABA4 ^ 0xFC6ABA3] = 0xF0B776FF ^ 0xF0B776BC;
            byArray[0xAE31ED9 ^ 0xAE31EDF] = 0x3061C808 ^ 0x3061C844;
            byArray[0x82B42FC7 ^ 0x82B42FC5] = 0xC4D565B8 ^ 0xC4D565E3;
            int n27 = 0x371FA22C ^ 0x371FA22D;
            byArray[n27] = 0x43546C71 ^ 0x43546C13;
            String string6 = new String(byArray, "UTF-8");
            while (true) {
                long l15 = -221269625467392442L - -436566847508739524L;
                long l16 = CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3 - l15;
                long l17 = l16 == 0L ? 0 : (l16 < 0L ? -1 : 1);
                if (l17 == false) continue;
                if (l17 == (0xE7EA38AE ^ 0xE7EA38AF)) break;
                l17 = 0xB1837351 ^ 0x6076F7A2;
            }
            CRACKME_c88d9c0a_4238_4118_a516_7a193fc637fd5dfba8db = CRACKME_c88d9c0a_4238_4118_a516_7a193fc637fd5dfba8db.replace(string6, 0QZ8.1c\u0107O);
            while (true) {
                long l18 = 0x475CC2EBA77C55B0L ^ 0x875D78EF3EAD4542L;
                long l19 = CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3 - l18;
                long l20 = l19 == 0L ? 0 : (l19 < 0L ? -1 : 1);
                if (l20 == false) continue;
                if (l20 == (0xB399ED33 ^ 0xB399ED32)) break;
                l20 = -767077172 >>> "\u0000\u0000".length();
            }
            String CRACKME_c88d9c0a_4238_4118_a516_7a193fc637fd5612b6be = 0QZ8.1d9kfLKTTP4TVZYm((String)CRACKME_c88d9c0a_4238_4118_a516_7a193fc637fd5dfba8db);
            StringBuilder stringBuilder = new StringBuilder();
            byArray = new byte[0x807747AE ^ 0x807747AC];
            byArray[0xD7027396 ^ 0xD7027397] = 0x859A14F8 ^ 0x859A14CF;
            int n28 = 0x165F22A2 ^ 0x165F2284;
            byArray[0x76289116 ^ 0x76289116] = n28;
            String string7 = new String(byArray, "UTF-8");
            while (true) {
                long l21;
                long l22;
                if ((l22 = (l21 = CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3 - (-6714263663799978071L - -2180719809718517889L)) == 0L ? 0 : (l21 < 0L ? -1 : 1)) == false) continue;
                if (l22 == (0x5DF74A2B ^ 0x5DF74A2A)) break;
                l22 = -1404461722 - 328273674;
            }
            StringBuilder stringBuilder2 = stringBuilder.append(string7);
            while (true) {
                long l23 = -6669423011518073003L - 8774034386015503814L;
                long l24 = CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3 - l23;
                long l25 = l24 == 0L ? 0 : (l24 < 0L ? -1 : 1);
                if (l25 == false) continue;
                if (l25 == (0x9E1570E4 ^ 0x9E1570E5)) break;
                l25 = 0xD0E962B2 ^ 0x859D6A3D;
            }
            StringBuilder stringBuilder3 = stringBuilder2.append(CRACKME_c88d9c0a_4238_4118_a516_7a193fc637fd5612b6be);
            while (true) {
                long l26 = -4783197463918511476L - 7516530095539214749L;
                long l27 = CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3 - l26;
                long l28 = l27 == 0L ? 0 : (l27 < 0L ? -1 : 1);
                if (l28 == false) continue;
                if (l28 == (0x5A9FDB89 ^ 0x5A9FDB88)) break;
                l28 = 0xAD4F365E ^ 0x1EFCD097;
            }
            String string8 = stringBuilder3.toString();
            long l29 = CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3;
            block31: while (true) {
                switch ((int)l29) {
                    case -183101829: {
                        break block31;
                    }
                    case 1628502084: {
                        l29 = (-3526306661373999508L - 5586373774215949987L) / (0xF2981A2016CE2A83L ^ 0x8AF594D482E0E8F3L);
                        continue block31;
                    }
                }
                break;
            }
            Bukkit.broadcastMessage((String)0QZ8.1d9kfLKTTP4TVZYm((String)string8));
            byArray = new byte[0x8258358A ^ 0x8258358E];
            byArray[0x914A9C3 ^ 0x914A9C3] = 0x8CA8FF82 ^ 0x8CA8FFE0;
            byArray[0xAEB700C4 ^ 0xAEB700C6] = 0xA43037B4 ^ 0xA43037D5;
            int n29 = 0x847DE24C ^ 0x847DE227;
            byArray[0x4A561B50 ^ 0x4A561B53] = n29;
            byArray[0xD8D6BB72 ^ 0xD8D6BB73] = 0x717D5398 ^ 0x717D53EA;
            String string9 = new String(byArray, "UTF-8");
            while (true) {
                long l30;
                long l31;
                if ((l31 = (l30 = CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3 - (7279304900604914599L - 4025334632720206314L)) == 0L ? 0 : (l30 < 0L ? -1 : 1)) == false) continue;
                if (l31 == (0xA63EAE9E ^ 0xA63EAE9F)) {
                    \u0105d\u017c\u0107 = string9;
                    break;
                }
                l31 = 0x1971C388 ^ 0x54106BA5;
            }
        }
        int cfr_ignored_20 = -216401400 - -680153393;
    }

    static {
        iCXa.CRACKME_BITCH[0] = "....................../\u00b4\u00af/)";
        iCXa.CRACKME_BITCH[1] = "....................,/\u00af../....................";
        iCXa.CRACKME_BITCH[2] = ".................../..../....................";
        iCXa.CRACKME_BITCH[3] = "............./\u00b4\u00af/'...'/\u00b4\u00af\u00af`\u00b7\u00b8....................";
        iCXa.CRACKME_BITCH[4] = "........../'/.../..../......./\u00a8\u00af\\....................";
        iCXa.CRACKME_BITCH[5] = "........('(...\u00b4...\u00b4.... \u00af~/'...')....................";
        iCXa.CRACKME_BITCH[6] = ".........\\.................'...../....................";
        iCXa.CRACKME_BITCH[7] = "..........''...\\.......... _.\u00b7\u00b4....................";
        iCXa.CRACKME_BITCH[8] = "............\\..............(....................";
        iCXa.CRACKME_BITCH[9] = "..............\\.............\\.......................";
        if (CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3 == 3030627235728219085L - 8171606001917802760L) {
            if (((-2965295706673374987L == -2965295706673374986L ? 1477687010 : 0x15CDC1B4 ^ 0x54ED4037) ^ 1985236858 - -162246789) != 0) {
                int cfr_ignored_1 = 0x1B81BBAC ^ 0x1B81BBAD;
            }
        } else {
            int cfr_ignored_2 = 0x5F9680E2 ^ 0x5F9680E2;
        }
        byte[] byArray = new byte[0xE9EE3F1D ^ 0xE9EE3F19];
        byArray[0x30E3D102 ^ 0x30E3D100] = 0xAB346627 ^ 0xAB346646;
        byArray[114922278264831079L == 114922278264831080L ? -272268179 : 0x7E037D8D ^ 0x7E037D8C] = 0xF5B4C151 ^ 0xF5B4C123;
        byArray[-8603954625923663088L == -8603954625923663087L ? 283983507 : 0x3E12C056 ^ 0x3E12C055] = 0xE0F72E89 ^ 0xE0F72EE2;
        byArray[0x7967489B ^ 0x7967489B] = 0xC4D130F ^ 0xC4D136D;
        String string = new String(byArray, "UTF-8");
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3 - (0xCD43D799400A9737L ^ 0xA330BCE5471A0C89L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0x27AA80D ^ 0xFD8557F2)) {
                \u0105d\u017c\u0107 = string;
                return;
            }
            l2 = 0x6056AA9C ^ 0x2EE7DADA;
        }
    }

    public void onError(Exception exception) {
        if (CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3 == (0x3B7340E8F2EAC10L ^ 0xB8E71AAB4EB62342L)) {
            if ((0x352413E3 ^ 0x9DC23CC ^ 1256593609 - -890890038) == 0) return;
            int cfr_ignored_0 = 0x5E8B9709 ^ 0x5E8B9708;
        } else {
            int cfr_ignored_1 = 0x8D4D5967 ^ 0x8D4D5967;
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     */
    private static /* synthetic */ void FssBKJiD93wNQn1B(Player player) {
        Player CRACKME_8c1c9b60_e79a_4292_83eb_ac484ea5b00930f69642;
        long l = 0x8618A4DF1E62DC88L ^ 0x72FA2BA67085F90FL;
        if (CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3 == l) {
            int n = 0x7C404136 ^ 0x7C404137;
        } else {
            int n = 0x1B8D2AFF ^ 0x1B8D2AFF;
        }
        int cfr_ignored_2 = 0x43F17601 ^ 0x6A14B5A6;
        int n = -348702168 >>> "\u0000\u0000".length();
        int n2 = 0xB1B0BE8 ^ 0xB1B0BD1;
        byte[] byArray = new byte[n2];
        int n3 = 0xE4E9CEC9 ^ 0xE4E9CEEF;
        byArray[0x31F76A07 ^ 0x31F76A0D] = n3;
        byArray[0xA80BE361 ^ 0xA80BE37D] = 0x6B842786 ^ 0x6B8427F1;
        int n4 = 0x3E548C6B ^ 0x3E548C55;
        byArray[0xC6C9E6B6 ^ 0xC6C9E6BB] = n4;
        byArray[0xD59D23EE ^ 0xD59D23FD] = 0x3D886328 ^ 0x3D886346;
        byArray[0x2A27296E ^ 0x2A272946] = 0xD8080170 ^ 0xD808011F;
        byArray[0x8A598BF1 ^ 0x8A598BC7] = 0xDB2C05BC ^ 0x24D3FA78;
        int n5 = 0xD270B8D8 ^ 0xD270B8DC;
        byArray[n5] = 0xB5AEABD4 ^ 0xB5AEABF9;
        int n6 = 0xA70728FE ^ 0xA70728CE;
        byArray[n6] = 0x8D29A05C ^ 0x8D29A03E;
        byArray[0x3AB73863 ^ 0x3AB73868] = 0xB2B1990D ^ 0xB2B19935;
        byArray[0xE0637FBC ^ 0xE0637FB2] = 0xB1D9973B ^ 0xB1D9971B;
        int n7 = 0xE752F5BE ^ 0xE752F5F2;
        byArray[0x92A3D95B ^ 0x92A3D95D] = n7;
        byArray[0x2CDC6AB8 ^ 0x2CDC6ABB] = 0x6C846766 ^ 0x6C84672F;
        byArray[0xEB7F69A9 ^ 0xEB7F69AB] = 0x387839A7 ^ 0x387839FC;
        byArray[0x7C8B617F ^ 0x7C8B616F] = 0xC4222AB2 ^ 0xC4222AD1;
        int n8 = 0x22B58DBE ^ 0x22B58DA3;
        byArray[n8] = 0x9EAF8D7B ^ 0x9EAF8D15;
        byArray[0x7330A197 ^ 0x7330A18C] = 0xCAE1ABA ^ 0xCAE1AD5;
        byArray[0x5DAE4A4E ^ 0x5DAE4A5A] = 0x1CC87AD5 ^ 0x1CC87AF5;
        byArray[0x8D949E65 ^ 0x8D949E4B] = 0xB242F053 ^ 0x4DBD0FD6;
        byArray[0x529F7E2E ^ 0x529F7E2E] = 0xB910CBEF ^ 0xB910CBC9;
        int n9 = 0x2360076E ^ 0x2360076F;
        byArray[n9] = 0xB8DE4378 ^ 0xB8DE434C;
        int n10 = 0x2A6CE274 ^ 0x2A6CE278;
        byArray[n10] = 0x6A3AEA78 ^ 0x6A3AEA46;
        byArray[0x97FFDA99 ^ 0x97FFDAB2] = 0x5F5F29BC ^ 0x5F5F29D3;
        int n11 = 0xE38376D9 ^ 0xE38376CC;
        int n12 = 0x93346C66 ^ 0x93346C13;
        byArray[n11] = n12;
        int n13 = 0xC018CE67 ^ 0xC018CE78;
        byArray[n13] = 0x10B374D8 ^ 0x10B374B3;
        int n14 = 0x5D28172B ^ 0x5D28171F;
        byArray[n14] = 0xA70961DE ^ 0xA70961BF;
        byArray[0xDAA4E371 ^ 0xDAA4E350] = 0x50002AEA ^ 0x50002A87;
        byArray[0xD7CED3AB ^ 0xD7CED398] = 0x9CCF04A4 ^ 0x9CCF04CF;
        byArray[0x134293E4 ^ 0x134293F5] = 0xBD9E4F72 ^ 0xBD9E4F26;
        byArray[0x58A47F5D ^ 0x58A47F44] = 0x46DCF511 ^ 0x46DCF565;
        byArray[0xEFAE3BEB ^ 0xEFAE3BC4] = 0x8E80BF10 ^ 0x8E80BF30;
        int n15 = 0xA78AFD53 ^ 0xA78AFD73;
        byArray[0xB8DF87A ^ 0xB8DF85A] = n15;
        byArray[0x834B2E70 ^ 0x834B2E53] = 0x326FFDC4 ^ 0x326FFDE4;
        byArray[0x27E2042D ^ 0x27E20428] = 0x2C92714 ^ 0x2C92740;
        int n16 = 0x5A86EE95 ^ 0x5A86EEB8;
        byArray[n16] = 0x65171A3D ^ 0x9AE8E5F9;
        byArray[0xC41BEF5D ^ 0xC41BEF74] = 0x14443E31 ^ 0xEBBBC1F4;
        byArray[0x10E6E079 ^ 0x10E6E05E] = 0x900777F ^ 0xF6FF88FD;
        byArray[0x654B918F ^ 0x654B91AB] = 0xE1B132A6 ^ 0xE1B132C8;
        byArray[0x4B6CB468 ^ 0x4B6CB45D] = 0x5B793157 ^ 0x5B793133;
        byArray[0x6B8DEF42 ^ 0x6B8DEF4D] = 0x5E527CFA ^ 0x5E527CDC;
        byArray[0x28CA774B ^ 0x28CA7751] = 0x3684292A ^ 0x36842941;
        byArray[0x13147B2A ^ 0x13147B34] = 0xBD1DE635 ^ 0xBD1DE65C;
        int n17 = 0xFC63639D ^ 0xFC6363F8;
        byArray[0x20C75D77 ^ 0x20C75D65] = n17;
        byArray[0x38EFEB90 ^ 0x38EFEB98] = 0x576A4FC6 ^ 0x576A4F9B;
        int n18 = 0xDD626528 ^ 0xDD62652F;
        byArray[n18] = 0xF4E08241 ^ 0xF4E08202;
        byArray[0x6FC439C5 ^ 0x6FC439CC] = 0x79B964A6 ^ 0x79B96486;
        int n19 = 0x866A42F4 ^ 0x866A42D6;
        int n20 = 0x6478941B ^ 0x6478947A;
        byArray[n19] = n20;
        byArray[0x2BAF71E7 ^ 0x2BAF71D0] = 1342254185 - 1342254288;
        byArray[0x84964E38 ^ 0x84964E14] = 0x85E02362 ^ 0x85E0230C;
        byArray[0x45FE964B ^ 0x45FE9661] = -826116641 - -826116573;
        byArray[0x7CA752F8 ^ 0x7CA752CA] = 0x10E2E0B4 ^ 0x10E2E0DB;
        byArray[0x8131549 ^ 0x813156F] = 1442018799 - 1442018858;
        int n21 = 0x91D9B8D ^ 0xF6E26448;
        byArray[0x601548FC ^ 0x601548EA] = n21;
        byArray[0x7FB372CB ^ 0x7FB372D3] = 0x600CF2A3 ^ 0x600CF2DA;
        byArray[0xD6728586 ^ 0xD6728591] = 0x41FCF55 ^ 0xFBE030E9;
        byArray[0x6AFA1205 ^ 0x6AFA123D] = 0x3F0E92A5 ^ 0x3F0E9284;
        byArray[0xF023CA9F ^ 0xF023CABA] = 0x4155E93D ^ 0x4155E95C;
        byArray[0x8D3B696F ^ 0x8D3B695E] = 0xB996BFCB ^ 0xB996BFA7;
        String string = new String(byArray, "UTF-8");
        long l2 = CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3;
        boolean bl = true;
        block11: while (true) {
            long l3;
            if (!bl || (bl = false) || !true) {
                long l4 = 6506020443878210196L >>> "\u0000\u0000".length();
                l2 = l3 / l4;
            }
            switch ((int)l2) {
                case -1897631473: {
                    l3 = 0x32B97EDD13D7604FL ^ 0x617341F05C2851F1L;
                    continue block11;
                }
                case -552715882: {
                    l3 = 0xF84B93341A5A3B02L ^ 0x54A48D28B22F3AF5L;
                    continue block11;
                }
                case -183101829: {
                    break block11;
                }
                case 190135252: {
                    l3 = -6770492055587527164L >>> "\u0000\u0000".length();
                    continue block11;
                }
            }
            break;
        }
        String string2 = 0QZ8.1d9kfLKTTP4TVZYm((String)string);
        long l5 = CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3;
        boolean bl2 = true;
        block12: while (true) {
            long l6;
            if (!bl2 || (bl2 = false) || !true) {
                l5 = l6 / (0xEFF56B5EB66BA32EL ^ 0x9C2FAE5379AAA908L);
            }
            switch ((int)l5) {
                case -183101829: {
                    break block12;
                }
                case 417524097: {
                    l6 = 0x8EE8F10651A2E8B0L ^ 0x69FAFAD9C4E8253EL;
                    continue block12;
                }
                case 652639400: {
                    l6 = -6635507376404076059L - 3503614798575155381L;
                    continue block12;
                }
            }
            break;
        }
        CRACKME_8c1c9b60_e79a_4292_83eb_ac484ea5b00930f69642.sendMessage(string2);
    }

    public void onOpen(ServerHandshake serverHandshake) {
        if (CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3 == (0xD6B3BFAB133996CDL ^ 0x76D3195C7E0AD41CL)) {
            if (((2389261037943736424L == 2389261037943736425L ? -358170970 : 0x4866B711 ^ 0x2665A835) ^ 1831180061 - -316303586) == 0) return;
            int cfr_ignored_0 = 0x3085B815 ^ 0x3085B814;
        } else {
            int cfr_ignored_1 = 0xE9EF5D1B ^ 0xE9EF5D1B;
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * WARNING - void declaration
     */
    public iCXa(URI uRI) {
        void CRACKME_fa5bab90_1f0e_4ad2_b778_851835f062a39a5d02ae;
        iCXa CRACKME_fa5bab90_1f0e_4ad2_b778_851835f062a3cd6b58ba;
        if (CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3 == -944361069748708756L - -4132498206291651146L) {
            int cfr_ignored_1 = 0x1470E919 ^ 0x1470E918;
        } else {
            int cfr_ignored_2 = 0x3F55D98E ^ 0x3F55D98E;
        }
        int n = 0xD96E7636 ^ 0xE6818225;
        long l = CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3;
        boolean bl = true;
        block6: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (-9056712012531303505L - 6436525958306644110L);
            }
            switch ((int)l) {
                case -779984272: {
                    l2 = 0xDCC0CD1E403B9C3AL ^ 0x386B4E05B54E876BL;
                    continue block6;
                }
                case -183101829: {
                    break block6;
                }
                case 864925687: {
                    l2 = 103044551141686722L - 5403373378106817884L;
                    continue block6;
                }
                case 1542985111: {
                    l2 = 0x858315E1DDC4DE3EL ^ 0x50DE74272CC0AFBBL;
                    continue block6;
                }
            }
            break;
        }
        super((URI)CRACKME_fa5bab90_1f0e_4ad2_b778_851835f062a39a5d02ae);
        int cfr_ignored_3 = 0x3A1F0E9F ^ 0xB5BDC0F;
    }

    /*
     * Unable to fully structure code
     */
    public void onClose(int var1_1, String var2_2, boolean var3_3) {
        block29: {
            block30: {
                block28: {
                    if (iCXa.CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3 == (-6046515518002727981L ^ 1192572242604689155L)) {
                        if ((2045230108 - 307422113 ^ (5745562788375797529L == 5745562788375797530L ? 2133521397 : -1996701620 - 150782029)) != 0) {
                            -437643340 ^ -437643339;
                        }
                    } else {
                        -773131522 ^ -773131522;
                    }
                    var5_4 = new byte[8498546683130040243L == 8498546683130040244L ? -344336532 : 1531752848 ^ 1531752857];
                    var5_4[8315452430887111584L == 8315452430887111585L ? -1123658451 : 1607460954 ^ 1607460956] = 979583856 ^ 979583769;
                    var5_4[-351914999 ^ -351915000] = 1545350788 ^ 1545350888;
                    var5_4[-1788996618 ^ -1788996619] = 7995214092818819874L == 7995214092818819875L ? 478128325 : -495153145 ^ -495153052;
                    var5_4[1075240480 ^ 1075240484] = -1852833983 ^ -1852834006;
                    var5_4[9046080974170968551L == 9046080974170968552L ? 1114178455 : 921787583 ^ 921787576] = 284605121945557909L == 284605121945557910L ? 1548682617 : 987209301 ^ 987209254;
                    var5_4[-164480681 ^ -164480686] = 1884741806 ^ 1884741826;
                    var5_4[462316538 ^ 462316536] = 1543595228 ^ 1543595197;
                    var5_4[2102386681 ^ 2102386673] = -750227202 ^ -750227318;
                    var5_4[1963021027 ^ 1963021027] = -1739939726 ^ -1739939824;
                    v0 = new String(var5_4, "UTF-8");
                    v1 = iCXa.CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3;
                    if (true) ** GOTO lbl28
                    block11: while (true) {
                        v1 = v2 / (-4716836042443762591L == -4716836042443762590L ? 8891492836980094630L : 7367767526503454986L ^ 7775472449388233633L);
lbl28:
                        // 2 sources

                        switch ((int)v1) {
                            case -403058788: {
                                v2 = 6128144822132169222L ^ -41689611716804236L;
                                continue block11;
                            }
                            case -380375886: {
                                v2 = 8046707515344686703L ^ 5868482490128599591L;
                                continue block11;
                            }
                            case -280131759: {
                                if (5685966598035480072L == 5685966598035480073L) {
                                    v2 = -5746345948433875586L;
                                    continue block11;
                                }
                                v2 = -8772012644510945998L ^ 5825394033557968426L;
                                continue block11;
                            }
                            case -183101829: {
                                break block11;
                            }
                        }
                        break;
                    }
                    if (!CRACKME_d30f39f3_9f03_484e_934b_a6a121a0971c64a105b1.contains(v0)) break block29;
                    v3 = -2053133256849398916L == -2053133256849398915L ? -321376372 : -97000172 >>> "\u0000\u0000".length();
                    while (true) {
                        if ((v4 = (cfr_temp_0 = iCXa.CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3 - (-5251224458065255267L ^ 5489437136259646054L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                        if (v4 == (-1531631312 ^ -1531631311)) break;
                        v4 = -1932956810 ^ -1662260413;
                    }
                    while (true) {
                        if ((v5 = (cfr_temp_1 = iCXa.CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3 - (3119526015201303448L ^ -311170422950096881L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                        if (v5 == (845565659 ^ 845565658)) {
                            v6 = zNb\u015b.Y\u017btq.getConfig();
                            var5_4 = new byte[-1117923502 ^ -1117923495];
                            var5_4[81454828 ^ 81454826] = -861693033 ^ -861692984;
                            var5_4[747293165 ^ 747293160] = -627764456 ^ -627764365;
                            if (-6025715782372343519L == -6025715782372343518L) {
                                break;
                            }
                            break block28;
                        }
                        v5 = -887804399 ^ 1342800050;
                    }
                    v7 = -1295419273;
                    break block30;
                }
                v7 = -451980596 ^ -451980597;
            }
            var5_4[v7] = -1008925005 ^ -1008924963;
            var5_4[1726936112 ^ 1726936122] = -2117327512 ^ -2117327603;
            var5_4[68095321 ^ 68095313] = -571682568 ^ -571682663;
            var5_4[1369770544 ^ 1369770545] = -6312908862763248318L == -6312908862763248317L ? -1957209649 : 905721642 ^ 905721667;
            var5_4[-1071309416 ^ -1071309413] = 2140981055 ^ 2140981067;
            var5_4[-986043771 ^ -986043775] = 259635230 ^ 259635313;
            var5_4[-639791491 ^ -639791491] = 503877732 ^ 503877648;
            var5_4[-1587818306 ^ -1587818313] = 2729797117132189824L == 2729797117132189825L ? -1054538531 : -1679923284 ^ -1679923263;
            var5_4[2058871014 ^ 2058871012] = -1420773989 ^ -1420773904;
            v8 = new String(var5_4, "UTF-8");
            v9 = iCXa.CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3;
            if (true) ** GOTO lbl84
            block14: while (true) {
                v9 = v10 / (-7926867126119302141L == -7926867126119302140L ? 8349152767244035493L : 4735944628613119693L ^ -6833024330238157117L);
lbl84:
                // 2 sources

                switch ((int)v9) {
                    case -1595154196: {
                        if (-6425415676734512519L == -6425415676734512518L) {
                            v10 = -9137347507939675751L;
                            continue block14;
                        }
                        v10 = 8215397344777188640L - 1014353003106211196L;
                        continue block14;
                    }
                    case -183101829: {
                        break block14;
                    }
                    case 613855504: {
                        if (3148102717856026180L == 3148102717856026181L) {
                            v10 = -726285462952629502L;
                            continue block14;
                        }
                        v10 = 2246140109350122367L - -3669112424629679104L;
                        continue block14;
                    }
                }
                break;
            }
            1108923081 ^ -1890676936;
            if (CRACKME_d30f39f3_9f03_484e_934b_a6a121a0971c64a105b1.contains(v6.getString(v8))) {
                419414687 ^ -349238800;
                var5_4 = new byte[-1485984725 ^ -1485984734];
                var5_4[1028268168 ^ 1028268160] = -1305148194 ^ -1305148246;
                var5_4[443555083 ^ 443555087] = -2063328129 ^ -2063328236;
                var5_4[1084973415 ^ 1084973414] = 1896529421 ^ 1896529505;
                var5_4[593687678 ^ 593687675] = 124504172 ^ 124504064;
                var5_4[280218454 ^ 280218453] = -1930541339 ^ -1930541434;
                var5_4[1313532313 ^ 1313532315] = -326559324 ^ -326559291;
                var5_4[2117276181 ^ 2117276179] = -1819595207 ^ -1819595184;
                var5_4[6164189477144948717L == 6164189477144948718L ? 2019706904 : 1618478909 ^ 1618478906] = 1047032176056941693L == 1047032176056941694L ? -1973754355 : 1560584950 ^ 1560584837;
                var5_4[-2066393490 ^ -2066393490] = -5318916119338024654L == -5318916119338024653L ? -1648333363 : -578864824 ^ -578864854;
                iCXa.\u0105d\u017c\u0107 = new String(var5_4, "UTF-8");
                -208376037 - 971832004;
                while (true) {
                    if ((v11 = (cfr_temp_2 = iCXa.CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3 - (-9210966428567879280L ^ 7300882645173105693L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                    if (v11 == (-1020391355 ^ -1020391356)) break;
                    if (8333180926678805124L == 8333180926678805125L) {
                        v11 = 1258616353;
                        continue;
                    }
                    v11 = 398343705 ^ 2146115816;
                }
                v12 = Bukkit.getOnlinePlayers();
                while (true) {
                    if ((v13 = (cfr_temp_3 = iCXa.CRACKME_8943221c_26cb_4f4f_afe4_1de151f9d091_c45bb4a3 - (3524277247542172929L ^ -1218693473098370350L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                    if (v13 == (1204832750 ^ 1204832751)) {
                        1380501266 ^ 1870624069;
                        v12.forEach((Consumer<Player>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)V, FssBKJiD93wNQn1B(org.bukkit.entity.Player ), (Lorg/bukkit/entity/Player;)V)());
                        break;
                    }
                    v13 = -1394894845 ^ 218787320;
                }
            }
        }
        -837435541 ^ -1083072542;
    }
}
