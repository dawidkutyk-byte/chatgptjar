/*
 * Decompiled with CFR 0.152.
 */
public final class nt5c {
    public static final String aXS0;
    private static long CRACKME_c974a056_4c57_49b1_b201_2c48dbd5136c_10cb1b5a = 6248292320269419457L;
    private static String[] CRACKME_BITCH;

    static {
        CRACKME_BITCH = new String[15];
        nt5c.CRACKME_BITCH[0] = "\u2282_\u30fd";
        nt5c.CRACKME_BITCH[1] = "\u3000 \uff3c\uff3c\u3000\u3000\u3000";
        nt5c.CRACKME_BITCH[2] = "\u3000\u3000 \uff3c( \u0361\u00b0 \u035c\u0296 \u0361\u00b0)\u3000\u3000\u3000";
        nt5c.CRACKME_BITCH[3] = "\u3000\u3000\u3000 >\u3000\u2312\u30fd\u3000\u3000\u3000";
        nt5c.CRACKME_BITCH[4] = "\u3000\u3000\u3000/ \u3000 \u3078\uff3c\u3000\u3000\u3000";
        nt5c.CRACKME_BITCH[5] = "\u3000\u3000 /\u3000\u3000/\u3000\uff3c\uff3c\u3000\u3000\u3000";
        nt5c.CRACKME_BITCH[6] = "\u3000\u3000 \uff9a\u3000\u30ce\u3000\u3000 \u30fd_\u3064\u3000\u3000\u3000";
        nt5c.CRACKME_BITCH[7] = "\u3000\u3000/\u3000/\u3000\u3000\u3000";
        nt5c.CRACKME_BITCH[8] = "\u3000 /\u3000/|\u3000\u3000\u3000";
        nt5c.CRACKME_BITCH[9] = "\u3000(\u3000(\u30fd\u3000\u3000\u3000";
        nt5c.CRACKME_BITCH[10] = "\u3000|\u3000|\u3001\uff3c\u3000\u3000\u3000";
        nt5c.CRACKME_BITCH[11] = "\u3000| \u4e3f \uff3c \u2312)\u3000\u3000\u3000";
        nt5c.CRACKME_BITCH[12] = "\u3000| |\u3000\u3000) /\u3000\u3000\u3000";
        nt5c.CRACKME_BITCH[13] = "\u30ce )\u3000\u3000L\uff89\u3000\u3000\u3000";
        nt5c.CRACKME_BITCH[14] = "(_\uff0f\u3000\u3000\u3000\u3000\u3000\u3000";
        byte[] byArray = new byte[-4694533793990127327L == -4694533793990127326L ? 1556204034 : 0x529E71FD ^ 0x529E71F4];
        byArray[4045994360059932075L == 4045994360059932076L ? -1657904866 : 0x77929DFC ^ 0x77929DFC] = 0x53D77E8A ^ 0x53D77EEB;
        byArray[0xBDD9B5B9 ^ 0xBDD9B5BB] = 0xAA76B6EB ^ 0xAA76B69D;
        byArray[0x416D7AEB ^ 0x416D7AEA] = 0xEC6EA2BB ^ 0xEC6EA2DF;
        byArray[7996651742561245282L == 7996651742561245283L ? 1813243293 : 0xE1679900 ^ 0xE1679907] = 0x9BF26AA8 ^ 0x9BF26ADA;
        byArray[0xA15BC01D ^ 0xA15BC018] = 0xF8CBEE82 ^ 0xF8CBEEF6;
        byArray[0x46AC40CD ^ 0x46AC40C5] = 7045591617137519545L == 7045591617137519546L ? 1699733991 : 0xDDB2CF1D ^ 0xDDB2CF78;
        byArray[0xA4B0A240 ^ 0xA4B0A243] = 0x97A2AA29 ^ 0x97A2AA4C;
        byArray[1185234333271157666L == 1185234333271157667L ? -300017418 : 0x2A702B95 ^ 0x2A702B91] = 0x52506F56 ^ 0x52506F38;
        byArray[0x23EA7300 ^ 0x23EA7306] = 3013831866876690053L == 3013831866876690054L ? 857136279 : 0xC0E2A26B ^ 0xC0E2A21E;
        aXS0 = new String(byArray, "UTF-8");
    }

    /*
     * Handled impossible loop by adding 'first' condition
     */
    private nt5c() {
        nt5c CRACKME_dfe1b72d_8e49_4f79_90c6_c10b4da629a6265d9e01;
        long l = -271353479007648225L - -208312233026611943L;
        if (CRACKME_c974a056_4c57_49b1_b201_2c48dbd5136c_10cb1b5a == l) {
            int n = -1268421726 - 6877181;
            if ((n ^ (0x1BC66ABB ^ 0x64399544)) != 0) {
                int cfr_ignored_1 = 0xC6F875E3 ^ 0xC6F875E2;
            }
        } else {
            int cfr_ignored_2 = 0xE3165048 ^ 0xE3165048;
        }
        long l2 = CRACKME_c974a056_4c57_49b1_b201_2c48dbd5136c_10cb1b5a;
        boolean bl = true;
        block6: while (true) {
            long l3;
            if (!bl || (bl = false) || !true) {
                l2 = l3 / (1824058214865945298L - -4812714954096331707L);
            }
            switch ((int)l2) {
                case -1435122751: {
                    break block6;
                }
                case -181538260: {
                    l3 = -792592450773254736L - -1651192173539962366L;
                    continue block6;
                }
                case 64406279: {
                    l3 = 0xD3266E467E8F43DL ^ 0xDDF815A4EB58E3C1L;
                    continue block6;
                }
                case 246918559: {
                    l3 = 7192350999506293609L - 3832404680564157772L;
                    continue block6;
                }
            }
            break;
        }
        int cfr_ignored_3 = -1707279177 - -1114550174;
    }
}
