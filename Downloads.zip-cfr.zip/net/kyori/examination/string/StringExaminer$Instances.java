/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.examination.string.StringExaminer
 */
package net.kyori.examination.string;

import net.kyori.examination.string.StringExaminer;

private static final class StringExaminer.Instances {
    static final StringExaminer SIMPLE_ESCAPING = new StringExaminer(StringExaminer.access$000());

    private StringExaminer.Instances() {
    }
}
