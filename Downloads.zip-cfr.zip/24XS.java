/*
 * Decompiled with CFR 0.152.
 */
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

public class 24XS {
    private static final DecimalFormatSymbols \u0105rBq;
    public static long CRACKME_f9713106_109f_42ea_83b5_ffb4cf973170_2f86d7a0 = 6112876433476098084L;
    private static String[] CRACKME_BITCH;

    /*
     * Unable to fully structure code
     */
    public static String h_4UABwP3uGOOmhd(int var0) {
        block22: {
            block24: {
                block19: {
                    block23: {
                        block20: {
                            block21: {
                                if (24XS.CRACKME_f9713106_109f_42ea_83b5_ffb4cf973170_2f86d7a0 == (-5164568056025565998L == -5164568056025565997L ? 511977649297977046L : -1569218996386468616L ^ -8594633297367598736L)) {
                                    if (((-5365712771541104328L == -5365712771541104327L ? -964951099 : -1810057968 ^ 1628801445) ^ -244679232 - 1902804417) != 0) {
                                        267347435 ^ 267347434;
                                    }
                                } else {
                                    -1892455076 ^ -1892455076;
                                }
                                -143075001 ^ -1425331274;
                                v0 = 2310962011552490784L == 2310962011552490785L ? 871667150 : -1584175971 ^ -828208427;
                                if (CRACKME_e62d3315_83f6_4ae4_96e1_13d904289803c184d3c0 >= (-1197979101 ^ -2096988125)) break block20;
                                if (CRACKME_e62d3315_83f6_4ae4_96e1_13d904289803c184d3c0 < (6533552837149501124L == 6533552837149501125L ? 766267678 : 4000000 >>> "\u0000\u0000".length())) break block21;
                                v1 = -7611272614485118479L == -7611272614485118478L ? -991818489 : 1273121896 ^ 1273826856;
                                v2 = 24XS.CRACKME_f9713106_109f_42ea_83b5_ffb4cf973170_2f86d7a0;
                                if (true) ** GOTO lbl45
                            }
                            if (CRACKME_e62d3315_83f6_4ae4_96e1_13d904289803c184d3c0 < 4000 >>> "\u0000\u0000".length()) break block22;
                            break block23;
                        }
                        v3 = 24XS.CRACKME_f9713106_109f_42ea_83b5_ffb4cf973170_2f86d7a0;
                        block8: while (true) {
                            switch ((int)v3) {
                                case -1791813596: {
                                    break block8;
                                }
                                case -455694960: {
                                    v3 = (9164148871397816904L >>> "\u0000\u0000".length()) / (2229599135187915472L >>> "\u0000\u0000".length());
                                    continue block8;
                                }
                            }
                            break;
                        }
                        return 24XS.q3sLhnZHmqdA0fWD(CRACKME_e62d3315_83f6_4ae4_96e1_13d904289803c184d3c0, -1664014168 ^ -1488199000, (char)(-943976337 ^ -943976403));
                        block9: while (true) {
                            v2 = v4 / (-2756860157947838780L ^ -7929023547758642773L);
lbl45:
                            // 2 sources

                            switch ((int)v2) {
                                case -1791813596: {
                                    break block9;
                                }
                                case -1745443610: {
                                    if (6000403597995369942L == 6000403597995369943L) {
                                        v4 = 821294218071394645L;
                                        continue block9;
                                    }
                                    v4 = 4149954487526143317L ^ 429580314512934553L;
                                    continue block9;
                                }
                            }
                            break;
                        }
                        return 24XS.q3sLhnZHmqdA0fWD(CRACKME_e62d3315_83f6_4ae4_96e1_13d904289803c184d3c0, v1, (char)(-1667162817 ^ -1667162766));
                    }
                    v5 = 4000 >>> "\u0000\u0000".length();
                    while (true) {
                        if ((v6 = (cfr_temp_0 = 24XS.CRACKME_f9713106_109f_42ea_83b5_ffb4cf973170_2f86d7a0 - (3558313879996060214L - 3809798199760509147L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                        if (v6 == (-1197037942 ^ -1197037941)) {
                            v7 = 24XS.q3sLhnZHmqdA0fWD(CRACKME_e62d3315_83f6_4ae4_96e1_13d904289803c184d3c0, v5, (char)(270144501 ^ 270144446));
                            if (2506489398798930461L == 2506489398798930462L) {
                                break;
                            }
                            break block19;
                        }
                        v6 = -1652080725 - -160304219;
                    }
                    v8 = 1756925687;
                    break block24;
                }
                v8 = -485611235 ^ -1201556618;
            }
            return v7;
        }
        while (true) {
            if ((v9 = (cfr_temp_1 = 24XS.CRACKME_f9713106_109f_42ea_83b5_ffb4cf973170_2f86d7a0 - (6821966725903609272L ^ 1920371749485225471L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v9 == (1686664091 ^ 1686664090)) {
                return Integer.toString(CRACKME_e62d3315_83f6_4ae4_96e1_13d904289803c184d3c0);
            }
            v9 = -179690680 ^ -1078020698;
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     */
    public 24XS() {
        24XS CRACKME_4ab8d8bd_2acb_40fd_97da_46f224ca8a8cbf9a5a61;
        long l = 1708146334709325520L >>> "\u0000\u0000".length();
        if (CRACKME_f9713106_109f_42ea_83b5_ffb4cf973170_2f86d7a0 == l) {
            int n = 752001682 - -1395481965;
            if ((-490540672 >>> "\u0000\u0000".length() ^ n) != 0) {
                int cfr_ignored_1 = 0x50AB6DF4 ^ 0x50AB6DF5;
            }
        } else {
            int cfr_ignored_2 = 0x3A73E5D ^ 0x3A73E5D;
        }
        int n = -810078612 - -1694329074;
        long l2 = CRACKME_f9713106_109f_42ea_83b5_ffb4cf973170_2f86d7a0;
        boolean bl = true;
        block6: while (true) {
            long l3;
            if (!bl || (bl = false) || !true) {
                long l4 = 2769988853297544449L - -3513649609102709749L;
                l2 = l3 / l4;
            }
            switch ((int)l2) {
                case -1791813596: {
                    break block6;
                }
                case 1482951999: {
                    l3 = -4503835214819607117L - -5965246364377730500L;
                    continue block6;
                }
                case 1592677743: {
                    l3 = 0xA07C13D6F7FE869EL ^ 0x653D2B080B59769AL;
                    continue block6;
                }
                case 1873434553: {
                    l3 = 0x33A093BC535D723EL ^ 0xCF2783C20A5B5821L;
                    continue block6;
                }
            }
            break;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        24XS.CRACKME_BITCH = new String[5];
        24XS.CRACKME_BITCH[0] = "\u2500\u2500\u2500\u2500\u2500\u2500\u2584\u258c\u2590\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u200b\u2580\u2580\u2580\u2580\u2580\u2580\u258c";
        24XS.CRACKME_BITCH[1] = "\u2500\u2500\u2500\u2584\u2584\u2588\u2588\u258c\u2588 BEEP BEEP";
        24XS.CRACKME_BITCH[2] = "\u2584\u2584\u2584\u258c\u2590\u2588\u2588\u258c\u2588 GAY PORN DELIVERY";
        24XS.CRACKME_BITCH[3] = "\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u258c\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u200b\u2584\u2584\u2584\u2584\u2584\u2584\u258c";
        24XS.CRACKME_BITCH[4] = "\u2580(@)\u2580\u2580\u2580\u2580\u2580\u2580\u2580(@)(@)\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u200b\u2580\u2580\u2580\u2580(@)\u2580";
        if (24XS.CRACKME_f9713106_109f_42ea_83b5_ffb4cf973170_2f86d7a0 == -8538487058286738668L >>> "\u0000\u0000".length()) {
            if ((671845186 - 730850771 ^ (-26070896 ^ -2121412753)) != 0) {
                -1486747649 ^ -1486747650;
            }
        } else {
            744187220 ^ 744187220;
        }
        737478252 - -1910311733;
        while (true) {
            block11: {
                if ((v0 = (cfr_temp_0 = 24XS.CRACKME_f9713106_109f_42ea_83b5_ffb4cf973170_2f86d7a0 - (7731981798330070745L ^ -7073389180974232293L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (v0 != (1578533028 ^ 1578533029)) break block11;
                v1 = new DecimalFormatSymbols();
                v2 = 24XS.CRACKME_f9713106_109f_42ea_83b5_ffb4cf973170_2f86d7a0;
                if (true) ** GOTO lbl39
            }
            v0 = 1145188983 - 1652608949;
        }
        block6: while (true) {
            v2 = v3 / (910246015349866037L == 910246015349866038L ? -2561181821778446880L : -2893119933720451860L ^ 8498900376240918873L);
lbl39:
            // 2 sources

            switch ((int)v2) {
                case -1791813596: {
                    break block6;
                }
                case -703071944: {
                    v3 = 2948705958541568630L ^ 157741393756932356L;
                    continue block6;
                }
                case 1141081472: {
                    v3 = 4581764511673701714L ^ 1907542583769458389L;
                    continue block6;
                }
            }
            break;
        }
        24XS.\u0105rBq = v1;
    }

    /*
     * Unable to fully structure code
     */
    private static String q3sLhnZHmqdA0fWD(int var0, int var1_1, char var2_2) {
        block57: {
            block58: {
                if (24XS.CRACKME_f9713106_109f_42ea_83b5_ffb4cf973170_2f86d7a0 == -836726578418562974L - 6751346391291424715L) {
                    1429412694 ^ 1429412695;
                } else {
                    1533252464 ^ 1533252464;
                }
                CRACKME_0431efac_f192_4abe_92e4_bfe04cd61380b4edfd6c = (double)CRACKME_0431efac_f192_4abe_92e4_bfe04cd6138048c0322b / (double)CRACKME_0431efac_f192_4abe_92e4_bfe04cd6138032ad61b9;
                var7_4 = new byte[-1534143296 ^ -1534143292];
                v0 = -1882864102 ^ -1882864076;
                var7_4[1198253988 ^ 1198253989] = v0;
                v1 = 1321863207 ^ 1321863204;
                var7_4[v1] = -552594737 ^ -552594775;
                var7_4[1488233166 ^ 1488233164] = -1425224448 ^ -1425224398;
                v2 = -843146572 ^ -843146572;
                v3 = 64524198 ^ 64524163;
                var7_4[v2] = v3;
                v4 = new String(var7_4, "UTF-8");
                v5 = new Object[-248817452 ^ -248817451];
                -1600389335 ^ 1647413117;
                v6 = 24XS.CRACKME_f9713106_109f_42ea_83b5_ffb4cf973170_2f86d7a0;
                if (true) ** GOTO lbl42
                block44: while (true) {
                    v6 = (-1705640533461291577L - 9067537305156181267L) / v7;
lbl42:
                    // 2 sources

                    switch ((int)v6) {
                        case -1791813596: {
                            break block44;
                        }
                        case 348600407: {
                            v7 = 9144796165855463240L ^ 787483139594971808L;
                            continue block44;
                        }
                    }
                    break;
                }
                v5[-73168603 ^ -73168603] = CRACKME_0431efac_f192_4abe_92e4_bfe04cd61380b4edfd6c;
                v8 = 24XS.CRACKME_f9713106_109f_42ea_83b5_ffb4cf973170_2f86d7a0;
                if (true) ** GOTO lbl54
                block45: while (true) {
                    v8 = v9 / (-263360755443577411L ^ -5688277520497796862L);
lbl54:
                    // 2 sources

                    switch ((int)v8) {
                        case -1791813596: {
                            break block45;
                        }
                        case 1690267333: {
                            v9 = -5215544504960008831L ^ -4322483765661570520L;
                            continue block45;
                        }
                        case 1876760726: {
                            v9 = 6209316136692393880L ^ -3574868814162627420L;
                            continue block45;
                        }
                    }
                    break;
                }
                var5_5 = String.format(v4, v5);
                v10 = -863129823 ^ 764008715;
                var7_4 = new byte[-835745736 ^ -835745733];
                var7_4[-2050891839 ^ -2050891837] = -24918160 ^ -24918208;
                v11 = 1754838586 ^ 1754838586;
                var7_4[v11] = -974391729 ^ -974391711;
                var7_4[691159654 ^ 691159655] = -1202328195 ^ -1202328243;
                v12 = new String(var7_4, "UTF-8");
                v13 = 24XS.CRACKME_f9713106_109f_42ea_83b5_ffb4cf973170_2f86d7a0;
                if (true) ** GOTO lbl82
                block46: while (true) {
                    v13 = v14 / (-1571450953572751882L ^ -5367561300185837918L);
lbl82:
                    // 2 sources

                    switch ((int)v13) {
                        case -1791813596: {
                            break block46;
                        }
                        case -1136347501: {
                            v14 = -5997357297986265860L - 9034164054701394397L;
                            continue block46;
                        }
                        case 596573541: {
                            v14 = -4862273090890071268L >>> "\u0000\u0000".length();
                            continue block46;
                        }
                        case 656362658: {
                            v14 = 1128658004166396706L - -2154875901228020281L;
                            continue block46;
                        }
                    }
                    break;
                }
                if (!CRACKME_0431efac_f192_4abe_92e4_bfe04cd613808649d7c6.endsWith(v12)) break block58;
                v15 = 24XS.CRACKME_f9713106_109f_42ea_83b5_ffb4cf973170_2f86d7a0;
                if (true) ** GOTO lbl115
            }
            var7_4 = new byte[927051948 ^ 927051949];
            v16 = -130180762 ^ -130180778;
            var7_4[-1218641418 ^ -1218641418] = v16;
            v17 = new String(var7_4, "UTF-8");
            1374570913 - -1437366550;
            v18 = 24XS.CRACKME_f9713106_109f_42ea_83b5_ffb4cf973170_2f86d7a0;
            if (true) ** GOTO lbl144
            block47: while (true) {
                v15 = v19 / (-8245125012497321194L - -1777098054854448L);
lbl115:
                // 2 sources

                switch ((int)v15) {
                    case -1791813596: {
                        break block47;
                    }
                    case -730839042: {
                        v19 = -2930877758227556976L - -3742476335857755718L;
                        continue block47;
                    }
                    case -114684810: {
                        v19 = 611644510354674442L - -6116622988165271992L;
                        continue block47;
                    }
                    case 1911539350: {
                        v19 = 5187528973494001216L ^ -4333572493298892619L;
                        continue block47;
                    }
                }
                break;
            }
            v20 = CRACKME_0431efac_f192_4abe_92e4_bfe04cd613808649d7c6.length() - (-990214287 ^ -990214286);
            while (true) {
                v21 = 1271489965083110662L ^ -7442289227126277929L;
                cfr_temp_0 = 24XS.CRACKME_f9713106_109f_42ea_83b5_ffb4cf973170_2f86d7a0 - v21;
                v22 = cfr_temp_0 == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1);
                if (v22 == false) continue;
                if (v22 == (1577094557 ^ 1577094556)) {
                    CRACKME_0431efac_f192_4abe_92e4_bfe04cd613808649d7c6 = CRACKME_0431efac_f192_4abe_92e4_bfe04cd613808649d7c6.substring(-679184455 ^ -679184455, v20);
                    break block57;
                }
                v22 = 1828237932 >>> "\u0000\u0000".length();
            }
            block49: while (true) {
                v23 = 8373348165371742558L ^ -4919098032139621735L;
                v18 = v24 / v23;
lbl144:
                // 2 sources

                switch ((int)v18) {
                    case -2146713983: {
                        v24 = -2174711614785169661L ^ 6012004154038745792L;
                        continue block49;
                    }
                    case -1791813596: {
                        break block49;
                    }
                    case -255601231: {
                        v24 = -6731017098524024105L - 5903492733659494995L;
                        continue block49;
                    }
                    case 232978591: {
                        v24 = 912677959974186100L ^ 7984651345232842859L;
                        continue block49;
                    }
                }
                break;
            }
            if (!CRACKME_0431efac_f192_4abe_92e4_bfe04cd613808649d7c6.endsWith(v17)) break block57;
            v25 = 24XS.CRACKME_f9713106_109f_42ea_83b5_ffb4cf973170_2f86d7a0;
            if (true) ** GOTO lbl168
            block50: while (true) {
                v26 = 4998664075483560773L - 7494123964827186467L;
                v25 = v27 / v26;
lbl168:
                // 2 sources

                switch ((int)v25) {
                    case -1791813596: {
                        break block50;
                    }
                    case -955666252: {
                        v27 = 5220654159800090124L >>> "\u0000\u0000".length();
                        continue block50;
                    }
                    case 1058109771: {
                        v27 = 7120633471098457857L ^ -9047454391662539125L;
                        continue block50;
                    }
                    case 1919135976: {
                        v27 = 6868378919831493561L ^ -977432579811922030L;
                        continue block50;
                    }
                }
                break;
            }
            CRACKME_0431efac_f192_4abe_92e4_bfe04cd613808649d7c6 = CRACKME_0431efac_f192_4abe_92e4_bfe04cd613808649d7c6.substring(-912587955 ^ -912587955, CRACKME_0431efac_f192_4abe_92e4_bfe04cd613808649d7c6.length() - (-442634585 ^ -442634586));
        }
        -1170362344 ^ -460996079;
        while (true) {
            block59: {
                v28 = 860054926099748409L ^ -3408821920232393002L;
                cfr_temp_1 = 24XS.CRACKME_f9713106_109f_42ea_83b5_ffb4cf973170_2f86d7a0 - v28;
                v29 = cfr_temp_1 == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1);
                if (v29 == false) continue;
                if (v29 != (1487847501 ^ 1487847500)) break block59;
                814405660 ^ -1445666700;
                v30 = 24XS.CRACKME_f9713106_109f_42ea_83b5_ffb4cf973170_2f86d7a0;
                if (true) ** GOTO lbl211
            }
            v29 = 714035276 ^ 2044021490;
        }
        block52: while (true) {
            v30 = v31 / (-8924345304939239755L ^ 4952651799975359254L);
lbl211:
            // 2 sources

            switch ((int)v30) {
                case -1791813596: {
                    break block52;
                }
                case -108546821: {
                    v31 = 713248541459797015L - -5841527658559411706L;
                    continue block52;
                }
                case 720260891: {
                    v31 = -5948010015485520975L - 599308964129897565L;
                    continue block52;
                }
                case 1268285500: {
                    v31 = 586778161478549322L - -6820356857846160373L;
                    continue block52;
                }
            }
            break;
        }
        v32 = 154265927 ^ -528787622;
        v33 = new StringBuilder().append(CRACKME_0431efac_f192_4abe_92e4_bfe04cd613808649d7c6).append((char)CRACKME_0431efac_f192_4abe_92e4_bfe04cd613806a4788ce);
        -1296620728 >>> "\u0000\u0000".length();
        v34 = 24XS.CRACKME_f9713106_109f_42ea_83b5_ffb4cf973170_2f86d7a0;
        if (true) ** GOTO lbl242
        block53: while (true) {
            v34 = v35 / (-5692209234677302292L ^ -1031845084692624411L);
lbl242:
            // 2 sources

            switch ((int)v34) {
                case -1791813596: {
                    return v33.toString();
                }
                case -1185106661: {
                    v35 = -8518026918000446134L ^ 1387156476619908227L;
                    continue block53;
                }
                case 1437926764: {
                    v35 = 8917623585865879008L ^ 7944753583437502915L;
                    continue block53;
                }
            }
            break;
        }
        return v33.toString();
    }

    /*
     * Handled impossible loop by adding 'first' condition
     */
    public static String mQJP1GRBa3RQGgTq(double d) {
        double CRACKME_9f175dea_39f0_489b_a39f_9fd347281cb2a6ffe82e;
        if (CRACKME_f9713106_109f_42ea_83b5_ffb4cf973170_2f86d7a0 == (0x39D5C8BD2F72A6B3L ^ 0xDF2D0B25A6A54187L)) {
            int cfr_ignored_3 = 0xC491855B ^ 0xC491855A;
        } else {
            int cfr_ignored_4 = 0x1A2A85C7 ^ 0x1A2A85C7;
        }
        if (CRACKME_9f175dea_39f0_489b_a39f_9fd347281cb2a6ffe82e == 0.0) {
            byte[] byArray = new byte[0x1B161B7F ^ 0x1B161B7E];
            int n = 0x6D98FA76 ^ 0x6D98FA76;
            byArray[n] = 0xDE9A3366 ^ 0xDE9A3356;
            return new String(byArray, "UTF-8");
        }
        int n = 0x4DEA29BE ^ 0xDB2B8887;
        long l = CRACKME_f9713106_109f_42ea_83b5_ffb4cf973170_2f86d7a0;
        boolean bl = true;
        block14: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = (0x49A6D3C81072D66AL ^ 0xDE5ECA70F6FCC7A5L) / l2;
            }
            switch ((int)l) {
                case -1791813596: {
                    break block14;
                }
                case 1946414602: {
                    l2 = 0x49C2C5331432890L ^ 0x9F65E3FF8F5A80A0L;
                    continue block14;
                }
            }
            break;
        }
        \u0105rBq.setGroupingSeparator((char)(0x63E7B2A2 ^ 0x63E7B282));
        int cfr_ignored_5 = 0x6DE7C95 ^ 0xF051DEED;
        long l3 = CRACKME_f9713106_109f_42ea_83b5_ffb4cf973170_2f86d7a0;
        boolean bl2 = true;
        block15: while (true) {
            long l4;
            if (!bl2 || (bl2 = false) || !true) {
                l3 = l4 / (1300859128428335724L >>> "\u0000\u0000".length());
            }
            switch ((int)l3) {
                case -1791813596: {
                    break block15;
                }
                case -676121817: {
                    l4 = -8336591447347587956L - 3046753750485739895L;
                    continue block15;
                }
                case -366485650: {
                    l4 = -5892295097626447948L - 4132934482208612808L;
                    continue block15;
                }
                case 524497357: {
                    l4 = 5223838099734782451L - -8533418006212803602L;
                    continue block15;
                }
            }
            break;
        }
        \u0105rBq.setDecimalSeparator((char)(0x3C6E0971 ^ 0x3C6E095D));
        byte[] byArray = new byte[0xC9372540 ^ 0xC9372548];
        byArray[0xB039AE2B ^ 0xB039AE2B] = 0x71D08DC1 ^ 0x71D08DE2;
        byArray[0x94093495 ^ 0x94093494] = 0xE3A6656D ^ 0xE3A66541;
        byArray[0xDC855D35 ^ 0xDC855D37] = 0x6C190635 ^ 0x6C190616;
        int n2 = 0x8C88AA86 ^ 0x8C88AA80;
        byArray[n2] = 0x40A66328 ^ 0x40A66318;
        byArray[0x54128318 ^ 0x5412831F] = 0x1D36F864 ^ 0x1D36F854;
        int n3 = 0xEB2015BA ^ 0xEB2015BF;
        byArray[n3] = 0xD9BD96A2 ^ 0xD9BD968C;
        byArray[0x88DADBA ^ 0x88DADB9] = 0x62429F2A ^ 0x62429F09;
        byArray[0x69068AE6 ^ 0x69068AE2] = 0xC34E39ED ^ 0xC34E39DD;
        String string = new String(byArray, "UTF-8");
        while (true) {
            long l5 = 1861515324454806627L - 6926887178598686109L;
            long l6 = CRACKME_f9713106_109f_42ea_83b5_ffb4cf973170_2f86d7a0 - l5;
            long l7 = l6 == 0L ? 0 : (l6 < 0L ? -1 : 1);
            if (l7 == false) continue;
            if (l7 == (0xFA814AF1 ^ 0xFA814AF0)) break;
            l7 = 0xDD4AC494 ^ 0x92E3B5A5;
        }
        int cfr_ignored_6 = 0xE7F66E45 ^ 0x421CF5A1;
        DecimalFormat CRACKME_9f175dea_39f0_489b_a39f_9fd347281cb27b93424e = new DecimalFormat(string, \u0105rBq);
        long l8 = CRACKME_f9713106_109f_42ea_83b5_ffb4cf973170_2f86d7a0;
        block17: while (true) {
            switch ((int)l8) {
                case -1887740122: {
                    l8 = (287740129145895058L - 4467620382984392657L) / (-1475916734831613245L - 4211616546182447327L);
                    continue block17;
                }
                case -1791813596: {
                    return CRACKME_9f175dea_39f0_489b_a39f_9fd347281cb27b93424e.format(CRACKME_9f175dea_39f0_489b_a39f_9fd347281cb2a6ffe82e);
                }
            }
            break;
        }
        return CRACKME_9f175dea_39f0_489b_a39f_9fd347281cb27b93424e.format(CRACKME_9f175dea_39f0_489b_a39f_9fd347281cb2a6ffe82e);
    }
}
