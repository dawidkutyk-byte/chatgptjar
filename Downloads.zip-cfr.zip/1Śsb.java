/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.clip.placeholderapi.expansion.PlaceholderExpansion
 *  org.bukkit.OfflinePlayer
 */
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;

public class 1\u015asb
extends PlaceholderExpansion {
    private static String[] CRACKME_BITCH = new String[5];
    protected static long CRACKME_83818b30_b70d_4ed7_be74_d3921e40a139_d94fde88 = 101756856725380861L;

    public String getVersion() {
        if (CRACKME_83818b30_b70d_4ed7_be74_d3921e40a139_d94fde88 == (0x1F47C0B7AFE678A0L ^ 0x8DCE432B38BDF4B3L)) {
            if ((0xA02912C1 ^ 0x5E6C8818 ^ (0x26FBDB5F ^ 0x590424A0)) != 0) {
                int cfr_ignored_0 = 0x674B5FCF ^ 0x674B5FCE;
            }
        } else {
            int cfr_ignored_1 = 0xF6B83F32 ^ 0xF6B83F32;
        }
        byte[] byArray = new byte[0x9C4E12FB ^ 0x9C4E12F8];
        byArray[0x2DA1DBAE ^ 0x2DA1DBAE] = 0x55E3F5E9 ^ 0x55E3F5D8;
        byArray[0x70ADDBA7 ^ 0x70ADDBA5] = 0x401435C3 ^ 0x401435F3;
        byArray[0x170A01BB ^ 0x170A01BA] = 0xEA9CFB7 ^ 0xEA9CF99;
        return new String(byArray, "UTF-8");
    }

    public String getAuthor() {
        if (CRACKME_83818b30_b70d_4ed7_be74_d3921e40a139_d94fde88 == (0x7024B1DEA489F69EL ^ 0xBC19EBED0478CD6FL)) {
            if ((0xCAF95A68 ^ 0xB152931C ^ (0x5A50211B ^ 0x25AFDEE4)) != 0) {
                int cfr_ignored_0 = 0xFE03CC84 ^ 0xFE03CC85;
            }
        } else {
            int cfr_ignored_1 = 0xD9F0D781 ^ 0xD9F0D781;
        }
        byte[] byArray = new byte[-5125050166301015332L == -5125050166301015331L ? -1573670443 : 0x63C24EC3 ^ 0x63C24EC4];
        byArray[0x568F1C6A ^ 0x568F1C6C] = -2969358663455326327L == -2969358663455326326L ? 50335019 : 0xDE77628B ^ 0xDE7762E4;
        byArray[0x1ED07184 ^ 0x1ED07184] = 0x59936439 ^ 0x59936470;
        byArray[2773316118125831239L == 2773316118125831240L ? 1509214340 : 0xCD13CBC2 ^ 0xCD13CBC6] = 5352429076033738847L == 5352429076033738848L ? -1731268553 : 0x1E8D509 ^ 0x1E8D564;
        byArray[0xACB9B2DB ^ 0xACB9B2D8] = 0x5CC81331 ^ 0x5CC81354;
        byArray[-1416915318642440642L == -1416915318642440641L ? 1130417507 : 0xEEA946BC ^ 0xEEA946BD] = 0xA0163EE3 ^ 0xA0163E88;
        byArray[0x292ABA27 ^ 0x292ABA22] = 0xE50AF02B ^ 0xE50AF040;
        byArray[2535092702565226626L == 2535092702565226627L ? 2118579561 : 0x5F410864 ^ 0x5F410866] = 4483992153820507151L == 4483992153820507152L ? 1966996752 : 0xDA316146 ^ 0xDA316128;
        return new String(byArray, "UTF-8");
    }

    public String getIdentifier() {
        if (CRACKME_83818b30_b70d_4ed7_be74_d3921e40a139_d94fde88 == (-4376220198309346056L == -4376220198309346055L ? 1405274354573832829L : 0x485D59FE4E58790CL ^ 0xE41D9F1520CC39A9L)) {
            if ((0x8DBA6756 ^ 0x5D74317 ^ -332776947 - 1814706702) != 0) {
                int cfr_ignored_0 = 0xFF7A0037 ^ 0xFF7A0036;
            }
        } else {
            int n = 5472817974576450081L == 5472817974576450082L ? -1866901451 : 0xF20C10F5 ^ 0xF20C10F5;
        }
        int cfr_ignored_1 = -1447322147 - 519049669;
        byte[] byArray = new byte[0xE7E81FBF ^ 0xE7E81FBB];
        byArray[0x425653A3 ^ 0x425653A3] = 0x52C07CE3 ^ 0x52C07C8A;
        byArray[1618045904287288630L == 1618045904287288631L ? -1827033483 : 0xB978F53D ^ 0xB978F53C] = -6690500939815937263L == -6690500939815937262L ? 76757598 : 0xC9707B49 ^ 0xC9707B3D;
        byArray[0x8E96044C ^ 0x8E96044F] = 0xCBA3C342 ^ 0xCBA3C321;
        byArray[0xDC1EC73 ^ 0xDC1EC71] = 0xC4DC1B1A ^ 0xC4DC1B76;
        return new String(byArray, "UTF-8");
    }

    /*
     * Exception decompiling
     */
    public String onRequest(OfflinePlayer var1_1, String var2_2) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.ClassCastException: class org.benf.cfr.reader.bytecode.analysis.parse.statement.GotoStatement cannot be cast to class org.benf.cfr.reader.bytecode.analysis.parse.statement.SwitchStatement (org.benf.cfr.reader.bytecode.analysis.parse.statement.GotoStatement and org.benf.cfr.reader.bytecode.analysis.parse.statement.SwitchStatement are in unnamed module of loader 'app')
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.moveJumpsToTerminalIfEmpty(SwitchReplacer.java:826)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.rebuildSwitches(SwitchReplacer.java:407)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:601)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doClass(Driver.java:84)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:78)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompile(CFRDecompiler.java:89)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompileToZip(CFRDecompiler.java:133)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.decompileSaveAll(ResourceDecompiling.java:261)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.lambda$decompileSaveAll$0(ResourceDecompiling.java:111)
         *     at java.base/java.lang.Thread.run(Thread.java:1575)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    public 1\u015asb() {
        1\u015asb CRACKME_8024e604_ec1d_4718_97a0_2b9619d84690e393e714;
        if (CRACKME_83818b30_b70d_4ed7_be74_d3921e40a139_d94fde88 == (-5004202514593986082L == -5004202514593986081L ? 3706353061729786139L : 748391879161243898L - 2702767400673544487L)) {
            if ((-1671092926 - 668114175 ^ (0xA960CD5 ^ 0x7569F32A)) != 0) {
                int n = -3262136063281087250L == -3262136063281087249L ? 1531148157 : 0x458A0D8F ^ 0x458A0D8E;
            }
        } else {
            int n = -5655384634582067562L == -5655384634582067561L ? -1550012038 : 0xE41C2328 ^ 0xE41C2328;
        }
        int cfr_ignored_0 = -1672725298 - -1662444013;
    }

    static {
        1\u015asb.CRACKME_BITCH[0] = "\u2500\u2500\u2500\u2500\u2500\u2500\u2584\u258c\u2590\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u200b\u2580\u2580\u2580\u2580\u2580\u2580\u258c";
        1\u015asb.CRACKME_BITCH[1] = "\u2500\u2500\u2500\u2584\u2584\u2588\u2588\u258c\u2588 BEEP BEEP";
        1\u015asb.CRACKME_BITCH[2] = "\u2584\u2584\u2584\u258c\u2590\u2588\u2588\u258c\u2588 GAY PORN DELIVERY";
        1\u015asb.CRACKME_BITCH[3] = "\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u258c\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u200b\u2584\u2584\u2584\u2584\u2584\u2584\u258c";
        1\u015asb.CRACKME_BITCH[4] = "\u2580(@)\u2580\u2580\u2580\u2580\u2580\u2580\u2580(@)(@)\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u200b\u2580\u2580\u2580\u2580(@)\u2580";
    }
}
