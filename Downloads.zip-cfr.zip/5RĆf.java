/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  D9jI
 */
public class 5R\u0106f {
    final /* synthetic */ D9jI Q12\u0106;
    static long CRACKME_76bb8ace_b5e7_4989_9fa6_82a97565dcad_9d4465d8 = -7633736257801103774L;
    private static String[] CRACKME_BITCH = new String[10];
    public int pSSs;
    public String iYjD;
    public String[] Xr\u0106\u0141;

    static {
        5R\u0106f.CRACKME_BITCH[0] = "....................../\u00b4\u00af/)";
        5R\u0106f.CRACKME_BITCH[1] = "....................,/\u00af../....................";
        5R\u0106f.CRACKME_BITCH[2] = ".................../..../....................";
        5R\u0106f.CRACKME_BITCH[3] = "............./\u00b4\u00af/'...'/\u00b4\u00af\u00af`\u00b7\u00b8....................";
        5R\u0106f.CRACKME_BITCH[4] = "........../'/.../..../......./\u00a8\u00af\\....................";
        5R\u0106f.CRACKME_BITCH[5] = "........('(...\u00b4...\u00b4.... \u00af~/'...')....................";
        5R\u0106f.CRACKME_BITCH[6] = ".........\\.................'...../....................";
        5R\u0106f.CRACKME_BITCH[7] = "..........''...\\.......... _.\u00b7\u00b4....................";
        5R\u0106f.CRACKME_BITCH[8] = "............\\..............(....................";
        5R\u0106f.CRACKME_BITCH[9] = "..............\\.............\\.......................";
    }

    /*
     * WARNING - void declaration
     */
    public 5R\u0106f(D9jI d9jI) {
        if (CRACKME_76bb8ace_b5e7_4989_9fa6_82a97565dcad_9d4465d8 == (-343340736272631273L == -343340736272631272L ? -6605583223650127784L : 0xD69AC15B3652504DL ^ 0xE735BE72C0AD55DL)) {
            if ((0xC1D2A6C ^ 0x7ECA4185 ^ -555435799 - 1592047850) != 0) {
                int n = -7788208514698154407L == -7788208514698154406L ? -2070594590 : 0x5D6A5DE4 ^ 0x5D6A5DE5;
            }
        } else {
            int cfr_ignored_1 = 0xEF602CD8 ^ 0xEF602CD8;
        }
        int cfr_ignored_2 = 0x171D6D4E ^ 0x35C45640;
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = CRACKME_76bb8ace_b5e7_4989_9fa6_82a97565dcad_9d4465d8 - (0x91615727BEEB3E4AL ^ 0x16AAEF8ACC5A977CL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0x585A8C0A ^ 0x585A8C0B)) {
                5R\u0106f CRACKME_84bd69f6_8abb_41ce_a6bb_bc1ddba2c0a4a404bee3;
                void CRACKME_84bd69f6_8abb_41ce_a6bb_bc1ddba2c0a4dcfb9498;
                CRACKME_84bd69f6_8abb_41ce_a6bb_bc1ddba2c0a4a404bee3.Q12\u0106 = CRACKME_84bd69f6_8abb_41ce_a6bb_bc1ddba2c0a4dcfb9498;
                return;
            }
            if (-7753907734627012924L == -7753907734627012923L) {
                l2 = 1761376169;
                continue;
            }
            l2 = 0x599B28D6 ^ 0xDB431EAC;
        }
    }
}
