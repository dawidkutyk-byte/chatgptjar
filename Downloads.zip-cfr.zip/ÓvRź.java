/*
 * Decompiled with CFR 0.152.
 */
/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class \u00d3vR\u017a {
    public String \u0142W\u015aq;
    public final int 5w\u0105\u0106;
    private static String[] CRACKME_BITCH = new String[10];
    public int N\u0142d\u0105;
    public final int kSX0;
    private static long CRACKME_395b8fbe_7063_428f_ac80_96c59b186905_563d8768 = -3278888489608670198L;

    static {
        \u00d3vR\u017a.CRACKME_BITCH[0] = "....................../\u00b4\u00af/)";
        \u00d3vR\u017a.CRACKME_BITCH[1] = "....................,/\u00af../....................";
        \u00d3vR\u017a.CRACKME_BITCH[2] = ".................../..../....................";
        \u00d3vR\u017a.CRACKME_BITCH[3] = "............./\u00b4\u00af/'...'/\u00b4\u00af\u00af`\u00b7\u00b8....................";
        \u00d3vR\u017a.CRACKME_BITCH[4] = "........../'/.../..../......./\u00a8\u00af\\....................";
        \u00d3vR\u017a.CRACKME_BITCH[5] = "........('(...\u00b4...\u00b4.... \u00af~/'...')....................";
        \u00d3vR\u017a.CRACKME_BITCH[6] = ".........\\.................'...../....................";
        \u00d3vR\u017a.CRACKME_BITCH[7] = "..........''...\\.......... _.\u00b7\u00b4....................";
        \u00d3vR\u017a.CRACKME_BITCH[8] = "............\\..............(....................";
        \u00d3vR\u017a.CRACKME_BITCH[9] = "..............\\.............\\.......................";
    }

    /*
     * WARNING - void declaration
     */
    public \u00d3vR\u017a(int n, String string, int n2) {
        void CRACKME_3c71fb67_7227_4962_93bc_db330e11f7bccccec66d;
        \u00d3vR\u017a CRACKME_3c71fb67_7227_4962_93bc_db330e11f7bc803b6a37;
        if (CRACKME_395b8fbe_7063_428f_ac80_96c59b186905_563d8768 == 1674410168209322512L >>> "\u0000\u0000".length()) {
            if ((1755573901 - -58010034 ^ -1481803568 - 665680081) != 0) {
                int n3 = 3575762606186819278L == 3575762606186819279L ? -1434740903 : 0x2AA1EC1E ^ 0x2AA1EC1F;
            }
        } else {
            int cfr_ignored_2 = 0xF8708763 ^ 0xF8708763;
        }
        int cfr_ignored_3 = -1105362989 - 1778684662;
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = CRACKME_395b8fbe_7063_428f_ac80_96c59b186905_563d8768 - (3492699451006603610L - -7402112510410453090L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x4814C844 ^ 0x4814C845)) break;
            l2 = 530365317 - -167114159;
        }
        CRACKME_3c71fb67_7227_4962_93bc_db330e11f7bc803b6a37.5w\u0105\u0106 = CRACKME_3c71fb67_7227_4962_93bc_db330e11f7bccccec66d;
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = CRACKME_395b8fbe_7063_428f_ac80_96c59b186905_563d8768 - (1715081186552305422L - 2427483617427686056L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l3 == (-8980844844030878644L == -8980844844030878643L ? -1146632312 : 0xE47EF5D7 ^ 0x1B810A28)) {
                void CRACKME_3c71fb67_7227_4962_93bc_db330e11f7bc812950bf;
                void CRACKME_3c71fb67_7227_4962_93bc_db330e11f7bcb71cb6de;
                CRACKME_3c71fb67_7227_4962_93bc_db330e11f7bc803b6a37.\u0142W\u015aq = CRACKME_3c71fb67_7227_4962_93bc_db330e11f7bcb71cb6de;
                CRACKME_3c71fb67_7227_4962_93bc_db330e11f7bc803b6a37.kSX0 = CRACKME_3c71fb67_7227_4962_93bc_db330e11f7bc812950bf;
                return;
            }
            l3 = 0x7F3EA4BD ^ 0x3E627208;
        }
    }
}
