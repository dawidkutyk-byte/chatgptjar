/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  a\u0106\u0105j
 *  org.bukkit.Bukkit
 *  org.bukkit.scheduler.BukkitRunnable
 *  zNb\u015b
 */
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitRunnable;

class U\u015a\u017b\u0105
extends BukkitRunnable {
    final /* synthetic */ String \u015b3A\u0104;
    public static long CRACKME_0f366b5d_13fc_463d_b764_d48586cb6d16_c9121a28 = 7123090120820367291L;
    private int RSdb;
    private final int mH\u0106v = 5;
    private static String[] CRACKME_BITCH = new String[15];
    final /* synthetic */ zNb\u015b ed9X;

    /*
     * Unable to fully structure code
     */
    public void run() {
        block49: {
            if (U\u015a\u017b\u0105.CRACKME_0f366b5d_13fc_463d_b764_d48586cb6d16_c9121a28 == (-4288426944037277236L == -4288426944037277235L ? -4725039375295202830L : 7097878800236288996L >>> "\u0000\u0000".length())) {
                if ((1696563992 ^ -1446167767 ^ (1567158159 ^ 580325488)) != 0) {
                    v0 = -9209276822910050919L == -9209276822910050918L ? -396295357 : 1312383595 ^ 1312383594;
                }
            } else {
                -489794570 ^ -489794570;
            }
            while (true) {
                if ((v1 = (cfr_temp_0 = U\u015a\u017b\u0105.CRACKME_0f366b5d_13fc_463d_b764_d48586cb6d16_c9121a28 - (6977208481933887364L ^ -2204206141686336724L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v1 == (547942321 ^ 547942320)) {
                    if (CRACKME_c3a4ae7a_ff4e_4075_a86a_3717ee7de83c44fec90f.RSdb >= (-889440422 ^ -889440417)) {
                        break;
                    }
                    break block49;
                }
                v1 = 1266014184 ^ -1536989283;
            }
            v2 = 7198009236081066142L == 7198009236081066143L ? -1489080351 : -1490108159 ^ 264237411;
            while (true) {
                if ((v3 = (cfr_temp_1 = U\u015a\u017b\u0105.CRACKME_0f366b5d_13fc_463d_b764_d48586cb6d16_c9121a28 - (-1529091771273127093L == -1529091771273127092L ? -805761698522816264L : 3884689157445359872L - -4933942791162251394L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v3 == -359401091 - -359401090) {
                    CRACKME_c3a4ae7a_ff4e_4075_a86a_3717ee7de83c44fec90f.cancel();
                    return;
                }
                v3 = -1657372493 ^ -2004212530;
            }
        }
        var1_1 = -5506770382157215057L == -5506770382157215056L ? -331498009 : -1452248875 ^ -1452248875;
        while (true) {
            block52: {
                v4 = U\u015a\u017b\u0105.CRACKME_0f366b5d_13fc_463d_b764_d48586cb6d16_c9121a28;
                if (true) ** GOTO lbl44
                block28: while (true) {
                    v4 = v5 / (-2287006391990419206L == -2287006391990419205L ? -1967514290588567131L : 6335026803475734966L ^ -968654179323433433L);
lbl44:
                    // 2 sources

                    switch ((int)v4) {
                        case -1567121477: {
                            break block28;
                        }
                        case -290556269: {
                            v5 = -8352802737741302914L - -3145906306367761880L;
                            continue block28;
                        }
                        case 2033609956: {
                            v5 = 1631189002892002460L - -1746614959987224700L;
                            continue block28;
                        }
                    }
                    break;
                }
                v6 = 2776653688816353517L == 2776653688816353518L ? -150441122 : -370319796 ^ 9377349;
                if (CRACKME_c3a4ae7a_ff4e_4075_a86a_3717ee7de83cea61de15 >= a\u0106\u0105j.HOxR.length) {
                    if (-4129023536826100603L == -4129023536826100602L) {
                        v7 = -1495531421;
                        break;
                    }
                    v7 = -1640508649 - 1064733542;
                    break;
                }
                CRACKME_c3a4ae7a_ff4e_4075_a86a_3717ee7de83c85b83274 = a\u0106\u0105j.HOxR[CRACKME_c3a4ae7a_ff4e_4075_a86a_3717ee7de83cea61de15];
                v8 = Bukkit.getServer();
                while (true) {
                    block51: {
                        if ((v9 = (cfr_temp_2 = U\u015a\u017b\u0105.CRACKME_0f366b5d_13fc_463d_b764_d48586cb6d16_c9121a28 - (-5153299952407459912L ^ 3564400330261590685L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                        if (v9 != (1001672090 ^ 1001672091)) break block51;
                        v10 = v8.getPluginManager();
                        v11 = U\u015a\u017b\u0105.CRACKME_0f366b5d_13fc_463d_b764_d48586cb6d16_c9121a28;
                        if (true) ** GOTO lbl81
                    }
                    if (-4740158555717774049L == -4740158555717774048L) {
                        v9 = 569226080;
                        continue;
                    }
                    v9 = -1658444943 - 1202171137;
                }
                block30: while (true) {
                    v11 = v12 / (-1413745906138262783L ^ -6439843465642379196L);
lbl81:
                    // 2 sources

                    switch ((int)v11) {
                        case -1917210046: {
                            v12 = 5512338544983257128L >>> "\u0000\u0000".length();
                            continue block30;
                        }
                        case -1567121477: {
                            break block30;
                        }
                        case 238062247: {
                            if (-1022608828058194240L == -1022608828058194239L) {
                                v12 = 3930497996270985707L;
                                continue block30;
                            }
                            v12 = -6514770379543594304L ^ -7284965452480759752L;
                            continue block30;
                        }
                        case 1293764691: {
                            if (5878967296740873584L == 5878967296740873585L) {
                                v12 = -1201358090560088460L;
                                continue block30;
                            }
                            v12 = -4115420165794289244L >>> "\u0000\u0000".length();
                            continue block30;
                        }
                    }
                    break;
                }
                CRACKME_c3a4ae7a_ff4e_4075_a86a_3717ee7de83ccc90922f = v10.getPlugin(CRACKME_c3a4ae7a_ff4e_4075_a86a_3717ee7de83c85b83274);
                v13 = CRACKME_c3a4ae7a_ff4e_4075_a86a_3717ee7de83c44fec90f.\u015b3A\u0104;
                v14 = -5670489970121850279L == -5670489970121850278L ? 995199834 : -338245808 ^ 24247398;
                v15 = U\u015a\u017b\u0105.CRACKME_0f366b5d_13fc_463d_b764_d48586cb6d16_c9121a28;
                if (true) ** GOTO lbl113
                block31: while (true) {
                    v15 = v16 / (-7923451205523215060L == -7923451205523215059L ? -5759118926278015408L : 7366865627306202007L - -5775053206772818353L);
lbl113:
                    // 2 sources

                    switch ((int)v15) {
                        case -1567121477: {
                            break block31;
                        }
                        case 1303551370: {
                            if (794145371863807496L == 794145371863807497L) {
                                v16 = 938901487724684276L;
                                continue block31;
                            }
                            v16 = 6052393042435435283L ^ -6206326076654997673L;
                            continue block31;
                        }
                    }
                    break;
                }
                if (CRACKME_c3a4ae7a_ff4e_4075_a86a_3717ee7de83c85b83274.equals(v13)) break block52;
                if (CRACKME_c3a4ae7a_ff4e_4075_a86a_3717ee7de83ccc90922f == null || !CRACKME_c3a4ae7a_ff4e_4075_a86a_3717ee7de83ccc90922f.isEnabled()) break block52;
                v17 = 7310164825536016328L == 7310164825536016329L ? -803064733 : 723792079 ^ 1017833676;
                v18 = U\u015a\u017b\u0105.CRACKME_0f366b5d_13fc_463d_b764_d48586cb6d16_c9121a28;
                if (true) ** GOTO lbl138
                block32: while (true) {
                    v18 = v19 / (1036572667776928834L - 3079945818007242530L);
lbl138:
                    // 2 sources

                    switch ((int)v18) {
                        case -1567121477: {
                            break block32;
                        }
                        case -1417556448: {
                            if (1814437899868106965L == 1814437899868106966L) {
                                v19 = -4037559369525875861L;
                                continue block32;
                            }
                            v19 = -4824328599688401140L - -203566939204930725L;
                            continue block32;
                        }
                        case -830020865: {
                            if (-6893482905399401743L == -6893482905399401742L) {
                                v19 = -1351250610702962727L;
                                continue block32;
                            }
                            v19 = 300495794283953490L ^ 6897329117882022959L;
                            continue block32;
                        }
                        case 901040173: {
                            if (4308592303725912575L == 4308592303725912576L) {
                                v19 = 8979728904046745949L;
                                continue block32;
                            }
                            v19 = 5329701822315691620L ^ 7908736339543774852L;
                            continue block32;
                        }
                    }
                    break;
                }
                Bukkit.getServer().getPluginManager().disablePlugin(CRACKME_c3a4ae7a_ff4e_4075_a86a_3717ee7de83ccc90922f);
            }
            -1149371414 ^ 255698460;
            ++CRACKME_c3a4ae7a_ff4e_4075_a86a_3717ee7de83cea61de15;
        }
        v20 = CRACKME_c3a4ae7a_ff4e_4075_a86a_3717ee7de83c44fec90f.RSdb + (-1697840410948456460L == -1697840410948456459L ? -1661381835 : -731636151 ^ -731636152);
        v21 = U\u015a\u017b\u0105.CRACKME_0f366b5d_13fc_463d_b764_d48586cb6d16_c9121a28;
        block33: while (true) {
            switch ((int)v21) {
                case -1567121477: {
                    break block33;
                }
                case -1425629143: {
                    v21 = (-8680789894162694202L ^ 9085656117003257707L) / (1676659541394048209L ^ 7646029176029940281L);
                    continue block33;
                }
            }
            break;
        }
        CRACKME_c3a4ae7a_ff4e_4075_a86a_3717ee7de83c44fec90f.RSdb = v20;
    }

    static {
        U\u015a\u017b\u0105.CRACKME_BITCH[0] = "\u2282_\u30fd";
        U\u015a\u017b\u0105.CRACKME_BITCH[1] = "\u3000 \uff3c\uff3c\u3000\u3000\u3000";
        U\u015a\u017b\u0105.CRACKME_BITCH[2] = "\u3000\u3000 \uff3c( \u0361\u00b0 \u035c\u0296 \u0361\u00b0)\u3000\u3000\u3000";
        U\u015a\u017b\u0105.CRACKME_BITCH[3] = "\u3000\u3000\u3000 >\u3000\u2312\u30fd\u3000\u3000\u3000";
        U\u015a\u017b\u0105.CRACKME_BITCH[4] = "\u3000\u3000\u3000/ \u3000 \u3078\uff3c\u3000\u3000\u3000";
        U\u015a\u017b\u0105.CRACKME_BITCH[5] = "\u3000\u3000 /\u3000\u3000/\u3000\uff3c\uff3c\u3000\u3000\u3000";
        U\u015a\u017b\u0105.CRACKME_BITCH[6] = "\u3000\u3000 \uff9a\u3000\u30ce\u3000\u3000 \u30fd_\u3064\u3000\u3000\u3000";
        U\u015a\u017b\u0105.CRACKME_BITCH[7] = "\u3000\u3000/\u3000/\u3000\u3000\u3000";
        U\u015a\u017b\u0105.CRACKME_BITCH[8] = "\u3000 /\u3000/|\u3000\u3000\u3000";
        U\u015a\u017b\u0105.CRACKME_BITCH[9] = "\u3000(\u3000(\u30fd\u3000\u3000\u3000";
        U\u015a\u017b\u0105.CRACKME_BITCH[10] = "\u3000|\u3000|\u3001\uff3c\u3000\u3000\u3000";
        U\u015a\u017b\u0105.CRACKME_BITCH[11] = "\u3000| \u4e3f \uff3c \u2312)\u3000\u3000\u3000";
        U\u015a\u017b\u0105.CRACKME_BITCH[12] = "\u3000| |\u3000\u3000) /\u3000\u3000\u3000";
        U\u015a\u017b\u0105.CRACKME_BITCH[13] = "\u30ce )\u3000\u3000L\uff89\u3000\u3000\u3000";
        U\u015a\u017b\u0105.CRACKME_BITCH[14] = "(_\uff0f\u3000\u3000\u3000\u3000\u3000\u3000";
    }

    /*
     * WARNING - void declaration
     */
    U\u015a\u017b\u0105(zNb\u015b zNb\u015b2, String string) {
        U\u015a\u017b\u0105 CRACKME_d4f141d7_449f_49c8_a2ab_6cf7a0cdc5ec5484b44f;
        void CRACKME_d4f141d7_449f_49c8_a2ab_6cf7a0cdc5ec6a67f821;
        if (CRACKME_0f366b5d_13fc_463d_b764_d48586cb6d16_c9121a28 == (-3806117824199607477L == -3806117824199607476L ? -6003628419097621415L : 5933962713159252789L - 4636459551592358638L)) {
            if ((0x7541CC12 ^ 0x3B560C28 ^ (0xFECCD8B6 ^ 0x81332749)) != 0) {
                int cfr_ignored_2 = 0x759D38E3 ^ 0x759D38E2;
            }
        } else {
            int n = 1672386694021915922L == 1672386694021915923L ? 330708896 : 0xE387E27B ^ 0xE387E27B;
        }
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = CRACKME_0f366b5d_13fc_463d_b764_d48586cb6d16_c9121a28 - (0x87CBC68B42C6E6CEL ^ 0xC952AF13FFCA0F89L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x145B2BC5 ^ 0x145B2BC4)) break;
            l2 = -23734371 - -1072977942;
        }
        CRACKME_d4f141d7_449f_49c8_a2ab_6cf7a0cdc5ec5484b44f.ed9X = CRACKME_d4f141d7_449f_49c8_a2ab_6cf7a0cdc5ec6a67f821;
        CRACKME_d4f141d7_449f_49c8_a2ab_6cf7a0cdc5ec5484b44f.\u015b3A\u0104 = string;
        CRACKME_d4f141d7_449f_49c8_a2ab_6cf7a0cdc5ec5484b44f.RSdb = 0x51DBB8BF ^ 0x51DBB8BF;
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = CRACKME_0f366b5d_13fc_463d_b764_d48586cb6d16_c9121a28 - (9047409979283685054L == 9047409979283685055L ? 8190751346097427462L : -4077008257400353853L - 989371666743997533L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l3 == (0xFCD3EA5E ^ 0xFCD3EA5F)) {
                CRACKME_d4f141d7_449f_49c8_a2ab_6cf7a0cdc5ec5484b44f.mH\u0106v = 0xD970C7F8 ^ 0xD970C7FD;
                return;
            }
            l3 = 0x6B4FD281 ^ 0x9787CE08;
        }
    }
}
