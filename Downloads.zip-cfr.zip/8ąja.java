/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  24XS
 *  DRHn
 *  e4wV
 *  org.bukkit.plugin.Plugin
 *  zNb\u015b
 *  \u00d3vR\u017a
 *  \u017b\u017c\u0107m
 */
import java.lang.invoke.LambdaMetafactory;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import org.bukkit.plugin.Plugin;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class 8\u0105ja {
    private static long CG\u0142o;
    private static long CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c = 6348460786073741580L;
    public static final Map<Integer, String> \u0118\u01790F;
    public static final Map<Integer, String> \u0119\u0107\u017cV;
    public static final Map<String, Map<Integer, String>> \u017bxh\u0143;
    public static final Map<Integer, Double> \u01189\u0107\u0105;
    public static final Map<Integer, Integer> ENMJ;
    private static String[] CRACKME_BITCH;
    public static final Map<String, Map<Integer, Integer>> \u0107\u017ceK;
    public static final Map<Integer, Integer> t9\u0142U;
    public static Map<String, \u00d3vR\u017a> \u0142Dzn;
    public static final Map<Integer, String> \u0119X\u01431;
    private static final long \u00f3cCm = 5000L;

    /*
     * Handled impossible loop by adding 'first' condition
     */
    public 8\u0105ja() {
        8\u0105ja CRACKME_e91fb931_167d_4bbb_994e_896eaab9d22734bc810d;
        if (CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == (0x89AA6211A0E8DBDL ^ 0xDCB4C986B9037779L)) {
            int cfr_ignored_1 = 0x2B2982BF ^ 0x2B2982BE;
        } else {
            int n = 0x45F1BD1F ^ 0x45F1BD1F;
        }
        long l = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        boolean bl = true;
        block5: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x795595CFD10062FEL ^ 0x3DA0387940CF7D4CL);
            }
            switch ((int)l) {
                case -1735791685: {
                    l2 = -3542123042474160352L - -2826289589016322507L;
                    continue block5;
                }
                case -1665319458: {
                    l2 = 0xE5A05C0BCD7FDAECL ^ 0xADB1167B2585D92CL;
                    continue block5;
                }
                case 141306124: {
                    break block5;
                }
            }
            break;
        }
    }

    /*
     * Unable to fully structure code
     */
    public static String Fhxj3t2DKd3GrXRn(String var0) {
        if (8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == -2821440608631044429L - 1200416022319166911L) {
            if ((469229460 >>> "\u0000\u0000".length() ^ -1147930147 - 999553502) != 0) {
                v0 = -3872188092575690830L == -3872188092575690829L ? -1945463498 : -1844366084 ^ -1844366083;
            }
        } else {
            854782523 ^ 854782523;
        }
        v1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl15
        block16: while (true) {
            v1 = v2 / (6718697529559331796L == 6718697529559331797L ? -5387570865273867L : 7425156700487896113L ^ -4561361557272979374L);
lbl15:
            // 2 sources

            switch ((int)v1) {
                case 141306124: {
                    break block16;
                }
                case 650341458: {
                    v2 = 2747265239289591508L >>> "\u0000\u0000".length();
                    continue block16;
                }
                case 1770987408: {
                    v2 = 3954841064427544551L ^ 8529256770721480387L;
                    continue block16;
                }
            }
            break;
        }
        438465718 - -1244693776;
        if (8\u0105ja.\u0142Dzn == null) {
            return null;
        }
        v3 = CRACKME_e7021c81_ebfd_4590_b2ef_caaf5240df2311b69c4f.trim();
        while (true) {
            if ((v4 = (cfr_temp_0 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-5677014181055268136L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v4 == (493386558 ^ 493386559)) break;
            v4 = 1615470278 - -240353608;
        }
        v5 = v3.toLowerCase();
        538413471 ^ 1069278978;
        var3_1 = new byte[2074169639 ^ 2074169638];
        var3_1[1048084197 ^ 1048084197] = 1321561273 ^ 1321561241;
        v6 = new String(var3_1, "UTF-8");
        var3_1 = new byte[1518484199 ^ 1518484198];
        var3_1[1799070855 ^ 1799070855] = 1105212959 ^ 1105212978;
        v7 = new String(var3_1, "UTF-8");
        while (true) {
            if ((v8 = (cfr_temp_1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (738415742495406840L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v8 == (-343322097 ^ -343322098)) break;
            if (3273035203302929165L == 3273035203302929166L) {
                v8 = -619069108;
                continue;
            }
            v8 = -444599981 ^ 1667470991;
        }
        CRACKME_e7021c81_ebfd_4590_b2ef_caaf5240df23ea62a6ba = v5.replace(v6, v7);
        while (true) {
            if ((v9 = (cfr_temp_2 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (1575550319575115946L - 8703481485562813268L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v9 == (-955702121 ^ -955702122)) break;
            v9 = -1307710670 ^ 181865846;
        }
        while (true) {
            block34: {
                if ((v10 = (cfr_temp_3 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-6272450333646551949L ^ 298839583421178130L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v10 != (1133548652 ^ 1133548653)) break block34;
                v11 = 8\u0105ja.\u0142Dzn.values();
                v12 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl75
            }
            v10 = -1669763830 ^ -541029652;
        }
        block21: while (true) {
            v12 = v13 / (361034427513277030L ^ -3187773566799453075L);
lbl75:
            // 2 sources

            switch ((int)v12) {
                case -1171006580: {
                    v13 = 1466331568213852251L ^ 2959157855332615377L;
                    continue block21;
                }
                case -407262035: {
                    v13 = 6138303228864933207L ^ 1238905802738141239L;
                    continue block21;
                }
                case 141306124: {
                    break block21;
                }
                case 660229872: {
                    if (-3921014755111099360L == -3921014755111099359L) {
                        v13 = -7408825133080595789L;
                        continue block21;
                    }
                    v13 = 6481061058358625910L ^ -1185559856187634937L;
                    continue block21;
                }
            }
            break;
        }
        v14 = v11.stream();
        while (true) {
            block35: {
                if ((v15 = (cfr_temp_4 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (5221984955352701954L ^ -4886646565062089897L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v15 != (882905635 ^ 882905634)) break block35;
                v16 = v14.map((Function<\u00d3vR\u017a, String>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, BvJk0G9_NbgSZphb(\u00d3vR\u017a ), (L\u00d3vR\u017a;)Ljava/lang/String;)());
                v17 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl102
            }
            v15 = 16561278 - -1859981129;
        }
        block23: while (true) {
            v17 = v18 / (6146084009066250001L ^ 1524235468240035360L);
lbl102:
            // 2 sources

            switch ((int)v17) {
                case 141306124: {
                    break block23;
                }
                case 293314148: {
                    v18 = 1346926524411352549L ^ -1359500385074116768L;
                    continue block23;
                }
                case 1921606852: {
                    v18 = 1774540120007674909L ^ -5399058409574497052L;
                    continue block23;
                }
            }
            break;
        }
        v19 = (Predicate<String>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Z, wqiqXJfNJJeGSNMZ(java.lang.String java.lang.String ), (Ljava/lang/String;)Z)((String)CRACKME_e7021c81_ebfd_4590_b2ef_caaf5240df23ea62a6ba);
        while (true) {
            if ((v20 = (cfr_temp_5 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (4166651999200685624L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v20 == (1820209525 ^ 1820209524)) break;
            v20 = 1245838807 - -1312905843;
        }
        v21 = v16.filter(v19).findFirst();
        while (true) {
            if ((v22 = (cfr_temp_6 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (1300645088825382972L == 1300645088825382973L ? 9037366747450988596L : -7864212326072166355L - -2534858796206153021L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v22 == (1206730937 ^ 1206730936)) {
                517054815 - 1508153844;
                return v21.orElse(null);
            }
            if (-9174557477803264645L == -9174557477803264644L) {
                v22 = 1352571964;
                continue;
            }
            v22 = -1031163549 - 1054124968;
        }
    }

    /*
     * Exception decompiling
     */
    private static void e0u__HzQOcgTkM1m(String var0, Map<Integer, String> var1_1, Map<Integer, Integer> var2_2) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 36[SWITCH]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doClass(Driver.java:84)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:78)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompile(CFRDecompiler.java:89)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompileToZip(CFRDecompiler.java:133)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.decompileSaveAll(ResourceDecompiling.java:261)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.lambda$decompileSaveAll$0(ResourceDecompiling.java:111)
         *     at java.base/java.lang.Thread.run(Thread.java:1575)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Unable to fully structure code
     */
    public static String GwIpmMpWfV3HusXk(String var0) {
        if (8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == 6558457362367544999L - -4534397664672293619L) {
            if ((-1686305595 ^ 1010189584 ^ (5978810568647617108L == 5978810568647617109L ? -790122967 : 150638346 ^ 1996845301)) != 0) {
                -517493655 ^ -517493656;
            }
        } else {
            v0 = 6570064995483759678L == 6570064995483759679L ? -2003263305 : 95870031 ^ 95870031;
        }
        8\u0105ja.zsjN3N7fF6D1WUzb();
        v1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl18
        block38: while (true) {
            v1 = v2 / (-7858708108700491313L ^ -847751112096064149L);
lbl18:
            // 2 sources

            switch ((int)v1) {
                case -623481234: {
                    if (-556127339690142554L == -556127339690142553L) {
                        v2 = 8054921854007304838L;
                        continue block38;
                    }
                    v2 = 109099414263252564L >>> "\u0000\u0000".length();
                    continue block38;
                }
                case 141306124: {
                    break block38;
                }
                case 473424755: {
                    if (-1545078230744728414L == -1545078230744728413L) {
                        v2 = 7864552428619298970L;
                        continue block38;
                    }
                    v2 = 2354914725063674515L ^ -972795010736855338L;
                    continue block38;
                }
                case 813932792: {
                    if (-230165264114613415L == -230165264114613414L) {
                        v2 = 5792615736002452972L;
                        continue block38;
                    }
                    v2 = 8524860510829831099L - -691728494579092982L;
                    continue block38;
                }
            }
            break;
        }
        v3 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl43
        block39: while (true) {
            v3 = v4 / (1549926885669710132L - -789473606331073034L);
lbl43:
            // 2 sources

            switch ((int)v3) {
                case -2061310059: {
                    v4 = 4720773237089646382L ^ 4895432738848141729L;
                    continue block39;
                }
                case -1049217927: {
                    v4 = -8600252404740992314L ^ 1089708326120280281L;
                    continue block39;
                }
                case 141306124: {
                    break block39;
                }
                case 2043225493: {
                    v4 = -6874443516710331631L ^ 7135576029254563017L;
                    continue block39;
                }
            }
            break;
        }
        var1_1 = 8\u0105ja.\u0119\u0107\u017cV.entrySet().iterator();
        block40: while (true) {
            block59: {
                -1719064583 - -1282557923;
                -218200025 ^ 1113644610;
                if (!var1_1.hasNext()) break block59;
                v5 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl84
            }
            var4_4 = new byte[-14245497 ^ -14245502];
            var4_4[-309632981 ^ -309632981] = 1673265095 - 1673265157;
            var4_4[-1849057090 ^ -1849057092] = 280691380365055301L == 280691380365055302L ? 459046380 : 751799732 ^ 751799767;
            var4_4[237411339 ^ 237411336] = -1873643114 ^ -1873643077;
            var4_4[1801185093 ^ 1801185092] = -2096060226 ^ 2096060185;
            var4_4[258620542 ^ 258620538] = -1020800880 ^ -1020800835;
            return new String(var4_4, "UTF-8");
            block41: while (true) {
                v5 = v6 / (-2259179936272371260L >>> "\u0000\u0000".length());
lbl84:
                // 2 sources

                switch ((int)v5) {
                    case -967062493: {
                        v6 = -2119477810544711300L ^ 9006581014162756663L;
                        continue block41;
                    }
                    case 141306124: {
                        break block41;
                    }
                    case 697895181: {
                        v6 = -2887608182887976495L - -489107386958349844L;
                        continue block41;
                    }
                    case 1011719615: {
                        v6 = 4569760420381586618L ^ -1987411271503604909L;
                        continue block41;
                    }
                }
                break;
            }
            -673446068 - 1743691763;
            CRACKME_fd92da59_2cbb_4948_9590_cefbad529b10b8596926 = var1_1.next();
            -305848284 ^ 1015056724;
            v7 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
            if (true) ** GOTO lbl116
            block42: while (true) {
                v7 = v8 / (6093061924871430781L == 6093061924871430782L ? 3233384402766107425L : 6171645248646959989L ^ -7244714112665119732L);
lbl116:
                // 2 sources

                switch ((int)v7) {
                    case 141306124: {
                        break block42;
                    }
                    case 642715428: {
                        v8 = -5154232649387577521L ^ 1911881411832610473L;
                        continue block42;
                    }
                    case 1221613978: {
                        v8 = 6834170072704652439L - 912128576121420123L;
                        continue block42;
                    }
                }
                break;
            }
            while (true) {
                if ((v9 = (cfr_temp_0 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-5777913028304342925L ^ 6257269740339770371L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (v9 == (-2925804015984824002L == -2925804015984824001L ? -1121213337 : -592157525 ^ -592157526)) {
                    if (!CRACKME_fd92da59_2cbb_4948_9590_cefbad529b10b8596926.getValue().equalsIgnoreCase(CRACKME_fd92da59_2cbb_4948_9590_cefbad529b10eb6d1333)) continue block40;
                    break block40;
                }
                v9 = -241560536 ^ -949216966;
            }
            break;
        }
        while (true) {
            block60: {
                if ((v10 = (cfr_temp_1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (6943369675907140383L - 8342960294110130122L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (v10 != (25817006 ^ 25817007)) break block60;
                v11 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl153
            }
            if (7048978016392269488L == 7048978016392269489L) {
                v10 = 2007664471;
                continue;
            }
            v10 = 1399303483 ^ -312088147;
        }
        block45: while (true) {
            v11 = v12 / (-2625454880694151287L ^ -7728813975460478463L);
lbl153:
            // 2 sources

            switch ((int)v11) {
                case -1081802524: {
                    v12 = 4012304296897591657L ^ -2418152712368503129L;
                    continue block45;
                }
                case 141306124: {
                    break block45;
                }
                case 1233985833: {
                    if (-1371787009445842170L == -1371787009445842169L) {
                        v12 = -4858197565060202164L;
                        continue block45;
                    }
                    v12 = 5504294087895867922L - -3374966283436571032L;
                    continue block45;
                }
            }
            break;
        }
        v13 = new StringBuilder();
        var4_3 = new byte[-220604851 ^ -220604852];
        var4_3[1974761649 ^ 1974761649] = -2112736555 ^ -2112736522;
        v14 = new String(var4_3, "UTF-8");
        v15 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl174
        block46: while (true) {
            v15 = v16 / (8001994484658075202L == 8001994484658075203L ? 2711979039019730123L : -4734125942034922728L ^ 2665014331596188324L);
lbl174:
            // 2 sources

            switch ((int)v15) {
                case 141306124: {
                    break block46;
                }
                case 479763162: {
                    v16 = 7722491956827812159L ^ -8877211059347724367L;
                    continue block46;
                }
                case 1463712493: {
                    v16 = -7059520045224905836L - -3581034617906810491L;
                    continue block46;
                }
            }
            break;
        }
        v17 = v13.append(v14).append(CRACKME_fd92da59_2cbb_4948_9590_cefbad529b10b8596926.getKey());
        v18 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl195
        block47: while (true) {
            v18 = v19 / (3864414333174331952L == 3864414333174331953L ? -8773034439371143973L : 504527042816345812L ^ -4321477475580831621L);
lbl195:
            // 2 sources

            switch ((int)v18) {
                case -911485529: {
                    v19 = 4129304186795725498L ^ 6817364470227391887L;
                    continue block47;
                }
                case -593377438: {
                    v19 = -3957273883350958724L - -4290987518009612437L;
                    continue block47;
                }
                case 141306124: {
                    break block47;
                }
            }
            break;
        }
        return v17.toString();
    }

    /*
     * Unable to fully structure code
     */
    public static String syKKtWt6COX6s6KG(int var0) {
        if (8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == (-4514025755191188352L ^ -8349738499350445061L)) {
            if (((-5286070959077494268L == -5286070959077494267L ? 1660272213 : -779150345 ^ -136243) ^ (5411101887627675577L == 5411101887627675578L ? 1123860390 : 225195162 - -1922288485)) != 0) {
                -288731721 ^ -288731722;
            }
        } else {
            1777299189 ^ 1777299189;
        }
        v0 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl16
        block25: while (true) {
            v0 = v1 / (1418012489226112848L ^ -8245405738029528325L);
lbl16:
            // 2 sources

            switch ((int)v0) {
                case -1789227613: {
                    v1 = 8979193295553401820L >>> "\u0000\u0000".length();
                    continue block25;
                }
                case 141306124: {
                    break block25;
                }
                case 1436165104: {
                    v1 = 347547998936419252L ^ -7994976297233104469L;
                    continue block25;
                }
            }
            break;
        }
        8\u0105ja.zsjN3N7fF6D1WUzb();
        while (true) {
            block38: {
                if ((v2 = (cfr_temp_0 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-1065295915029992131L == -1065295915029992130L ? 6251817396412567904L : -1215175912142731727L ^ -6346583239538012143L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (v2 != (-330379477 ^ -330379478)) break block38;
                v3 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl38
            }
            v2 = -2101478835 - 1510886057;
        }
        block27: while (true) {
            v3 = v4 / (-8197868026172451412L == -8197868026172451411L ? 2154903243697129812L : -4276112825150990300L ^ 8869246448291298788L);
lbl38:
            // 2 sources

            switch ((int)v3) {
                case 21674175: {
                    v4 = -7829442755305349853L - 8922444937187321312L;
                    continue block27;
                }
                case 141306124: {
                    break block27;
                }
                case 1772245514: {
                    v4 = -1019042582195652756L ^ 3131822733370676126L;
                    continue block27;
                }
            }
            break;
        }
        v5 = CRACKME_3d12befb_1a45_40d1_a8f7_6b9d7e5af4705b01219c;
        31390688 - 100496886;
        v6 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl56
        block28: while (true) {
            v6 = v7 / (-858326733872446287L == -858326733872446286L ? 6953563679036515595L : 4069240306913708322L ^ -3518318255295788922L);
lbl56:
            // 2 sources

            switch ((int)v6) {
                case -418205924: {
                    v7 = 8908456235737330235L ^ -8985343026161485048L;
                    continue block28;
                }
                case 141306124: {
                    break block28;
                }
                case 327371084: {
                    v7 = -6058160696407169355L ^ 5491470265802833415L;
                    continue block28;
                }
                case 1748752011: {
                    v7 = -417497797887698486L - -503657794271130159L;
                    continue block28;
                }
            }
            break;
        }
        var1_1 = 8\u0105ja.\u0119X\u01431.getOrDefault(v5, null);
        -982136886 - -1947571920;
        if (CRACKME_3d12befb_1a45_40d1_a8f7_6b9d7e5af470c533edf2 == null) {
            var3_2 = new byte[838100114 ^ 838100114];
            return new String(var3_2, "UTF-8");
        }
        while (true) {
            block39: {
                if ((v8 = (cfr_temp_1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (6721152192731208789L == 6721152192731208790L ? -2465286212183331461L : -1729480930998350163L ^ -5103733358069106792L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (v8 != 1703318117 - 1703318118) break block39;
                v9 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl92
            }
            v8 = 1903008768 >>> "\u0000\u0000".length();
        }
        block30: while (true) {
            v9 = v10 / (-5097721376539183549L - 2349795811053067142L);
lbl92:
            // 2 sources

            switch ((int)v9) {
                case 141306124: {
                    break block30;
                }
                case 332499478: {
                    v10 = -6353968460021400602L - -815465446669159248L;
                    continue block30;
                }
                case 332781903: {
                    v10 = -1949398374298030226L - -7158321940628925732L;
                    continue block30;
                }
            }
            break;
        }
        var3_3 = new byte[3673991771753692688L == 3673991771753692689L ? 2078759594 : 1853287285 ^ 1853287294];
        var3_3[1795741440 ^ 1795741450] = -583654419 ^ -583654528;
        var3_3[2638846784820904556L == 2638846784820904557L ? -773091335 : -1087946865 ^ -1087946871] = 5130522153974688746L == 5130522153974688747L ? -1460919323 : -1188936783 ^ -1188936722;
        var3_3[1712201969 ^ 1712201976] = 1085637751746010555L == 1085637751746010556L ? 2140715736 : 1455583746 ^ 1455583843;
        var3_3[483264430401065899L == 483264430401065900L ? 1682720164 : -1691582905 ^ -1691582910] = 1992077634 ^ 1992077615;
        var3_3[1631062265 ^ 1631062270] = 846187172298236172L == 846187172298236173L ? 1609416333 : 931539443 ^ 931539335;
        var3_3[5751685818204106896L == 5751685818204106897L ? -1537048156 : -64331644 ^ -64331643] = -1767390700150656089L == -1767390700150656088L ? -1776849771 : -425906030 ^ -425905945;
        var3_3[1013399860 ^ 1013399862] = 4928041217614724769L == 4928041217614724770L ? -966957034 : -596628313 ^ -596628268;
        var3_3[-981541356 ^ -981541356] = -1928253034 ^ -1928252939;
        var3_3[7301093995526333839L == 7301093995526333840L ? 84829515 : -1959555010 ^ -1959555014] = -1684878560 ^ -1684878513;
        var3_3[7855433628617056622L == 7855433628617056623L ? 1114165264 : -1975379041 ^ -1975379044] = -4493781298116833948L == -4493781298116833947L ? 183888864 : 240158354 ^ 240158438;
        var3_3[-1496154831954310432L == -1496154831954310431L ? 1938861441 : 2061023316 ^ 2061023324] = 2869262199278724976L == 2869262199278724977L ? 1680866980 : -2103560305 ^ -2103560214;
        -1703362646 ^ -773433979;
        v11 = new String(var3_3, "UTF-8") + 8\u0105ja.3c7pwrayAXd-4qg4((String)CRACKME_3d12befb_1a45_40d1_a8f7_6b9d7e5af470c533edf2);
        v12 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        block31: while (true) {
            switch ((int)v12) {
                case 37749129: {
                    v12 = (-1137746011100124710L ^ 1876129010266088354L) / (-3794068630984853191L ^ 1675076915773846322L);
                    continue block31;
                }
                case 141306124: {
                    break block31;
                }
            }
            break;
        }
        return e4wV.2al_94WjzQTnIzkU((String)v11);
    }

    /*
     * Unable to fully structure code
     */
    public static String ashjNM09Yup5pl1Q(int var0) {
        block41: {
            block40: {
                block39: {
                    if (8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == (8542851213713857829L ^ 4963916079132039578L)) {
                        if (((5703978712335761636L == 5703978712335761637L ? -983753723 : -1612651482 ^ 685157648) ^ (6892494472248665549L == 6892494472248665550L ? -431656081 : -901345054 - 1246138595)) != 0) {
                            v0 = 3069178093625322194L == 3069178093625322195L ? 1469780041 : 1470580750 ^ 1470580751;
                        }
                    } else {
                        -1895648156 ^ -1895648156;
                    }
                    v1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                    if (true) ** GOTO lbl14
                    block17: while (true) {
                        v1 = v2 / (-480744360648563377L ^ -4780620070157920987L);
lbl14:
                        // 2 sources

                        switch ((int)v1) {
                            case -1972918117: {
                                if (-5902904144631432869L == -5902904144631432868L) {
                                    v2 = -6279175734355726799L;
                                    continue block17;
                                }
                                v2 = 2043426810217918004L >>> "\u0000\u0000".length();
                                continue block17;
                            }
                            case -1437443227: {
                                v2 = 7703484119780332297L - -174351451108684961L;
                                continue block17;
                            }
                            case -1117629706: {
                                if (-895652171581212734L == -895652171581212733L) {
                                    v2 = -2516505316925900758L;
                                    continue block17;
                                }
                                v2 = 8539073753969606325L - -1045498041701711875L;
                                continue block17;
                            }
                            case 141306124: {
                                break block17;
                            }
                        }
                        break;
                    }
                    8\u0105ja.zsjN3N7fF6D1WUzb();
                    while (true) {
                        if ((v3 = (cfr_temp_0 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (3176949775218130758L == 3176949775218130759L ? -6606214550175826588L : -3476057511132806373L ^ 3644089328443685423L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                        if (v3 == (-980260805 ^ -980260806)) {
                            var1_1 = 8\u0105ja.\u0118\u01790F.getOrDefault(CRACKME_3c72d792_c159_4e08_87d8_d457bd61ae2f1fe98c57, null);
                            if (CRACKME_3c72d792_c159_4e08_87d8_d457bd61ae2f39ee0079 == null) {
                                break;
                            }
                            break block39;
                        }
                        v3 = 341605926 ^ 1129689683;
                    }
                    var3_2 = new byte[-796075038 ^ -796075038];
                    -1464425845 - 1498747097;
                    1039506524 - 1640495531;
                    return new String(var3_2, "UTF-8");
                }
                1831719560 ^ 483635941;
                1976998594 ^ 2108143611;
                v4 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl86
                block19: while (true) {
                    v4 = v5 / (3620156383895657885L ^ -2141709698206681252L);
lbl86:
                    // 2 sources

                    switch ((int)v4) {
                        case -1128416223: {
                            v5 = -3218273259480796055L ^ -5007176619832840611L;
                            continue block19;
                        }
                        case 141306124: {
                            break block19;
                        }
                        case 570145900: {
                            if (3544967624481571578L == 3544967624481571579L) {
                                v5 = -6092589133121736860L;
                                continue block19;
                            }
                            v5 = 4364029943571224019L ^ 5330367667619300143L;
                            continue block19;
                        }
                        case 1876599451: {
                            if (-5970991212860869661L == -5970991212860869660L) {
                                v5 = 6446368309219134740L;
                                continue block19;
                            }
                            v5 = 3724807667804995256L ^ -5268462304356313686L;
                            continue block19;
                        }
                    }
                    break;
                }
                while (true) {
                    if ((v6 = (cfr_temp_1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (806884206705041970L ^ -6764084958001245274L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                    if (v6 == (587222782 ^ 587222783)) {
                        v7 = new StringBuilder();
                        var3_3 = new byte[1035975815 ^ 1035975820];
                        var3_3[-229460205 ^ -229460197] = -765583980 ^ -765583875;
                        var3_3[846059110 ^ 846059104] = -188149665 ^ -188149760;
                        var3_3[1990379811 ^ 1990379811] = 1956373687 ^ 1956373716;
                        var3_3[1469491795 ^ 1469491799] = -897271173 ^ -897271276;
                        var3_3[-1294609840 ^ -1294609835] = 1757343779 ^ 1757343822;
                        var3_3[-269046454 ^ -269046464] = -1644371657 ^ -1644371645;
                        var3_3[231793093 ^ 231793094] = 190510293 ^ 190510241;
                        if (5862884856791465805L == 5862884856791465806L) {
                            break;
                        }
                        break block40;
                    }
                    v6 = 1519060727 ^ -550839737;
                }
                v8 = 1731591215;
                break block41;
            }
            v8 = -1476212967 ^ -1476212976;
        }
        var3_3[v8] = -2863323686310209264L == -2863323686310209263L ? 563325587 : 276281291 ^ 276281261;
        var3_3[1083844614 ^ 1083844612] = 1133858472 ^ 1133858523;
        var3_3[7882946965726445706L == 7882946965726445707L ? -625167735 : 785470176 ^ 785470183] = 1398528607 ^ 1398528568;
        var3_3[1561230968 ^ 1561230969] = 913540547 ^ 913540534;
        v9 = new String(var3_3, "UTF-8");
        while (true) {
            if ((v10 = (cfr_temp_2 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-6157585765452485155L ^ 7859233398941173047L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v10 == (-482834400 ^ -482834399)) break;
            v10 = -1122673028 - 1302566111;
        }
        v11 = v7.append(v9);
        while (true) {
            block42: {
                if ((v12 = (cfr_temp_3 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (5911482373218222033L - -6842791479577784593L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v12 != (405613418 ^ 405613419)) break block42;
                v13 = 8\u0105ja.gFOWaAfPEoX63PWz((String)CRACKME_3c72d792_c159_4e08_87d8_d457bd61ae2f39ee0079);
                v14 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl152
            }
            if (5987409094915821189L == 5987409094915821190L) {
                v12 = -1381101652;
                continue;
            }
            v12 = -661250342 - -852110929;
        }
        block23: while (true) {
            v14 = v15 / (-3951056914407496075L ^ -2043210898793443201L);
lbl152:
            // 2 sources

            switch ((int)v14) {
                case -730623946: {
                    v15 = 6934185493922939535L - 1590891348950863872L;
                    continue block23;
                }
                case 141306124: {
                    break block23;
                }
                case 853682290: {
                    if (-4289407765286411611L == -4289407765286411610L) {
                        v15 = 863124655316771944L;
                        continue block23;
                    }
                    v15 = -4341032124112007801L ^ 8100489994881022300L;
                    continue block23;
                }
            }
            break;
        }
        v16 = v11.append(v13);
        while (true) {
            if ((v17 = (cfr_temp_4 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-1768521216525941616L ^ 935850771087479269L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v17 == (-1265776163 ^ -1265776164)) {
                return e4wV.2al_94WjzQTnIzkU((String)v16.toString());
            }
            v17 = -1940150112 ^ 1344797042;
        }
    }

    /*
     * Unable to fully structure code
     */
    public static int HhF6UH640jkc43fN(String var0) {
        block39: {
            block37: {
                block38: {
                    block36: {
                        if (8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == (2587159269927146893L ^ 7108265037034139955L)) {
                            if ((419690240 ^ -1229169238 ^ (-273891971 ^ -1873591678)) != 0) {
                                v0 = 2723388072759688069L == 2723388072759688070L ? 1165857725 : -1640791142 ^ -1640791141;
                            }
                        } else {
                            -487755649 ^ -487755649;
                        }
                        1351483982 ^ -924915821;
                        while (true) {
                            if ((v1 = (cfr_temp_0 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-6914299106583007086L - 3592283724865744886L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                            if (v1 == (-2568353451047673085L == -2568353451047673084L ? 1807823288 : -1864848920 ^ 1864848919)) {
                                v2 = zNb\u015b.Y\u017btq.getConfig();
                                var4_1 = new byte[-626303867 ^ -626303858];
                                var4_1[895730041 ^ 895730040] = 1869850941 ^ 1869850964;
                                var4_1[1550485278 ^ 1550485277] = -179306394 ^ -179306478;
                                var4_1[-1065343959 ^ -1065343957] = 564976445 ^ 564976470;
                                if (6235017299459100439L == 6235017299459100440L) {
                                    break;
                                }
                                break block36;
                            }
                            v1 = 1664431504 ^ 655867764;
                        }
                        v3 = 864579970;
                        break block38;
                    }
                    v3 = 1329058953 ^ 1329058947;
                }
                var4_1[v3] = -1088519082 ^ -1088519117;
                var4_1[3467409849861965789L == 3467409849861965790L ? 380909280 : 2131314404 ^ 2131314412] = 2027359740 ^ 2027359645;
                var4_1[704368899 ^ 704368902] = -4132854537869181992L == -4132854537869181991L ? 431769525 : 765273724 ^ 765273623;
                var4_1[-1126765665 ^ -1126765665] = 1104473792917886906L == 1104473792917886907L ? 1387610499 : 1697220884 ^ 1697220960;
                var4_1[810744537 ^ 810744541] = -1847190374 ^ -1847190283;
                var4_1[1728035950 ^ 1728035943] = -442875446 ^ -442875481;
                var4_1[-1964470230 ^ -1964470228] = 1812977496 ^ 1812977415;
                var4_1[-294149139 ^ -294149142] = -303303656 ^ -303303562;
                v4 = new String(var4_1, "UTF-8");
                while (true) {
                    if ((v5 = (cfr_temp_1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (3252569190000732867L == 3252569190000732868L ? 4541680254588474801L : 8782491741074873364L - 8681049018614502557L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                    if (v5 == (-7185207900063547747L == -7185207900063547746L ? 1596246861 : -1079670108 ^ -1079670107)) {
                        v6 = v2.getString(v4);
                        var4_1 = new byte[140953703 ^ 0x866C866];
                        var4_1[1873165301 ^ 1873165301] = 0x3B33B31B ^ 0x3B33B335;
                        v7 = new String(var4_1, "UTF-8");
                        var4_1 = new byte[1285502878 ^ 1285502879];
                        if (1715235041698504830L == 1715235041698504831L) {
                            break;
                        }
                        break block37;
                    }
                    v5 = 259104540 ^ 134320945;
                }
                v8 = -83558847;
                break block39;
            }
            v8 = 1943744906 ^ 1943744906;
        }
        var4_1[v8] = 2039365516 ^ 2039365537;
        v9 = new String(var4_1, "UTF-8");
        while (true) {
            if ((v10 = (cfr_temp_2 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-8477839122535276391L ^ 1359093389938748860L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v10 == (-1716029964677287921L == -1716029964677287920L ? -1811569281 : -1255584425 ^ -1255584426)) break;
            if (829697227077088437L == 829697227077088438L) {
                v10 = 2089138924;
                continue;
            }
            v10 = 1288916772 ^ -1628638284;
        }
        var1_2 = v6.replace(v7, v9);
        -1286013444 ^ -321731664;
        1855345958 ^ 64411256;
        while (true) {
            block40: {
                if ((v11 = (cfr_temp_3 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-4202883713688784806L ^ 6624112714084608893L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v11 != (-2028559581 ^ -2028559582)) break block40;
                v12 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl99
            }
            if (-75922973786946517L == -75922973786946516L) {
                v11 = 1353173228;
                continue;
            }
            v11 = -1491261324 ^ -930888156;
        }
        block21: while (true) {
            v12 = v13 / (-7543275927937817336L - 8269649895619593086L);
lbl99:
            // 2 sources

            switch ((int)v12) {
                case -1911389721: {
                    v13 = 9056154346049993236L >>> "\u0000\u0000".length();
                    continue block21;
                }
                case 141306124: {
                    break block21;
                }
                case 974139797: {
                    v13 = -6598814118850432770L ^ -2063751230528080912L;
                    continue block21;
                }
                case 1578967307: {
                    v13 = -7680613029700315361L ^ 2980600602895334313L;
                    continue block21;
                }
            }
            break;
        }
        var4_1 = new byte[4343952442538448746L == 4343952442538448747L ? 555879573 : -820296977 ^ -820296987];
        var4_1[-2488965978858509863L == -2488965978858509862L ? 984597960 : -1783485947 ^ -1783485949] = -286839959 ^ -286840062;
        var4_1[7008747328630071108L == 7008747328630071109L ? -1971190345 : 942110685 ^ 942110686] = 1713605147 ^ 1713605174;
        var4_1[-435438335 ^ -435438331] = -1843535394397834158L == -1843535394397834157L ? 942579561 : -1066713549 ^ -1066713505;
        var4_1[2938142906914501383L == 2938142906914501384L ? -708169850 : -20985934 ^ -20985933] = -1775398612 ^ -1775398589;
        var4_1[-318407775 ^ -318407768] = -237940337 ^ -237940319;
        var4_1[1257051734 ^ 1257051731] = 202527953 ^ 202527928;
        var4_1[210940639 ^ 210940631] = 346667295 ^ 346667372;
        var4_1[-1430465798 ^ -1430465795] = 5106307869748984665L == 5106307869748984666L ? 952911591 : 1363987173 ^ 1363987072;
        var4_1[1713967077 ^ 1713967077] = -280279345 ^ -280279365;
        var4_1[8517559589883164495L == 8517559589883164496L ? -395821850 : -1642175486 ^ -1642175488] = 1672960349 ^ 1672960301;
        -948544194 ^ 1787470397;
        v14 = new StringBuilder().append(new String(var4_1, "UTF-8")).append((String)CRACKME_45e466a0_61fe_4052_b8af_0be37828eea9399859de);
        var4_1 = new byte[424711359746781058L == 424711359746781059L ? -1860748653 : 580481359 ^ 580481358];
        var4_1[-904580635 ^ -904580635] = -885526842 ^ -885526808;
        v15 = new String(var4_1, "UTF-8");
        -142291853 ^ -2070786533;
        v16 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl139
        block22: while (true) {
            v16 = v17 / (-2733986420654505992L == -2733986420654505991L ? -7997526662041379214L : 2010408433963321767L - -5468077695556592671L);
lbl139:
            // 2 sources

            switch ((int)v16) {
                case -77279951: {
                    v17 = 6579640899355043048L - -2082554320721146992L;
                    continue block22;
                }
                case 141306124: {
                    break block22;
                }
                case 1728625640: {
                    v17 = -3437290953264175085L ^ -6843091900567543147L;
                    continue block22;
                }
            }
            break;
        }
        v18 = -7966442011845136221L == -7966442011845136220L ? -803831002 : 1849291139 ^ 45991019;
        var4_1 = new byte[1526825439 ^ 1526825438];
        var4_1[588085503 ^ 588085503] = -200308170 ^ -200308200;
        v19 = new String(var4_1, "UTF-8");
        var4_1 = new byte[2013529110 ^ 2013529109];
        var4_1[9054139485891485961L == 9054139485891485962L ? -862111021 : 1650404693 ^ 1650404693] = -2133742225 ^ -2133742319;
        var4_1[-1184331770 ^ -1184331769] = -7073026195609767346L == -7073026195609767345L ? -849858104 : -1724654606 ^ -1724654655;
        var4_1[1831967328 ^ 1831967330] = 1972045524666378092L == 1972045524666378093L ? 1518074875 : 1093832590 ^ 1093832688;
        v20 = v14.append(v15).append(CRACKME_45e466a0_61fe_4052_b8af_0be37828eea97a7d2e26.replace(v19, new String(var4_1, "UTF-8")));
        while (true) {
            if ((v21 = (cfr_temp_4 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-82129318148861599L == -82129318148861598L ? 3891838904961079L : -8021939482052290617L ^ 7267505948602125609L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v21 == (2119475222 ^ 2119475223)) break;
            if (-8254176366782265635L == -8254176366782265634L) {
                v21 = 423191874;
                continue;
            }
            v21 = 1700844240 ^ -635117228;
        }
        CRACKME_45e466a0_61fe_4052_b8af_0be37828eea9d5a05f3f = v20.toString();
        while (true) {
            block41: {
                if ((v22 = (cfr_temp_5 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (7877594048748587179L == 7877594048748587180L ? -4389561870309457403L : 4716269917638141878L - -8784154098189849650L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v22 != (-7318826035645951638L == -7318826035645951637L ? -1738562613 : -1392963491 ^ -1392963492)) break block41;
                v23 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl180
            }
            v22 = -700249607 ^ -213127455;
        }
        block25: while (true) {
            v23 = v24 / (-8046492688601625316L == -8046492688601625315L ? 4969755804533890366L : 9125380307338789124L ^ 3362658712686390296L);
lbl180:
            // 2 sources

            switch ((int)v23) {
                case -1053140103: {
                    v24 = 2305228179921933604L >>> "\u0000\u0000".length();
                    continue block25;
                }
                case -554092190: {
                    v24 = 7787743071396712931L ^ -4611281932831370195L;
                    continue block25;
                }
                case 141306124: {
                    break block25;
                }
                case 985572418: {
                    v24 = -8606686841415218753L ^ 7862748276886128834L;
                    continue block25;
                }
            }
            break;
        }
        return \u017b\u017c\u0107m.7\u015aCz.getInt(CRACKME_45e466a0_61fe_4052_b8af_0be37828eea9d5a05f3f, -1602724520 ^ -1602724520);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     */
    private static void zsjN3N7fF6D1WUzb() {
        if (CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == (0xB7574236DD9B0EA8L ^ 0x5E0470A068DBDD3BL)) {
            int cfr_ignored_1 = 0xB378DB5E ^ 0xB378DB5F;
        } else {
            int cfr_ignored_2 = 0x3522246E ^ 0x3522246E;
        }
        long l = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        block9: while (true) {
            switch ((int)l) {
                case -1004902406: {
                    l = (0xFCBEEF363BF9679CL ^ 0x43FECCB8DBD9DA3AL) / (-8315652140095378942L - -4537891220701726122L);
                    continue block9;
                }
                case 141306124: {
                    break block9;
                }
            }
            break;
        }
        long l2 = 0xF58CB315A85DB1BL ^ 0xF58CB315A85C893L;
        if (System.currentTimeMillis() - CG\u0142o > l2) {
            int cfr_ignored_3 = 1679861707 - -5863389;
            long l3 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
            boolean bl = true;
            block10: while (true) {
                long l4;
                if (!bl || (bl = false) || !true) {
                    l3 = l4 / (0x61382EDE885276AL ^ 0xD414EBB0C7B11939L);
                }
                switch ((int)l3) {
                    case 141306124: {
                        break block10;
                    }
                    case 724592439: {
                        l4 = 0x14E94C457D5F7AAL ^ 0xDEB10C982E38EDC0L;
                        continue block10;
                    }
                    case 1995090388: {
                        l4 = 0x93570E79AB92559FL ^ 0x6747A53E7554B953L;
                        continue block10;
                    }
                }
                break;
            }
            8\u0105ja.KiRG_7P2LsN0KTrf();
        }
        int n = 0xA27A26F4 ^ 0xF16CB849;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * WARNING - void declaration
     */
    public static String sskddxtiA85ZjBCI(int n) {
        int CRACKME_d9a66905_7970_4e7a_b8b8_eb2c3632cd281e496cd0;
        if (CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == -7957607286747801260L >>> "\u0000\u0000".length()) {
            int cfr_ignored_3 = 0xE11049B7 ^ 0xE11049B6;
        } else {
            int n2 = 0x740DE7F3 ^ 0x740DE7F3;
        }
        int cfr_ignored_4 = -781434943 - 321193746;
        long l = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        boolean bl = true;
        block9: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                long l3 = 0x655536C21CE9DEF8L ^ 0x7849F5E4A237AB8DL;
                l = l2 / l3;
            }
            switch ((int)l) {
                case -2071732450: {
                    l2 = -7329277982721147534L - -1421816778169405499L;
                    continue block9;
                }
                case 141306124: {
                    break block9;
                }
            }
            break;
        }
        8\u0105ja.zsjN3N7fF6D1WUzb();
        long l4 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        boolean bl2 = true;
        block10: while (true) {
            long l5;
            if (!bl2 || (bl2 = false) || !true) {
                l4 = l5 / (0x54C55525764A50F7L ^ 0xEB1A19514210A827L);
            }
            switch ((int)l4) {
                case 141306124: {
                    break block10;
                }
                case 241775767: {
                    l5 = 3141744892668886704L - -5543135687428124257L;
                    continue block10;
                }
                case 397155329: {
                    l5 = 0x423D6E8028E5DAAL ^ 0x9C5DC87CFA05CCD5L;
                    continue block10;
                }
            }
            break;
        }
        Integer n3 = CRACKME_d9a66905_7970_4e7a_b8b8_eb2c3632cd281e496cd0;
        int cfr_ignored_5 = 1070548540 - -271067173;
        int cfr_ignored_6 = 0xD967E73 ^ 0xC9B8D4E1;
        while (true) {
            long l6 = 7895644589808842309L - -7710563164829488590L;
            long l7 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - l6;
            long l8 = l7 == 0L ? 0 : (l7 < 0L ? -1 : 1);
            if (l8 == false) continue;
            int n4 = 0x9C55C735 ^ 0x9C55C734;
            if (l8 == n4) {
                void CRACKME_d9a66905_7970_4e7a_b8b8_eb2c3632cd28e13ea264;
                String string = \u0119X\u01431.getOrDefault(n3, null);
                if (CRACKME_d9a66905_7970_4e7a_b8b8_eb2c3632cd28e13ea264 == null) break;
                int cfr_ignored_7 = -2135000303 - 196818231;
                return CRACKME_d9a66905_7970_4e7a_b8b8_eb2c3632cd28e13ea264;
            }
            l8 = -1593888793 - 1190343009;
        }
        byte[] byArray = new byte[0xE59BA5AA ^ 0xE59BA5AD];
        int n5 = 0xD83C9CD7 ^ 0xD83C9CD6;
        byArray[n5] = 0x6D36AD9C ^ 0x92C9523B;
        byArray[0x6E6E9DB7 ^ 0x6E6E9DB5] = 0x38D17496 ^ 0x38D174F5;
        byArray[0xA354B2B ^ 0xA354B28] = 0xE6884904 ^ 0xE6884946;
        int n6 = 0xCB5889D0 ^ 0xCB5889D4;
        int n7 = 0x5B0EC87B ^ 0x5B0EC829;
        byArray[n6] = n7;
        byArray[0x86C7C562 ^ 0x86C7C567] = 0x5541E521 ^ 0x5541E560;
        byArray[0xED284B4F ^ 0xED284B49] = 0x893119FA ^ 0x893119B1;
        byArray[0x63ABD3E6 ^ 0x63ABD3E6] = 0xB20E09B1 ^ 0x4DF1F673;
        return new String(byArray, "UTF-8");
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * WARNING - void declaration
     */
    public static String oMlHUhWcbbyYz_zw(String string, int n) {
        void CRACKME_b3524c93_118b_4a4a_bd70_959144f2418db52cb502;
        String CRACKME_b3524c93_118b_4a4a_bd70_959144f2418d5920b7d3;
        if (CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == -5478444521307101407L - 8604339588673451787L) {
            int n2 = 0x20C45675 ^ 0x5F3BA98A;
            if ((0xDA28C503 ^ 0xADDF9562 ^ n2) != 0) {
                int cfr_ignored_4 = 0x417D5856 ^ 0x417D5857;
            }
        } else {
            int cfr_ignored_5 = 0x9034B131 ^ 0x9034B131;
        }
        int cfr_ignored_6 = 0x62BD7C8E ^ 0x7EE8FAEE;
        long l = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        boolean bl = true;
        block6: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0xA6629C7254489960L ^ 0xE6C398C8CF63DACAL);
            }
            switch ((int)l) {
                case -476843394: {
                    l2 = 0x6B3490022CED0362L ^ 0xF1BF569998A45045L;
                    continue block6;
                }
                case -237059335: {
                    l2 = -8989385419119608612L - 3067699954986582790L;
                    continue block6;
                }
                case 141306124: {
                    break block6;
                }
                case 1802583495: {
                    l2 = 0x40BAE4FB8258B041L ^ 0x77DC7C5C02475EC9L;
                    continue block6;
                }
            }
            break;
        }
        8\u0105ja.zsjN3N7fF6D1WUzb();
        String string2 = CRACKME_b3524c93_118b_4a4a_bd70_959144f2418d5920b7d3.toLowerCase();
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (749969982636765411L - -1979375147063668441L)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
            if (l4 == (0x6C1BDD7C ^ 0x6C1BDD7D)) break;
            l4 = -867316492 >>> "\u0000\u0000".length();
        }
        Map map = Collections.emptyMap();
        while (true) {
            long l5 = 6767024619686338485L - -2029518178523289488L;
            long l6 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - l5;
            long l7 = l6 == 0L ? 0 : (l6 < 0L ? -1 : 1);
            if (l7 == false) continue;
            if (l7 == (0x50E85159 ^ 0xAF17AEA6)) break;
            l7 = 0xF1DF7579 ^ 0x5165DF3E;
        }
        Integer n3 = (int)CRACKME_b3524c93_118b_4a4a_bd70_959144f2418db52cb502;
        while (true) {
            long l8 = 0xA36C8E474397D881L ^ 0x3B517D54A53DA6A1L;
            long l9 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - l8;
            long l10 = l9 == 0L ? 0 : (l9 < 0L ? -1 : 1);
            if (l10 == false) continue;
            int n4 = 0x3CECA0F7 ^ 0x3CECA0F6;
            if (l10 == n4) {
                void CRACKME_b3524c93_118b_4a4a_bd70_959144f2418d024eaafe;
                int cfr_ignored_7 = 911101578 - -962736927;
                String string3 = \u017bxh\u0143.getOrDefault(string2, map).getOrDefault(n3, null);
                int cfr_ignored_8 = 698760501 - 1601002871;
                if (CRACKME_b3524c93_118b_4a4a_bd70_959144f2418d024eaafe == null) break;
                int cfr_ignored_9 = 1977124901 - -1499482927;
                return CRACKME_b3524c93_118b_4a4a_bd70_959144f2418d024eaafe;
            }
            l10 = 0x432AF160 ^ 0x2289DFC5;
        }
        byte[] byArray = new byte[0x75BD9F24 ^ 0x75BD9F23];
        byArray[0x8B7FCAC5 ^ 0x8B7FCAC0] = 0x34F1C263 ^ 0x34F1C222;
        int n5 = 0x34B3E255 ^ 0x34B3E217;
        byArray[0x8CB76EC8 ^ 0x8CB76ECB] = n5;
        int n6 = 0x56A31D7A ^ 0x56A31D78;
        byArray[n6] = 0xFB65FCBC ^ 0xFB65FCDF;
        int n7 = 0xE7E67F9F ^ 0xE7E67F9E;
        byArray[n7] = -659146366 - -659146277;
        int n8 = 0x86E9339D ^ 0x86E933D6;
        byArray[0x33C6C7BC ^ 0x33C6C7BA] = n8;
        byArray[0xA9C51FA9 ^ 0xA9C51FA9] = -468912177 - -468912115;
        int n9 = 0xFF32A340 ^ 0xFF32A344;
        byArray[n9] = 0x7472B65B ^ 0x7472B609;
        return new String(byArray, "UTF-8");
    }

    public static String 6FJcVI3mm3tynuJs(int n) {
        byte[] byArray;
        block8: {
            int n2;
            block7: {
                if (CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == (0xF80A09815F22146AL ^ 0x402D19DDB73C1259L)) {
                    if ((0xDF5E8FA0 ^ 0x63534873 ^ (6657802699125640564L == 6657802699125640565L ? 1533559018 : 0xA028B11F ^ 0xDFD74EE0)) != 0) {
                        int n3 = -1590026655555345684L == -1590026655555345683L ? -2040291332 : 0x8C61A553 ^ 0x8C61A552;
                    }
                } else {
                    int cfr_ignored_1 = 0xBC744E1D ^ 0xBC744E1D;
                }
                8\u0105ja.zsjN3N7fF6D1WUzb();
                while (true) {
                    long l;
                    long l2;
                    if ((l2 = (l = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (0xC8E6CFA74BEC49F1L ^ 0xF4387A7D3149FA24L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                        continue;
                    }
                    if (l2 == (0xC8835293 ^ 0xC8835292)) {
                        int CRACKME_17c61701_00e1_40a7_a456_c91859977697df3a7487;
                        String CRACKME_17c61701_00e1_40a7_a456_c91859977697d77dea35 = \u0119\u0107\u017cV.getOrDefault(CRACKME_17c61701_00e1_40a7_a456_c91859977697df3a7487, null);
                        if (CRACKME_17c61701_00e1_40a7_a456_c91859977697d77dea35 != null) return CRACKME_17c61701_00e1_40a7_a456_c91859977697d77dea35;
                        byArray = new byte[0x48048DEF ^ 0x48048DE8];
                        byArray[0x6108EEB ^ 0x6108EED] = 0xC864A1C1 ^ 0xC864A18A;
                        byArray[0x72C71A20 ^ 0x72C71A23] = 0xDAB1857D ^ 0xDAB1853F;
                        if (-6928971674147079873L == -6928971674147079872L) {
                            break;
                        }
                        break block7;
                    }
                    l2 = 1680198282 - 1091383554;
                }
                n2 = -1039016197;
                break block8;
            }
            n2 = 0x3AC7D937 ^ 0x3AC7D937;
        }
        byArray[n2] = 0xFEC22460 ^ 0x13DDBA2;
        byArray[0x89BBBDEE ^ 0x89BBBDEF] = 0x5E12F7D3 ^ 0xA1ED0874;
        byArray[0xCB47BBE8 ^ 0xCB47BBEA] = 0x52EC33AA ^ 0x52EC33C9;
        byArray[0x2235572D ^ 0x22355728] = -5163406526313802641L == -5163406526313802640L ? -598362319 : 0xC790F750 ^ 0xC790F711;
        byArray[0x73E1EE0E ^ 0x73E1EE0A] = 8207686858295856716L == 8207686858295856717L ? -1384915755 : 0xED393E9 ^ 0xED393BB;
        return new String(byArray, "UTF-8");
    }

    /*
     * Handled impossible loop by adding 'first' condition
     */
    public static String 9S5356hGBySIfBGk(int n) {
        String CRACKME_5cf09174_a8b5_406c_930a_bcba5d662940493197d2;
        block29: {
            int CRACKME_5cf09174_a8b5_406c_930a_bcba5d66294099ff5c93;
            if (CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == (0x2F52C4416519EA4AL ^ 0x5C61493147A54019L)) {
                int n2 = 0x7409537 ^ 0x70E5546;
                if ((n2 ^ (0xCC750C9E ^ 0xB38AF361)) != 0) {
                    int n3 = 0x6EF0F2E7 ^ 0x6EF0F2E6;
                }
            } else {
                int cfr_ignored_4 = 0xE345F910 ^ 0xE345F910;
            }
            8\u0105ja.zsjN3N7fF6D1WUzb();
            long l = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
            boolean bl = true;
            block16: while (true) {
                long l2;
                if (!bl || (bl = false) || !true) {
                    l = l2 / (0x497A731244C64135L ^ 0x39F04D9DA2650979L);
                }
                switch ((int)l) {
                    case -1229062236: {
                        l2 = 3595423382579415774L - 2334995211502431030L;
                        continue block16;
                    }
                    case -910476174: {
                        l2 = 0x8E9661B4CEDB9630L ^ 0x1654EC8F8944F12DL;
                        continue block16;
                    }
                    case 141306124: {
                        break block16;
                    }
                    case 1502695942: {
                        l2 = 6608187037026459159L - -2752147213345404696L;
                        continue block16;
                    }
                }
                break;
            }
            long l3 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
            boolean bl2 = true;
            block17: while (true) {
                long l4;
                if (!bl2 || (bl2 = false) || !true) {
                    l3 = l4 / (-1811712289977403788L - -1558383143267631874L);
                }
                switch ((int)l3) {
                    case -1961171143: {
                        l4 = 0x7C741E13C8C46961L ^ 0x2DBD44EFDF747C0DL;
                        continue block17;
                    }
                    case -1444133518: {
                        l4 = -4812385715851891250L - 5504787072765427717L;
                        continue block17;
                    }
                    case 141306124: {
                        break block17;
                    }
                    case 1889421322: {
                        l4 = 3541312437007013709L - -1962057619838250285L;
                        continue block17;
                    }
                }
                break;
            }
            Integer n4 = CRACKME_5cf09174_a8b5_406c_930a_bcba5d66294099ff5c93;
            while (true) {
                long l5;
                long l6;
                if ((l6 = (l5 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (0xD290403EF61153E1L ^ 0x621B1D6DF9CDDB50L)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (l6 == (0x9408E4E3 ^ 0x9408E4E2)) {
                    int cfr_ignored_5 = 0x80A678C ^ 0xEBB0354C;
                    CRACKME_5cf09174_a8b5_406c_930a_bcba5d662940493197d2 = \u0118\u01790F.getOrDefault(n4, null);
                    int cfr_ignored_6 = -245188620 - 1508866549;
                    if (CRACKME_5cf09174_a8b5_406c_930a_bcba5d662940493197d2 == null) {
                        break;
                    }
                    break block29;
                }
                l6 = 609859426 - 543189472;
            }
            int cfr_ignored_7 = 0xAB5B001D ^ 0x58B7C951;
            byte[] byArray = new byte[0x8001C660 ^ 0x8001C667];
            byArray[0xA706ED09 ^ 0xA706ED0C] = 0xBE124F19 ^ 0xBE124F58;
            int n5 = 0xFBA01147 ^ 0xFBA01146;
            byArray[n5] = -1910630651 - -1910630562;
            int n6 = 0x4047C35 ^ 0xFBFB83F7;
            byArray[0x5E419519 ^ 0x5E419519] = n6;
            byArray[0xDE521885 ^ 0xDE521881] = 0x502DD3A8 ^ 0x502DD3FA;
            int n7 = 0xF8C1EBC4 ^ 0xF8C1EBC6;
            int n8 = 0xF2260F4 ^ 0xF226097;
            byArray[n7] = n8;
            int n9 = 0x7EEA87FE ^ 0x7EEA87BC;
            byArray[0x60C28E04 ^ 0x60C28E07] = n9;
            byArray[0x11BBD6BD ^ 0x11BBD6BB] = 0x636FBCF3 ^ 0x636FBCB8;
            return new String(byArray, "UTF-8");
        }
        int n10 = 0x4845387C ^ 0x8F56674B;
        long l = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        boolean bl = true;
        block19: while (true) {
            long l7;
            if (!bl || (bl = false) || !true) {
                l = (0x2A5910BDA1D5DA44L ^ 0x46C8A23906F1BBB1L) / l7;
            }
            switch ((int)l) {
                case -165198152: {
                    l7 = -2508096766651509529L - -850265735963848760L;
                    continue block19;
                }
                case 141306124: {
                    return 8\u0105ja.mrVvLE3h-7jv8HUT(CRACKME_5cf09174_a8b5_406c_930a_bcba5d662940493197d2);
                }
            }
            break;
        }
        return 8\u0105ja.mrVvLE3h-7jv8HUT(CRACKME_5cf09174_a8b5_406c_930a_bcba5d662940493197d2);
    }

    /*
     * Unable to fully structure code
     */
    public static int MDvIWNV_LhA6NH_x(String var0) {
        block37: {
            block33: {
                block36: {
                    block32: {
                        block35: {
                            block31: {
                                block34: {
                                    block30: {
                                        if (8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == (1933266520048073562L ^ 3104984721014010816L)) {
                                            if ((1618264797 - -103350264 ^ (2034665442 ^ 112818205)) != 0) {
                                                -488233429 ^ -488233430;
                                            }
                                        } else {
                                            1547607330 ^ 1547607330;
                                        }
                                        while (true) {
                                            if ((v0 = (cfr_temp_0 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-8768510760529605551L ^ 5615428639548650804L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                                            if (v0 == (254324775 ^ 254324774)) {
                                                -272059884 - 1038118420;
                                                v1 = zNb\u015b.Y\u017btq.getConfig();
                                                if (5013528935642679751L == 5013528935642679752L) {
                                                    break;
                                                }
                                                break block30;
                                            }
                                            v0 = -447097815 - -531052860;
                                        }
                                        v2 = 1752902302;
                                        break block34;
                                    }
                                    v2 = 2107248415 ^ 2107248404;
                                }
                                var4_1 = new byte[v2];
                                var4_1[-458728961 ^ -458728962] = -6610902872985251701L == -6610902872985251700L ? -2008781259 : -1604407609 ^ -1604407634;
                                var4_1[-1051724957 ^ -1051724954] = -2049626505 ^ -2049626596;
                                var4_1[991012603 ^ 991012595] = 1638813386 ^ 1638813355;
                                var4_1[1473592290 ^ 1473592294] = 5715404052159869387L == 5715404052159869388L ? 137071089 : -1714781422 ^ -1714781315;
                                var4_1[770185849 ^ 770185849] = 3459185461327293260L == 3459185461327293261L ? -1348023935 : 408530542 ^ 408530458;
                                var4_1[-453275674 ^ -453275679] = 222458766 ^ 222458848;
                                var4_1[-697777728 ^ -697777725] = -881397526 ^ -881397602;
                                var4_1[1922103358 ^ 1922103356] = -6897862561533099835L == -6897862561533099834L ? 1397737412 : -971075895 ^ -971075934;
                                var4_1[-453842259 ^ -453842268] = 1274184722551766539L == 1274184722551766540L ? -563575387 : -1011839327 ^ -1011839284;
                                var4_1[-404430518 ^ -404430516] = -36765454 ^ -36765523;
                                var4_1[-1927038296 ^ -1927038302] = 182941206 ^ 182941299;
                                v3 = new String(var4_1, "UTF-8");
                                while (true) {
                                    if ((v4 = (cfr_temp_1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-6625824339671631179L - 7595042986558977571L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                                    if (v4 == (1923451236 ^ 1923451237)) {
                                        v5 = v1.getString(v3);
                                        var4_1 = new byte[-1515684933 ^ -1515684934];
                                        var4_1[1154280445 ^ 1154280445] = -174437007 ^ -174437025;
                                        v6 = new String(var4_1, "UTF-8");
                                        var4_1 = new byte[-1688355418 ^ -1688355417];
                                        if (-2058008636118391164L == -2058008636118391163L) {
                                            break;
                                        }
                                        break block31;
                                    }
                                    v4 = 1222907320 - -1263677999;
                                }
                                v7 = 1224408208;
                                break block35;
                            }
                            v7 = -1884154627 ^ -1884154672;
                        }
                        var4_1[456440015 ^ 456440015] = v7;
                        v8 = new String(var4_1, "UTF-8");
                        v9 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                        block11: while (true) {
                            switch ((int)v9) {
                                case 141306124: {
                                    break block11;
                                }
                                case 1649448981: {
                                    v9 = (-7587519832559211515L - -6670455567921682315L) / (4334275960770281831L ^ 6184060723124562540L);
                                    continue block11;
                                }
                            }
                            break;
                        }
                        CRACKME_815b724a_3c97_40af_9137_bcd0f2b74b745db1499b = v5.replace(v6, v8);
                        var4_1 = new byte[-1942953705 ^ -1942953700];
                        var4_1[-122347701 ^ -122347704] = 8409426754729434066L == 8409426754729434067L ? -837451874 : 869446312 ^ 869446277;
                        var4_1[-1921285231430653165L == -1921285231430653164L ? 151131650 : -1808877778 ^ -1808877784] = 704488971 ^ 704489083;
                        var4_1[664311250 ^ 664311251] = -1588633295 ^ -1588633250;
                        var4_1[646371832 ^ 646371839] = -92554394 ^ -92554474;
                        var4_1[-1877726515 ^ -1877726523] = 2109456569005937949L == 2109456569005937950L ? -773665087 : -642376074 ^ -642376166;
                        var4_1[1128163996 ^ 1128163992] = 60404359 ^ 60404467;
                        var4_1[-1655575219 ^ -1655575225] = 511926214 ^ 511926248;
                        var4_1[-5486686416735379109L == -5486686416735379108L ? -1808495287 : 2098996908 ^ 2098996910] = -664539064 ^ -664539080;
                        var4_1[-834639443 ^ -834639448] = 423574244 ^ 423574157;
                        var4_1[830244272 ^ 830244281] = -1581345152 ^ -1581345031;
                        var4_1[7452588520954409611L == 7452588520954409612L ? 511114400 : 2135522036 ^ 2135522036] = 527897517 ^ 527897561;
                        v10 = new StringBuilder().append(new String(var4_1, "UTF-8"));
                        while (true) {
                            if ((v11 = (cfr_temp_2 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-2080530629265142049L ^ 3684926547629237109L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                            if (v11 == (-855213110 ^ -855213109)) {
                                v12 = v10.append(CRACKME_815b724a_3c97_40af_9137_bcd0f2b74b745db1499b);
                                var4_1 = new byte[-1758583649 ^ -1758583650];
                                if (-3377015535207602434L == -3377015535207602433L) {
                                    break;
                                }
                                break block32;
                            }
                            v11 = -1243775998 ^ 1524288366;
                        }
                        v13 = -983169945;
                        break block36;
                    }
                    v13 = 1286813470 ^ 1286813488;
                }
                var4_1[-959255284 ^ -959255284] = v13;
                v14 = new String(var4_1, "UTF-8");
                while (true) {
                    if ((v15 = (cfr_temp_3 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-1729243676905497899L == -1729243676905497898L ? -6269507266384041387L : 6910300651901883291L ^ -7575827495635782580L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                    if (v15 == (624632130821355442L == 624632130821355443L ? 8981754 : 251540430 ^ 251540431)) {
                        v16 = v12.append(v14);
                        var4_1 = new byte[-833067867 ^ -833067868];
                        var4_1[-794594193 ^ -794594193] = -1171063249 ^ -1171063295;
                        v17 = new String(var4_1, "UTF-8");
                        if (-7364875110475009870L == -7364875110475009869L) {
                            break;
                        }
                        break block33;
                    }
                    if (-312576096860114471L == -312576096860114470L) {
                        v15 = -1135757871;
                        continue;
                    }
                    v15 = -315312561 - -1491284797;
                }
                v18 = -598074164;
                break block37;
            }
            v18 = 1137201172 ^ 1137201175;
        }
        var4_1 = new byte[v18];
        var4_1[493318586 ^ 493318586] = -2236842208084087682L == -2236842208084087681L ? -1356204581 : -27537874 ^ -27537840;
        var4_1[965948612 ^ 965948613] = 1002678809 ^ 1002678826;
        var4_1[1400027449 ^ 1400027451] = -137888531 ^ -137888621;
        v19 = CRACKME_815b724a_3c97_40af_9137_bcd0f2b74b742b1323bc.replace(v17, new String(var4_1, "UTF-8"));
        while (true) {
            if ((v20 = (cfr_temp_4 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-2247727738935924559L ^ -7728953521920071825L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v20 == (-3746303228273740416L == -3746303228273740415L ? 1683411307 : 1348221334 - 1348221335)) break;
            if (-6204898154866062899L == -6204898154866062898L) {
                v20 = -1615788608;
                continue;
            }
            v20 = 894038335 ^ -1758280927;
        }
        v21 = v16.append(v19);
        while (true) {
            block38: {
                if ((v22 = (cfr_temp_5 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-4818313147708037351L ^ 1922794487498762962L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v22 != (2133585661 ^ 2133585660)) break block38;
                CRACKME_815b724a_3c97_40af_9137_bcd0f2b74b74bf8b6d5c = v21.toString();
                v23 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl152
            }
            v22 = 556209622 ^ -1733891289;
        }
        block16: while (true) {
            v23 = v24 / (-4223729898260514056L >>> "\u0000\u0000".length());
lbl152:
            // 2 sources

            switch ((int)v23) {
                case -1386967229: {
                    v24 = -2527262868640429056L >>> "\u0000\u0000".length();
                    continue block16;
                }
                case 141306124: {
                    break block16;
                }
                case 253029720: {
                    v24 = -1483549493939181377L - 841187105993998224L;
                    continue block16;
                }
            }
            break;
        }
        return \u017b\u017c\u0107m.7\u015aCz.getInt(CRACKME_815b724a_3c97_40af_9137_bcd0f2b74b74bf8b6d5c, -69528714 ^ -69528714);
    }

    /*
     * Exception decompiling
     */
    public static void DQJ-rNp6qH1KLeAn() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [4[TRYBLOCK]], but top level block is 51[SWITCH]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doClass(Driver.java:84)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:78)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompile(CFRDecompiler.java:89)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompileToZip(CFRDecompiler.java:133)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.decompileSaveAll(ResourceDecompiling.java:261)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.lambda$decompileSaveAll$0(ResourceDecompiling.java:111)
         *     at java.base/java.lang.Thread.run(Thread.java:1575)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Unable to fully structure code
     */
    public static int mUHYBBPpV50j2CtP(String var0) {
        if (8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == (-4351429624599605845L ^ -7334326571867223827L)) {
            914869230 ^ 914869231;
        } else {
            v0 = 1003673351 ^ 1003673351;
        }
        v1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        block18: while (true) {
            switch ((int)v1) {
                case -725069210: {
                    v1 = (1830762434230214696L ^ 8750638259298338253L) / (-871700198415185598L ^ 6900942385564845339L);
                    continue block18;
                }
                case 141306124: {
                    break block18;
                }
            }
            break;
        }
        v2 = zNb\u015b.Y\u017btq.getConfig();
        v3 = -203370445 ^ -203370440;
        var4_1 = new byte[v3];
        v4 = 2146925686 ^ 0x7FF77C7C;
        var4_1[v4] = -1250517500 ^ -1250517407;
        v5 = 1004821366 ^ 1004821273;
        var4_1[652989523 ^ 652989527] = v5;
        v6 = 542891194 ^ 542891187;
        var4_1[v6] = -1112269059 ^ -1112269168;
        var4_1[-861881413 ^ -861881410] = 1302615257 ^ 1302615218;
        v7 = 332647861 ^ 332647902;
        var4_1[-166358497 ^ -166358499] = v7;
        v8 = -1222700281 ^ -1222700173;
        var4_1[-1277637375 ^ -1277637374] = v8;
        var4_1[-739563784 ^ -739563783] = 1431389975 ^ 1431390078;
        var4_1[-111627136 ^ -111627129] = 1254102930 ^ 1254103036;
        v9 = 62465921 ^ 62465929;
        var4_1[v9] = 1559711113 ^ 1559711208;
        var4_1[-691365650 ^ -691365656] = -1225298811 ^ -1225298726;
        v10 = 1624522522 ^ 1624522606;
        var4_1[-721093309 ^ -721093309] = v10;
        v11 = new String(var4_1, "UTF-8");
        v12 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl45
        block19: while (true) {
            v12 = v13 / (-3552731622886663075L - 5513431226512626969L);
lbl45:
            // 2 sources

            switch ((int)v12) {
                case -828482208: {
                    v13 = 5589930901414329457L - -5218142070997450786L;
                    continue block19;
                }
                case 141306124: {
                    break block19;
                }
            }
            break;
        }
        var4_1 = new byte[855328224 ^ 855328225];
        var4_1[-965958836 ^ -965958836] = 357882025 ^ 357881991;
        v14 = new String(var4_1, "UTF-8");
        var4_1 = new byte[1730684812 ^ 1730684813];
        var4_1[-2070291944 ^ -2070291944] = -15141709 ^ -15141730;
        var1_2 = v2.getString(v11).replace(v14, new String(var4_1, "UTF-8"));
        while (true) {
            block28: {
                if ((v15 = (cfr_temp_0 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-6769853043560558852L ^ 4676348751755299679L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (v15 != (-1913927684 ^ -1913927683)) break block28;
                var4_1 = new byte[876693236 ^ 876693246];
                var4_1[459979510 ^ 459979511] = 1410313641 ^ 1410313664;
                v16 = -2002817088 ^ -2002817081;
                v17 = -843261011 ^ -843260962;
                var4_1[v16] = v17;
                var4_1[-29647124 ^ -29647131] = 324488601 ^ 324488631;
                v18 = 135621058 ^ 135621028;
                var4_1[198329006 ^ 198329004] = v18;
                v19 = -1171924094 ^ -1171924086;
                var4_1[v19] = 782639017 ^ 782639069;
                v20 = -105207794 ^ -105207798;
                var4_1[v20] = -1247000937 ^ -1247000902;
                v21 = -1579077007 ^ -1579077007;
                var4_1[v21] = 53321008 ^ 53321047;
                var4_1[-203913456 ^ -203913451] = -1090465248 ^ -1090465213;
                v22 = -1909511204 ^ -1909511256;
                var4_1[-314514906 ^ -314514907] = v22;
                var4_1[-1051117699 ^ -1051117701] = 1189675344 ^ 1189675327;
                v23 = new StringBuilder().append(new String(var4_1, "UTF-8"));
                v24 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl104
            }
            v15 = -1986426469 ^ -870970364;
        }
        block21: while (true) {
            v25 = -6221878063414149804L >>> "\u0000\u0000".length();
            v24 = v26 / v25;
lbl104:
            // 2 sources

            switch ((int)v24) {
                case -461836338: {
                    v26 = 3853059941402416215L ^ 5881508808432575152L;
                    continue block21;
                }
                case 141306124: {
                    break block21;
                }
                case 1751666719: {
                    v26 = 8729736168909458762L ^ -2421838224762235125L;
                    continue block21;
                }
                case 1912123817: {
                    v26 = 982231174499441695L ^ -734643424239131300L;
                    continue block21;
                }
            }
            break;
        }
        v27 = v23.append((String)CRACKME_4439e412_97c4_4984_9b0d_8aec30b74cbddbf0739a);
        var4_1 = new byte[-378453774 ^ -378453773];
        v28 = -2145002045 ^ -2145002045;
        v29 = -1537499376 ^ -1537499330;
        var4_1[v28] = v29;
        v30 = new String(var4_1, "UTF-8");
        while (true) {
            block29: {
                if ((v31 = (cfr_temp_1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (1986815431994093214L - 6427174744198281261L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (v31 != (-661573029 ^ -661573030)) break block29;
                v32 = v27.append(v30);
                var4_1 = new byte[-1338860286 ^ -1338860285];
                var4_1[-508389825 ^ -508389825] = 344723001 ^ 344722967;
                v33 = new String(var4_1, "UTF-8");
                var4_1 = new byte[2143113935 ^ 2143113932];
                v34 = -429691931 ^ -429691931;
                var4_1[v34] = 845457764 ^ 845457690;
                var4_1[1081628634 ^ 1081628632] = -1366905328 ^ -1366905234;
                v35 = 452403705 ^ 452403704;
                var4_1[v35] = -1349733044 ^ -1349732993;
                v36 = 137210802 - -2075104946;
                v37 = CRACKME_4439e412_97c4_4984_9b0d_8aec30b74cbd691ae9a3.replace(v33, new String(var4_1, "UTF-8"));
                -195551813 ^ -1091696394;
                v38 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl154
            }
            v31 = 744710387 ^ -1027891546;
        }
        block23: while (true) {
            v38 = (624186852275355824L ^ -759480675623138673L) / v39;
lbl154:
            // 2 sources

            switch ((int)v38) {
                case 141306124: {
                    break block23;
                }
                case 678394865: {
                    v39 = 3186718848622241351L ^ -6220485713934540777L;
                    continue block23;
                }
            }
            break;
        }
        var2_3 = v32.append(v37).toString();
        -1542745012 >>> "\u0000\u0000".length();
        return \u017b\u017c\u0107m.7\u015aCz.getInt((String)CRACKME_4439e412_97c4_4984_9b0d_8aec30b74cbdbc41ff95, 1027511331 ^ 1027511331);
    }

    /*
     * Unable to fully structure code
     */
    public static String tHQ4iHD_ZrsnHdEu(int var0) {
        block40: {
            block39: {
                block38: {
                    if (8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == (-8940249393689211448L == -8940249393689211447L ? -748975932917027146L : -8571914397595383381L ^ -2098396289013516582L)) {
                        if ((535762496 - 1971537950 ^ (-213195157 ^ -1934288492)) != 0) {
                            -1446610506 ^ -1446610505;
                        }
                    } else {
                        -1714314507 ^ -1714314507;
                    }
                    v0 = -7734128824955141423L == -7734128824955141422L ? 424329334 : -769687713 ^ -311067254;
                    v1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                    if (true) ** GOTO lbl16
                    block17: while (true) {
                        v1 = v2 / (-9061630841272907384L == -9061630841272907383L ? -3846382015208024592L : 6101821640086641797L ^ 2355744751246606040L);
lbl16:
                        // 2 sources

                        switch ((int)v1) {
                            case -2109331262: {
                                v2 = 3131410353895752328L >>> "\u0000\u0000".length();
                                continue block17;
                            }
                            case -1328748701: {
                                v2 = -5048695284217869059L ^ -4170546618078355466L;
                                continue block17;
                            }
                            case -423170241: {
                                v2 = -2614993344742588176L ^ -5996232510356225254L;
                                continue block17;
                            }
                            case 141306124: {
                                break block17;
                            }
                        }
                        break;
                    }
                    8\u0105ja.zsjN3N7fF6D1WUzb();
                    -1059071373 ^ 1883344798;
                    while (true) {
                        if ((v3 = (cfr_temp_0 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-7929255203832556956L ^ 5119806511092031497L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                            continue;
                        }
                        if (v3 == (7670178464385139834L == 7670178464385139835L ? -382698328 : 1633621200 ^ 1633621201)) {
                            CRACKME_4abed3ff_d0c6_47c7_a9f3_9b8de76cc428bb14f2f5 = 8\u0105ja.\u0119X\u01431.getOrDefault(CRACKME_4abed3ff_d0c6_47c7_a9f3_9b8de76cc428afe171bf, null);
                            if (CRACKME_4abed3ff_d0c6_47c7_a9f3_9b8de76cc428bb14f2f5 == null) {
                                break;
                            }
                            break block38;
                        }
                        v3 = 1820392288 ^ 380812157;
                    }
                    var3_2 = new byte[1682499506 ^ 1682499506];
                    return new String(var3_2, "UTF-8");
                }
                v4 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl57
                block19: while (true) {
                    v4 = v5 / (2804250027236876662L == 2804250027236876663L ? 2094839191152367236L : -7741989251547380075L ^ 267288103852829275L);
lbl57:
                    // 2 sources

                    switch ((int)v4) {
                        case -1628817322: {
                            if (5547479934584551083L == 5547479934584551084L) {
                                v5 = 1109180094159247564L;
                                continue block19;
                            }
                            v5 = 5184871248470005689L ^ -7789985714328653001L;
                            continue block19;
                        }
                        case -703882488: {
                            if (-6242534382704010483L == -6242534382704010482L) {
                                v5 = 4004860195973541447L;
                                continue block19;
                            }
                            v5 = 6338724204400967639L ^ 8364841771781131952L;
                            continue block19;
                        }
                        case 141306124: {
                            break block19;
                        }
                    }
                    break;
                }
                while (true) {
                    if ((v6 = (cfr_temp_1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-352194655728911811L ^ -6135399856062179939L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) {
                        continue;
                    }
                    if (v6 == (289078122 ^ 289078123)) {
                        v7 = new StringBuilder();
                        var3_3 = new byte[-394992473 ^ -394992468];
                        var3_3[-582801648 ^ -582801640] = 470836620 ^ 470836709;
                        var3_3[-627574565 ^ -627574574] = -769676109 ^ -769676075;
                        if (-803457427423073018L == -803457427423073017L) {
                            break;
                        }
                        break block39;
                    }
                    if (-3960321838263582800L == -3960321838263582799L) {
                        v6 = -1308224919;
                        continue;
                    }
                    v6 = -304467714 ^ -844271854;
                }
                v8 = -1296130730;
                break block40;
            }
            v8 = 1538191826 ^ 1538191831;
        }
        var3_3[v8] = 545901653 ^ 545901624;
        var3_3[492101766 ^ 492101761] = -1664568071 ^ -1664568162;
        var3_3[-290636427181515355L == -290636427181515354L ? 1646407055 : 492884137 ^ 492884137] = -23601777 ^ -23601684;
        var3_3[3785186731680017367L == 3785186731680017368L ? 495414443 : -1904226740 ^ -1904226744] = 1761710482 ^ 1761710589;
        var3_3[241636517 ^ 241636516] = -6646018161058013068L == -6646018161058013067L ? -877967444 : 1147589822 ^ 1147589835;
        var3_3[-1019088819752310084L == -1019088819752310083L ? -1653429153 : 981588678 ^ 981588676] = -604697821 ^ -604697776;
        var3_3[-832392252 ^ -832392254] = 4113084214598002586L == 4113084214598002587L ? 2146941329 : -291174710 ^ -291174763;
        var3_3[-48635597 ^ -48635600] = -6877105196162178876L == -6877105196162178875L ? -550337294 : -10595477 ^ -10595553;
        var3_3[800234815 ^ 800234805] = -1983672387 ^ -1983672375;
        v9 = new String(var3_3, "UTF-8");
        v10 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl113
        block21: while (true) {
            v10 = v11 / (2054041708524738808L ^ -7809821913694734138L);
lbl113:
            // 2 sources

            switch ((int)v10) {
                case -194372808: {
                    if (-6453883058930534749L == -6453883058930534748L) {
                        v11 = 819622551864479835L;
                        continue block21;
                    }
                    v11 = -4004427337733651717L - -4040504164889569927L;
                    continue block21;
                }
                case 141306124: {
                    break block21;
                }
                case 215795070: {
                    v11 = 6819227809242737496L >>> "\u0000\u0000".length();
                    continue block21;
                }
                case 1356189824: {
                    v11 = 5683877804419973981L ^ -4583594797107998191L;
                    continue block21;
                }
            }
            break;
        }
        v12 = v7.append(v9).append(8\u0105ja.gFOWaAfPEoX63PWz(CRACKME_4abed3ff_d0c6_47c7_a9f3_9b8de76cc428bb14f2f5));
        while (true) {
            if ((v13 = (cfr_temp_2 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (8553016081089150942L ^ 2043790338263207582L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v13 == (-8283909350308078006L == -8283909350308078005L ? -1660953704 : -1245353742 ^ 1245353741)) {
                return e4wV.2al_94WjzQTnIzkU((String)v12.toString());
            }
            v13 = -2053719819 - -2019958293;
        }
    }

    public static String gxbWh8_-PtBNhnOb(String string) {
        String CRACKME_82fe2b0d_3839_4926_af37_850996e48370dd9fafc6;
        int n;
        byte[] byArray;
        StringBuilder stringBuilder;
        block14: {
            block13: {
                if (CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == (8697095293168750893L == 8697095293168750894L ? 7146494194720485235L : 4670772882639958476L - 1975465913109830115L)) {
                    if ((1236005924 >>> "\u0000\u0000".length() ^ (7618300042202859816L == 7618300042202859817L ? -751995722 : 0xDD2BB98B ^ 0xA2D44674)) != 0) {
                        int cfr_ignored_5 = 0xD3BC6B00 ^ 0xD3BC6B01;
                    }
                } else {
                    int cfr_ignored_6 = 0x77B6712 ^ 0x77B6712;
                }
                while (true) {
                    long l;
                    long l2;
                    if ((l2 = (l = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (0x25252A2D50B74A72L ^ 0x9CB3509F64B94C71L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
                    if (l2 == (0x32867001 ^ 0x32867000)) break;
                    if (-5108052910437061100L == -5108052910437061099L) {
                        l2 = -124196473;
                        continue;
                    }
                    l2 = 0x6E7228F1 ^ 0x20FD6367;
                }
                while (true) {
                    long l;
                    long l3;
                    if ((l3 = (l = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (0xB24C66BB1D211C8L ^ 0x852D0A57AB751BE5L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
                    if (l3 == (1280498954982469346L == 1280498954982469347L ? 1977657799 : 0x24994019 ^ 0x24994018)) {
                        stringBuilder = new StringBuilder();
                        byArray = new byte[0x5453AC78 ^ 0x5453AC73];
                        if (2668320350404548058L == 2668320350404548059L) {
                            break;
                        }
                        break block13;
                    }
                    if (-934099466782476561L == -934099466782476560L) {
                        l3 = 1120807292;
                        continue;
                    }
                    l3 = 483802634 - 1551185523;
                }
                n = 1023002291;
                break block14;
            }
            n = 0x2E7A6223 ^ 0x2E7A6240;
        }
        byArray[0x9C690FC2 ^ 0x9C690FC2] = n;
        byArray[0xAA7E8059 ^ 0xAA7E8050] = 0xCEE5C2 ^ 0xCEE5A4;
        byArray[-8465321183017688443L == -8465321183017688442L ? -227956279 : 0x5D98AA42 ^ 0x5D98AA41] = 0x3DE84621 ^ 0x3DE84655;
        byArray[0xAC65DDCC ^ 0xAC65DDC4] = 0xF63C0810 ^ 0xF63C0879;
        byArray[0x8FAC1A73 ^ 0x8FAC1A77] = 0xAFEC0C0C ^ 0xAFEC0C63;
        byArray[0x521C7558 ^ 0x521C7559] = -9005380250407858180L == -9005380250407858179L ? -986633296 : 0x13FE394D ^ 0x13FE3938;
        byArray[0xE94AD765 ^ 0xE94AD762] = 0x73E0DAB ^ 0x73E0DCC;
        byArray[0x375A1 ^ 0x375A4] = 0x85D971E3 ^ 0x85D9718E;
        byArray[0xA03B0F3E ^ 0xA03B0F38] = 0x284D14F ^ 0x284D110;
        byArray[0x5D072569 ^ 0x5D07256B] = 0x53129FBC ^ 0x53129FCF;
        byArray[0x9AA866B2 ^ 0x9AA866B8] = 0x803B709C ^ 0x803B70E8;
        StringBuilder stringBuilder2 = stringBuilder.append(new String(byArray, "UTF-8"));
        int cfr_ignored_7 = 0x3095778E ^ 0x733DF55C;
        String string2 = 8\u0105ja.gFOWaAfPEoX63PWz(CRACKME_82fe2b0d_3839_4926_af37_850996e48370dd9fafc6);
        while (true) {
            long l;
            long l4;
            if ((l4 = (l = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (8033330503023821584L - 4075266685710157702L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l4 == (0x79E64AD3 ^ 0x79E64AD2)) break;
            l4 = 0xD25178B4 ^ 0x2BD29B1E;
        }
        StringBuilder stringBuilder3 = stringBuilder2.append(string2);
        while (true) {
            long l;
            long l5;
            if ((l5 = (l = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (7611657583268554753L == 7611657583268554754L ? 7458427778315246773L : 210096323234950772L >>> "\u0000\u0000".length())) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l5 == (0x7F25D8CA ^ 0x7F25D8CB)) break;
            l5 = -15714648 >>> "\u0000\u0000".length();
        }
        String string3 = stringBuilder3.toString();
        while (true) {
            long l;
            long l6;
            if ((l6 = (l = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-1829517342611166605L - 5853474433534525686L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l6 == (0xA97869ED ^ 0xA97869EC)) {
                return e4wV.2al_94WjzQTnIzkU((String)string3);
            }
            l6 = 0x12DB5834 ^ 0xCF3249D;
        }
    }

    /*
     * Unable to fully structure code
     */
    public static String We0ReNO7CoUFIfr2(String var0, int var1_1) {
        block47: {
            block44: {
                block43: {
                    block46: {
                        block42: {
                            block45: {
                                block41: {
                                    if (8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == (-6139084255440876208L == -6139084255440876207L ? -5751740079018776141L : 2497642094674825629L ^ -4783864701960947099L)) {
                                        if ((954086770 ^ 2119357900 ^ (-680913643 ^ -1466570006)) != 0) {
                                            535306607 ^ 535306606;
                                        }
                                    } else {
                                        -1739687140 ^ -1739687140;
                                    }
                                    v0 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                                    if (true) ** GOTO lbl14
                                    block16: while (true) {
                                        v0 = v1 / (-5999577411116939112L == -5999577411116939111L ? -3831392304674461433L : 2503019617406255679L - 958968619541685768L);
lbl14:
                                        // 2 sources

                                        switch ((int)v0) {
                                            case -516982805: {
                                                if (-8697887612516890226L == -8697887612516890225L) {
                                                    v1 = -3657777338595861917L;
                                                    continue block16;
                                                }
                                                v1 = 994477569041224213L - -5744199725229944187L;
                                                continue block16;
                                            }
                                            case 141306124: {
                                                break block16;
                                            }
                                            case 1645160123: {
                                                if (2140475650903932183L == 2140475650903932184L) {
                                                    v1 = -3855429291527999767L;
                                                    continue block16;
                                                }
                                                v1 = 7859202788148820867L ^ -6969194977414979825L;
                                                continue block16;
                                            }
                                            case 1646518689: {
                                                v1 = -6036035897686568593L ^ -3104666065176674634L;
                                                continue block16;
                                            }
                                        }
                                        break;
                                    }
                                    8\u0105ja.zsjN3N7fF6D1WUzb();
                                    while (true) {
                                        if ((v2 = (cfr_temp_0 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (2544420131748852371L ^ -4172637161155832151L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                                        if (v2 == (-871348466 ^ -871348465)) {
                                            if (4422648153125007575L == 4422648153125007576L) {
                                                break;
                                            }
                                            break block41;
                                        }
                                        v2 = -1997358201 ^ -2056234251;
                                    }
                                    v3 = 1745749960;
                                    break block45;
                                }
                                v3 = -586741530 - -1315354632;
                            }
                            v4 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                            if (true) ** GOTO lbl53
                            block18: while (true) {
                                v4 = v5 / (7276981698034638766L - 8672252500678151119L);
lbl53:
                                // 2 sources

                                switch ((int)v4) {
                                    case -1247129904: {
                                        v5 = 6724201450489812304L ^ -956379217312870839L;
                                        continue block18;
                                    }
                                    case 141306124: {
                                        break block18;
                                    }
                                    case 263037833: {
                                        v5 = 8882764127335019362L ^ -5097357052645508003L;
                                        continue block18;
                                    }
                                }
                                break;
                            }
                            v6 = CRACKME_472cae7f_e1f7_4b77_867d_28dce866010e493d5d73.toLowerCase();
                            while (true) {
                                if ((v7 = (cfr_temp_1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-770976864507383198L ^ 7767494383198464569L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                                if (v7 == (-982111192 ^ -982111191)) break;
                                v7 = 1175431518 - -687227540;
                            }
                            v8 = Collections.emptyMap();
                            while (true) {
                                if ((v9 = (cfr_temp_2 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (7585262585334182485L == 7585262585334182486L ? 5974143317849922419L : -2699551154044914740L - 2666174376719838565L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                                if (v9 == (3129221348314389752L == 3129221348314389753L ? 1857555165 : -1543632771 ^ -1543632772)) {
                                    v10 = 8\u0105ja.\u017bxh\u0143.getOrDefault(v6, v8);
                                    if (-5112443866978974999L == -5112443866978974998L) {
                                        break;
                                    }
                                    break block42;
                                }
                                v9 = 1297938866 - -1101978242;
                            }
                            v11 = 618754475;
                            break block46;
                        }
                        v11 = 1540892506 - 918851846;
                    }
                    while (true) {
                        if ((v12 = (cfr_temp_3 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (4021311137448153750L ^ 5528936671844061731L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                        if (v12 == -924824689 - -924824688) break;
                        if (6960813125368575950L == 6960813125368575951L) {
                            v12 = -368618158;
                            continue;
                        }
                        v12 = -327802515 ^ 1237516583;
                    }
                    v13 = (int)CRACKME_472cae7f_e1f7_4b77_867d_28dce866010e05a58115;
                    while (true) {
                        if ((v14 = (cfr_temp_4 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-454133735989414278L - -5242961416435649424L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                        if (v14 == (-248341719 ^ -248341720)) {
                            CRACKME_472cae7f_e1f7_4b77_867d_28dce866010e372b0f3b = v10.getOrDefault(v13, null);
                            223056334 - 1605273742;
                            if (CRACKME_472cae7f_e1f7_4b77_867d_28dce866010e372b0f3b == null) {
                                break;
                            }
                            break block43;
                        }
                        v14 = 1161851270 ^ -1760570859;
                    }
                    var4_3 = new byte[1793679813101454497L == 1793679813101454498L ? -1272853174 : 1636922131 ^ 1636922131];
                    return new String(var4_3, "UTF-8");
                }
                while (true) {
                    if ((v15 = (cfr_temp_5 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-5944680799228278713L ^ -1304148307502894810L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                    if (v15 == (-861195711 ^ -861195712)) {
                        v16 = new StringBuilder();
                        var4_4 = new byte[-617560987 ^ -617560978];
                        var4_4[1865163766 ^ 1865163766] = 716900258 ^ 716900289;
                        var4_4[-828246744 ^ -828246751] = -1922839988 ^ -1922840022;
                        var4_4[757035463 ^ 757035457] = 325022590 ^ 325022497;
                        if (3944460270693581400L == 3944460270693581401L) {
                            break;
                        }
                        break block44;
                    }
                    if (5677980578135911808L == 5677980578135911809L) {
                        v15 = 710461462;
                        continue;
                    }
                    v15 = 1374333565 ^ -1915253886;
                }
                v17 = -236619312;
                break block47;
            }
            v17 = -810420472 ^ -810420377;
        }
        var4_4[156619767 ^ 156619763] = v17;
        var4_4[-286698542431054694L == -286698542431054693L ? 1547830559 : -173825213 ^ -173825216] = 7740345110527533487L == 7740345110527533488L ? 1520056968 : -483500881 ^ -483500837;
        var4_4[409760122 ^ 409760123] = 8048475272750454299L == 8048475272750454300L ? 856953088 : 25656714 ^ 25656831;
        var4_4[7152377316192924000L == 7152377316192924001L ? -1694300638 : -587194028 ^ -587194020] = -523444349 ^ -523444246;
        var4_4[-7551799672287183010L == -7551799672287183009L ? -1811494660 : 1495107782 ^ 1495107780] = -1979167040 ^ -1979167053;
        var4_4[-415305166 ^ -415305160] = 6213026381084552236L == 6213026381084552237L ? -670649263 : 752086835 ^ 752086855;
        var4_4[-7879708 ^ -7879711] = 1970670957842832865L == 1970670957842832866L ? -850736268 : 133606810 ^ 133606903;
        var4_4[5335063421882720038L == 5335063421882720039L ? 75939940 : -789026948 ^ -789026949] = -300862809 ^ -300862784;
        v18 = v16.append(new String(var4_4, "UTF-8"));
        858105850 ^ 129497065;
        while (true) {
            block48: {
                if ((v19 = (cfr_temp_6 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (4140827615057870226L ^ -3045727999307563678L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                if (v19 != (-4675830462825286058L == -4675830462825286057L ? 1198519168 : -1798734116 ^ -1798734115)) break block48;
                v20 = 8\u0105ja.gFOWaAfPEoX63PWz(CRACKME_472cae7f_e1f7_4b77_867d_28dce866010e372b0f3b);
                v21 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl161
            }
            v19 = 1406695437 - -416647641;
        }
        block25: while (true) {
            v21 = v22 / (-5937596294429788853L ^ 4526426651609594295L);
lbl161:
            // 2 sources

            switch ((int)v21) {
                case -447064582: {
                    v22 = -3100731667608648901L ^ -4593105909935159835L;
                    continue block25;
                }
                case 141306124: {
                    break block25;
                }
                case 396626468: {
                    v22 = 7046468839173904320L ^ 6592176390077258919L;
                    continue block25;
                }
            }
            break;
        }
        1681898256 ^ 607242578;
        return e4wV.2al_94WjzQTnIzkU((String)v18.append(v20).toString());
    }

    /*
     * Unable to fully structure code
     */
    private static /* synthetic */ void Kqgm_LxOMraQlqTV(Map var0, Map var1_1, String var2_2, Map var3_3) {
        block55: {
            block54: {
                if (8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == (737811291477861591L ^ 4662402688934321284L)) {
                    if (((-9145322486873448558L == -9145322486873448557L ? -824133948 : -962650692 - 732324254) ^ (1576630303 ^ 570853344)) != 0) {
                        -866672978 ^ -866672977;
                    }
                } else {
                    -431865625 ^ -431865625;
                }
                while (true) {
                    if ((v0 = (cfr_temp_0 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-6733225018688863541L - -7241185197792888077L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                    if (v0 == (-1795427211 ^ -1795427212)) {
                        v1 = new ArrayList<Map.Entry<K, V>>(CRACKME_d5e8d43f_3d3b_47ea_9ef3_11e1f0d5b3a2a48729e3.entrySet());
                        if (1902217697880491578L == 1902217697880491579L) {
                            break;
                        }
                        break block54;
                    }
                    if (-4912004986232865939L == -4912004986232865938L) {
                        v0 = 1113234990;
                        continue;
                    }
                    v0 = -429074246 ^ 1646906472;
                }
                v2 = 156535491;
                break block55;
            }
            v2 = 2054944655 ^ -865641662;
        }
        var4_4 = v1;
        while (true) {
            if ((v3 = (cfr_temp_1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-8843535054122608148L ^ -439985405916706266L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v3 == -1518595099 - -1518595098) break;
            v3 = -466298057 ^ 1028336191;
        }
        v4 = Map.Entry.comparingByValue();
        while (true) {
            block56: {
                if ((v5 = (cfr_temp_2 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (7134020830970804718L - -1812596921502294298L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v5 != 673028097 - 673028098) break block56;
                v6 = Collections.reverseOrder(v4);
                v7 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl53
            }
            if (2913254444514070921L == 2913254444514070922L) {
                v5 = 2036612643;
                continue;
            }
            v5 = -1529112329 ^ 33485718;
        }
        block31: while (true) {
            v7 = v8 / (-3149861279144980896L ^ 5156260209724543038L);
lbl53:
            // 2 sources

            switch ((int)v7) {
                case -2109292090: {
                    if (3880877279211537539L == 3880877279211537540L) {
                        v8 = 9015981277963602559L;
                        continue block31;
                    }
                    v8 = 5096102047052710540L >>> "\u0000\u0000".length();
                    continue block31;
                }
                case 141306124: {
                    break block31;
                }
                case 1093898242: {
                    v8 = -6596471023951281446L - 3222790476985672360L;
                    continue block31;
                }
                case 2123746251: {
                    if (1330090820603761360L == 1330090820603761361L) {
                        v8 = -6527844713595115698L;
                        continue block31;
                    }
                    v8 = 1346587701078571468L >>> "\u0000\u0000".length();
                    continue block31;
                }
            }
            break;
        }
        CRACKME_d5e8d43f_3d3b_47ea_9ef3_11e1f0d5b3a2d6d1d980.sort(v6);
        CRACKME_d5e8d43f_3d3b_47ea_9ef3_11e1f0d5b3a2a363b36a = new ConcurrentHashMap<Integer, String>();
        while (true) {
            block57: {
                if ((v9 = (cfr_temp_3 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (9114284916858133192L == 9114284916858133193L ? -4888356638650061563L : -116336973006073605L ^ -7659429623488115826L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v9 != -561771548 - -561771547) break block57;
                v10 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl87
            }
            if (452008846968720367L == 452008846968720368L) {
                v9 = 842655244;
                continue;
            }
            v9 = 1560513835 ^ 835019255;
        }
        block33: while (true) {
            v10 = v11 / (-7461391334973926897L == -7461391334973926896L ? 6367624941646488689L : 4922578218231297949L ^ -8435643522948983062L);
lbl87:
            // 2 sources

            switch ((int)v10) {
                case -2105660278: {
                    if (3830039593265023154L == 3830039593265023155L) {
                        v11 = -3992752491682783241L;
                        continue block33;
                    }
                    v11 = 7581564533340287612L - -1399395645338979853L;
                    continue block33;
                }
                case -1809424632: {
                    if (172748740662126161L == 172748740662126162L) {
                        v11 = -3180316926783545882L;
                        continue block33;
                    }
                    v11 = -1643970603938927645L ^ -827242142756923892L;
                    continue block33;
                }
                case 141306124: {
                    break block33;
                }
            }
            break;
        }
        var6_6 = new ConcurrentHashMap<K, V>();
        var7_7 = 229513707 ^ 229513707;
        while (true) {
            block61: {
                block59: {
                    block60: {
                        block58: {
                            if ((v12 = (cfr_temp_4 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-8361501201510981513L ^ 1452272692720817980L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                            if (v12 != (1010107839 ^ 1010107838)) break block58;
                            if (CRACKME_d5e8d43f_3d3b_47ea_9ef3_11e1f0d5b3a21813bcc1 >= CRACKME_d5e8d43f_3d3b_47ea_9ef3_11e1f0d5b3a2d6d1d980.size()) break block59;
                            break block60;
                        }
                        v12 = 806780076 >>> "\u0000\u0000".length();
                        continue;
                    }
                    2093070299 - -1689468716;
                    v13 = CRACKME_d5e8d43f_3d3b_47ea_9ef3_11e1f0d5b3a21813bcc1 + (-6378851762706450596L == -6378851762706450595L ? -579661166 : -591641972 ^ -591641971);
                    v14 = -8253342477511886401L == -8253342477511886400L ? 1790936340 : -529349172 - -1540306339;
                    break block61;
                }
                1535147135 ^ -1685123688;
                v15 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl221
            }
            while (true) {
                if ((v16 = (cfr_temp_5 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (6965338430326838412L == 6965338430326838413L ? -8120900465114250503L : 1009840506146271106L ^ -7022355849108201357L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v16 == (-1558064372 ^ -1558064371)) break;
                v16 = -1811687272 - -764195817;
            }
            v17 = (int)v13;
            while (true) {
                block62: {
                    if ((v18 = (cfr_temp_6 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-522232621892822736L == -522232621892822735L ? -1240227284204326988L : 8123067585960082027L ^ -1674433780271904085L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                    if (v18 != (-2767703060819743989L == -2767703060819743988L ? -1522442033 : 1718469384 ^ 1718469385)) break block62;
                    -1320436302 ^ -1766785768;
                    CRACKME_d5e8d43f_3d3b_47ea_9ef3_11e1f0d5b3a2a363b36a.put(v17, (String)((Map.Entry)CRACKME_d5e8d43f_3d3b_47ea_9ef3_11e1f0d5b3a2d6d1d980.get((int)CRACKME_d5e8d43f_3d3b_47ea_9ef3_11e1f0d5b3a21813bcc1)).getKey());
                    v19 = (int)(CRACKME_d5e8d43f_3d3b_47ea_9ef3_11e1f0d5b3a21813bcc1 + (-1814206873 ^ -1814206874));
                    v20 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                    if (true) ** GOTO lbl177
                }
                v18 = -1141616870 ^ 562256631;
            }
            block37: while (true) {
                v20 = v21 / (3249996975605299052L - 4084480765996973842L);
lbl177:
                // 2 sources

                switch ((int)v20) {
                    case -1081679483: {
                        v21 = -3931020988994831404L ^ 7305623043256719418L;
                        continue block37;
                    }
                    case -95776761: {
                        if (8845286852003391923L == 8845286852003391924L) {
                            v21 = -6824181173550813854L;
                            continue block37;
                        }
                        v21 = 7535809238707453132L - -3095484690756041894L;
                        continue block37;
                    }
                    case 141306124: {
                        break block37;
                    }
                    case 1955082579: {
                        v21 = -1815073680034733581L - -8824936327496136324L;
                        continue block37;
                    }
                }
                break;
            }
            -2058730475 ^ -1548721644;
            v22 = (Integer)((Map.Entry)CRACKME_d5e8d43f_3d3b_47ea_9ef3_11e1f0d5b3a2d6d1d980.get((int)CRACKME_d5e8d43f_3d3b_47ea_9ef3_11e1f0d5b3a21813bcc1)).getValue();
            v23 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
            if (true) ** GOTO lbl201
            block38: while (true) {
                v23 = v24 / (-7641074740289810511L ^ -2002258550909542698L);
lbl201:
                // 2 sources

                switch ((int)v23) {
                    case -584189309: {
                        v24 = -1416852225881694122L - -2817348572822670217L;
                        continue block38;
                    }
                    case -212165968: {
                        v24 = -5890901761891731470L ^ -7757637425756899339L;
                        continue block38;
                    }
                    case 141306124: {
                        break block38;
                    }
                    case 1163995621: {
                        v24 = 669953502814840597L ^ -2053178093037320323L;
                        continue block38;
                    }
                }
                break;
            }
            CRACKME_d5e8d43f_3d3b_47ea_9ef3_11e1f0d5b3a2772bc903.put(v19, v22);
            ++CRACKME_d5e8d43f_3d3b_47ea_9ef3_11e1f0d5b3a21813bcc1;
        }
        block39: while (true) {
            v15 = v25 / (3770461777863436033L ^ 5757683599758493319L);
lbl221:
            // 2 sources

            switch ((int)v15) {
                case -1957094127: {
                    v25 = -1433855285523942308L ^ -6807117428735187165L;
                    continue block39;
                }
                case 141306124: {
                    break block39;
                }
                case 1697239632: {
                    if (-8593415394054453666L == -8593415394054453665L) {
                        v25 = -6693079334308951620L;
                        continue block39;
                    }
                    v25 = 7186291084530148430L ^ -5030048567649353089L;
                    continue block39;
                }
            }
            break;
        }
        CRACKME_d5e8d43f_3d3b_47ea_9ef3_11e1f0d5b3a2893bfd22.put(CRACKME_d5e8d43f_3d3b_47ea_9ef3_11e1f0d5b3a2cf12a19f, CRACKME_d5e8d43f_3d3b_47ea_9ef3_11e1f0d5b3a2a363b36a);
        537006232 ^ 1775690784;
        CRACKME_d5e8d43f_3d3b_47ea_9ef3_11e1f0d5b3a230274070.put(CRACKME_d5e8d43f_3d3b_47ea_9ef3_11e1f0d5b3a2cf12a19f, CRACKME_d5e8d43f_3d3b_47ea_9ef3_11e1f0d5b3a2772bc903);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     */
    public static String loZloImVMJOSohtn(int n) {
        String CRACKME_85bdd521_fdd5_4516_a418_d518e64bf766600c84f2;
        block20: {
            int CRACKME_85bdd521_fdd5_4516_a418_d518e64bf766558be195;
            long l = 0x99D52D283585410DL ^ 0xDB3394F180910C17L;
            if (CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == l) {
                int cfr_ignored_3 = 0x9F4CA59C ^ 0x9F4CA59D;
            } else {
                int cfr_ignored_4 = 0xE46A89C0 ^ 0xE46A89C0;
            }
            8\u0105ja.zsjN3N7fF6D1WUzb();
            int cfr_ignored_5 = 994108156 >>> "\u0000\u0000".length();
            int n2 = 0x1EC69A7C ^ 0x9A99697;
            long l2 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
            boolean bl = true;
            block11: while (true) {
                long l3;
                if (!bl || (bl = false) || !true) {
                    long l4 = 0x52CA3BBCA9457F5FL ^ 0x9606243AF84B8051L;
                    l2 = l3 / l4;
                }
                switch ((int)l2) {
                    case -1716677500: {
                        l3 = -7531970952821900476L >>> "\u0000\u0000".length();
                        continue block11;
                    }
                    case -1015446565: {
                        l3 = -3683613264060096010L - 3776099169225997952L;
                        continue block11;
                    }
                    case 141306124: {
                        break block11;
                    }
                    case 599029508: {
                        l3 = -1362489513785040642L - -5382616816093583284L;
                        continue block11;
                    }
                }
                break;
            }
            Integer n3 = CRACKME_85bdd521_fdd5_4516_a418_d518e64bf766558be195;
            while (true) {
                long l5 = 0x6EDEACD7A8540EE2L ^ 0x70A13AFA0C82C59L;
                long l6 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - l5;
                long l7 = l6 == 0L ? 0 : (l6 < 0L ? -1 : 1);
                if (l7 == false) continue;
                if (l7 == -1938713188 - -1938713187) {
                    CRACKME_85bdd521_fdd5_4516_a418_d518e64bf766600c84f2 = \u0119X\u01431.getOrDefault(n3, null);
                    if (CRACKME_85bdd521_fdd5_4516_a418_d518e64bf766600c84f2 == null) {
                        break;
                    }
                    break block20;
                }
                l7 = 0x6262E04D ^ 0x8C8D9664;
            }
            byte[] byArray = new byte[0xBE97F7D8 ^ 0xBE97F7DF];
            byArray[0xB726B2B3 ^ 0xB726B2B5] = 0xB0567E8E ^ 0xB0567EC5;
            byArray[0xCFB96598 ^ 0xCFB9659B] = 0xF8092776 ^ 0xF8092734;
            int n4 = 0xE9B95CDE ^ 0xE9B95C9F;
            byArray[0xA5918F9C ^ 0xA5918F99] = n4;
            byArray[0x333A0B12 ^ 0x333A0B13] = -658510532 - -658510443;
            byArray[0xAB64FEC8 ^ 0xAB64FECC] = 0x303DA4B7 ^ 0x303DA4E5;
            int n5 = 0x3D17E627 ^ 0x3D17E625;
            byArray[n5] = 0xD39DB511 ^ 0xD39DB572;
            int n6 = 0xEA183A20 ^ 0xEA183A20;
            int n7 = 0x9354E191 ^ 0x6CAB1E53;
            byArray[n6] = n7;
            return new String(byArray, "UTF-8");
        }
        long l = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        boolean bl = true;
        block13: while (true) {
            long l8;
            if (!bl || (bl = false) || !true) {
                long l9 = 5554651504229110664L - -3780133260956544614L;
                l = l8 / l9;
            }
            switch ((int)l) {
                case -1557271743: {
                    l8 = 0xE7B3DCE2AD02C88DL ^ 0x7A98D76389025C11L;
                    continue block13;
                }
                case -697827826: {
                    l8 = 0x4E02A5C60852C7DL ^ 0xF0E597EB5A1CEAE0L;
                    continue block13;
                }
                case 141306124: {
                    return 8\u0105ja.mrVvLE3h-7jv8HUT(CRACKME_85bdd521_fdd5_4516_a418_d518e64bf766600c84f2);
                }
            }
            break;
        }
        return 8\u0105ja.mrVvLE3h-7jv8HUT(CRACKME_85bdd521_fdd5_4516_a418_d518e64bf766600c84f2);
    }

    /*
     * Unable to fully structure code
     */
    public static String XrKUnNuN0Gvkpq8y(String var0) {
        block53: {
            block47: {
                if (8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == -2555942089905249818L - -4837911232733614630L) {
                    if ((-2035502839 ^ 1406403865 ^ (1340570234 ^ 806913413)) != 0) {
                        1350579971 ^ 1350579970;
                    }
                } else {
                    1407324037 ^ 1407324037;
                }
                v0 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl20
                block24: while (true) {
                    v0 = v1 / (553041736911418792L >>> "\u0000\u0000".length());
lbl20:
                    // 2 sources

                    switch ((int)v0) {
                        case 141306124: {
                            break block24;
                        }
                        case 595501670: {
                            v1 = -8412400302465899404L ^ -8517224115958686976L;
                            continue block24;
                        }
                        case 1174697534: {
                            v1 = -2165640320852499405L - 1150176311080123185L;
                            continue block24;
                        }
                    }
                    break;
                }
                8\u0105ja.zsjN3N7fF6D1WUzb();
                while (true) {
                    if ((v2 = (cfr_temp_0 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (8936289003414056194L ^ -7631155742471813977L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                    if (v2 == (161499422 ^ 161499423)) break;
                    v2 = 2020578055 ^ -2059647706;
                }
                v3 = 8\u0105ja.\u0118\u01790F.entrySet();
                v4 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                block26: while (true) {
                    switch ((int)v4) {
                        case 141306124: {
                            break block26;
                        }
                        case 1848739826: {
                            v4 = (6674000887488797864L >>> "\u0000\u0000".length()) / (4918575199616326124L - -4561273817495234869L);
                            continue block26;
                        }
                    }
                    break;
                }
                var1_1 = v3.iterator();
                block27: while (true) {
                    block52: {
                        block51: {
                            block49: {
                                block50: {
                                    block48: {
                                        if ((v5 = (cfr_temp_1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (7511412324422653370L ^ -5635224613710810794L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                                        if (v5 != (-168196727 ^ -168196728)) break block48;
                                        v6 = var1_1.hasNext();
                                        if (6792416608763351713L != 6792416608763351714L) break block49;
                                        break block50;
                                    }
                                    if (5581394195691982192L == 5581394195691982193L) {
                                        v5 = 505723704;
                                        continue;
                                    }
                                    v5 = 799156223 ^ 1145684996;
                                    continue;
                                }
                                v7 = -1028559168;
                                break block51;
                            }
                            v7 = 1457879464 - 373355658;
                        }
                        if (!v6) break block52;
                        v8 = -3467341307116010157L == -3467341307116010156L ? 66744819 : -990535168 - -752675301;
                        CRACKME_1f7bf84e_a0cb_4498_bd82_f12eb40cdc5b1361eb4c = var1_1.next();
                        v9 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                        if (true) ** GOTO lbl85
                    }
                    var4_4 = new byte[-2952955748437626317L == -2952955748437626316L ? -1232020403 : 1639203844 ^ 1639203841];
                    var4_4[351320246 ^ 351320245] = -2612912760076947151L == -2612912760076947150L ? -1459646935 : -244343688 ^ -244343723;
                    var4_4[5925516197682731110L == 5925516197682731111L ? -1384934226 : -1996868770 ^ -1996868772] = 2407488275100782129L == 2407488275100782130L ? 1192045044 : 1372112649 ^ 1372112746;
                    var4_4[502610007 ^ 502610003] = 422387994 ^ 422388023;
                    var4_4[-2021340341 ^ -2021340342] = 2576815253785202284L == 2576815253785202285L ? 1382855812 : -548936562 ^ 548936489;
                    var4_4[-1395446501 ^ -1395446501] = -1897445082 ^ 1897445092;
                    return new String(var4_4, "UTF-8");
                    block28: while (true) {
                        v9 = v10 / (1495627874483061908L ^ 8655854879448670757L);
lbl85:
                        // 2 sources

                        switch ((int)v9) {
                            case -1479094324: {
                                v10 = 7200965627126348238L - -5667288599038367989L;
                                continue block28;
                            }
                            case -507767149: {
                                v10 = 2913937838602881807L ^ -2894263323417696909L;
                                continue block28;
                            }
                            case 141306124: {
                                break block28;
                            }
                            case 1391771384: {
                                v10 = -4320868384393948180L - 8864359743916319361L;
                                continue block28;
                            }
                        }
                        break;
                    }
                    while (true) {
                        if ((v11 = (cfr_temp_2 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (2424646877509967321L ^ 7343330820256498446L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                        if (v11 == (7364653569434146770L == 7364653569434146771L ? -1884873137 : 1455453307 ^ 1455453306)) {
                            if (!CRACKME_1f7bf84e_a0cb_4498_bd82_f12eb40cdc5b1361eb4c.getValue().equalsIgnoreCase(CRACKME_1f7bf84e_a0cb_4498_bd82_f12eb40cdc5b5ec48253)) ** break;
                            break block27;
                        }
                        v11 = -1222414545 ^ -489528219;
                    }
                    break;
                }
                while (true) {
                    if ((v12 = (cfr_temp_3 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-3076566751285073307L - 5298460452834667196L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                    if (v12 == (1049038976 ^ 1049038977)) break;
                    if (4967533757437158667L == 4967533757437158668L) {
                        v12 = 1457879927;
                        continue;
                    }
                    v12 = 324754770 ^ 1488493846;
                }
                while (true) {
                    if ((v13 = (cfr_temp_4 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (2938773708817660435L ^ 1765888142733251323L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                    if (v13 == (68630598 ^ 68630599)) {
                        v14 = new StringBuilder();
                        if (-282406911977112840L == -282406911977112839L) {
                            break;
                        }
                        break block47;
                    }
                    if (-4296683165971589387L == -4296683165971589386L) {
                        v13 = 1475919575;
                        continue;
                    }
                    v13 = 1277143448 - 1516515910;
                }
                v15 = -139611229;
                break block53;
            }
            v15 = -240546088 ^ -240546087;
        }
        var4_3 = new byte[v15];
        var4_3[-1704071370 ^ -1704071370] = -517294715 ^ -517294682;
        v16 = new String(var4_3, "UTF-8");
        while (true) {
            if ((v17 = (cfr_temp_5 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-4192495268630152007L ^ -5592052815408479523L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v17 == (-1735733890 ^ 1735733889)) break;
            v17 = 1848673965 ^ 1952606577;
        }
        v18 = v14.append(v16);
        while (true) {
            if ((v19 = (cfr_temp_6 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (9163319406565952224L ^ -7473661400007549808L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v19 == (1523446600 ^ 1523446601)) break;
            if (-8381479102490184716L == -8381479102490184715L) {
                v19 = -687924202;
                continue;
            }
            v19 = -280585283 ^ -984011707;
        }
        v20 = CRACKME_1f7bf84e_a0cb_4498_bd82_f12eb40cdc5b1361eb4c.getKey();
        v21 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        block34: while (true) {
            switch ((int)v21) {
                case 141306124: {
                    break block34;
                }
                case 1900090593: {
                    v21 = (-5642804881337759962L ^ 1681158320120255801L) / (4490491965333033581L ^ -6127275345606481589L);
                    continue block34;
                }
            }
            break;
        }
        v22 = v18.append(v20);
        v23 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl161
        block35: while (true) {
            v23 = v24 / (-3469949806763092527L == -3469949806763092526L ? -5602647689913819106L : 4640430512019131381L - 3073898136062452034L);
lbl161:
            // 2 sources

            switch ((int)v23) {
                case -408098159: {
                    v24 = -3013658777325942736L ^ -1378772811784244399L;
                    continue block35;
                }
                case 141306124: {
                    break block35;
                }
                case 1738669126: {
                    if (7995658513290310205L == 7995658513290310206L) {
                        v24 = 6794383294751464473L;
                        continue block35;
                    }
                    v24 = 3560738868638963642L ^ -4271145748724528874L;
                    continue block35;
                }
            }
            break;
        }
        return v22.toString();
    }

    /*
     * Unable to fully structure code
     */
    static {
        8\u0105ja.CRACKME_BITCH = new String[13];
        8\u0105ja.CRACKME_BITCH[0] = "\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800    ";
        8\u0105ja.CRACKME_BITCH[1] = "\u2800\u2800\u2800\u2800\u28e0\u28f6\u287e\u280f\u2809\u2819\u2833\u28a6\u2840\u2800\u2800\u2800\u28a0\u281e\u2809\u2819\u2832\u2840\u2800    ";
        8\u0105ja.CRACKME_BITCH[2] = "\u2800\u2800\u2800\u28f4\u283f\u280f\u2800\u2800\u2800\u2800\u2800\u2800\u28b3\u2840\u2800\u284f\u2800\u2800\u2800\u2800\u2800\u28b7     ";
        8\u0105ja.CRACKME_BITCH[3] = "\u2800\u2800\u28a0\u28df\u28cb\u2840\u2880\u28c0\u28c0\u2840\u2800\u28c0\u2840\u28e7\u2800\u28b8\u2800\u2800\u2800\u2800\u2800 \u2847    ";
        8\u0105ja.CRACKME_BITCH[4] = "\u2800\u2800\u28b8\u28ef\u286d\u2801\u2838\u28db\u28df\u2806\u2874\u28fb\u2872\u28ff\u2800\u28f8\u2800\u2800OK\u2800 \u2847    ";
        8\u0105ja.CRACKME_BITCH[5] = "\u2800\u2800\u28df\u28ff\u286d\u2800\u2800\u2800\u2800\u2800\u28b1\u2800\u2800\u28ff\u2800\u28b9\u2800\u2800\u2800\u2800\u2800 \u2847    ";
        8\u0105ja.CRACKME_BITCH[6] = "\u2800\u2800\u2819\u28bf\u28ef\u2804\u2800\u2800\u2800\u2880\u2840\u2800\u2800\u287f\u2800\u2800\u2847\u2800\u2800\u2800\u2800\u287c     ";
        8\u0105ja.CRACKME_BITCH[7] = "\u2800\u2800\u2800\u2800\u2839\u28f6\u2806\u2800\u2800\u2800\u2800\u2800\u2874\u2803\u2800\u2800\u2818\u2824\u28c4\u28e0\u281e\u2800     ";
        8\u0105ja.CRACKME_BITCH[8] = "\u2800\u2800\u2800\u2800\u2800\u28b8\u28f7\u2866\u28a4\u2864\u28a4\u28de\u28c1\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800    ";
        8\u0105ja.CRACKME_BITCH[9] = "\u2800\u2800\u2880\u28e4\u28f4\u28ff\u28cf\u2801\u2800\u2800\u2838\u28cf\u28af\u28f7\u28d6\u28e6\u2840\u2800\u2800\u2800\u2800\u2800\u2800    ";
        8\u0105ja.CRACKME_BITCH[10] = "\u2880\u28fe\u28fd\u28ff\u28ff\u28ff\u28ff\u281b\u28b2\u28f6\u28fe\u2889\u2877\u28ff\u28ff\u2835\u28ff\u2800\u2800\u2800\u2800\u2800\u2800    ";
        8\u0105ja.CRACKME_BITCH[11] = "\u28fc\u28ff\u280d\u2809\u28ff\u286d\u2809\u2819\u28ba\u28c7\u28fc\u284f\u2800\u2800\u2800\u28c4\u28b8\u2800\u2800\u2800\u2800\u2800\u2800    ";
        8\u0105ja.CRACKME_BITCH[12] = "\u28ff\u28ff\u28e7\u28c0\u28ff.........\u28c0\u28f0\u28cf\u28d8\u28c6\u28c0\u2800\u2800       ";
        if (8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == 2116177955457101672L >>> "\u0000\u0000".length()) {
            -172277269 ^ -172277270;
        } else {
            v0 = -1496439141 ^ -1496439141;
        }
        v1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl27
        block54: while (true) {
            v1 = v2 / (3127846849717324936L ^ 4504679854564454091L);
lbl27:
            // 2 sources

            switch ((int)v1) {
                case -2143447775: {
                    v2 = 323833713833611503L ^ 916278203542358740L;
                    continue block54;
                }
                case 141306124: {
                    break block54;
                }
                case 553478467: {
                    v2 = -5684898937780555084L - 30285578866098289L;
                    continue block54;
                }
                case 1756305375: {
                    v2 = 8984021036678129326L ^ 8484054480240297718L;
                    continue block54;
                }
            }
            break;
        }
        v3 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl43
        block55: while (true) {
            v3 = (-6928092312547741594L ^ 4153014653085763403L) / v4;
lbl43:
            // 2 sources

            switch ((int)v3) {
                case -2056584713: {
                    v4 = -8950017556265947019L - 156475115133465050L;
                    continue block55;
                }
                case 141306124: {
                    break block55;
                }
            }
            break;
        }
        8\u0105ja.\u0118\u01790F = new ConcurrentHashMap<Integer, String>();
        while (true) {
            if ((v5 = (cfr_temp_0 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-5798592428433676165L - 2855484425453509668L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v5 == (-546082027 ^ -546082028)) break;
            v5 = 1820475624 - 1431372703;
        }
        v6 = new ConcurrentHashMap<Integer, Integer>();
        v7 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        block57: while (true) {
            switch ((int)v7) {
                case 141306124: {
                    break block57;
                }
                case 1650840408: {
                    v7 = (-5838145859066320936L ^ 7287467449394345732L) / (-7079605114883013762L ^ -2117848090889644000L);
                    continue block57;
                }
            }
            break;
        }
        8\u0105ja.ENMJ = v6;
        while (true) {
            if ((v8 = (cfr_temp_1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (499658364766431886L ^ -1924211298631474955L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v8 == (1969737940 ^ 1969737941)) break;
            v8 = 1181331084 - 2102380291;
        }
        v9 = new ConcurrentHashMap<Integer, String>();
        while (true) {
            block80: {
                v10 = -5804594770381606775L - -9036287196756449875L;
                cfr_temp_2 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - v10;
                v11 = cfr_temp_2 == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1);
                if (v11 == false) continue;
                v12 = -765052143 ^ -765052144;
                if (v11 != v12) break block80;
                8\u0105ja.\u0119X\u01431 = v9;
                v13 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl100
            }
            v11 = -2112194409 ^ -98592724;
        }
        block60: while (true) {
            v13 = v14 / (-3676314893590727897L ^ -9100329267855748206L);
lbl100:
            // 2 sources

            switch ((int)v13) {
                case -1912208334: {
                    v14 = 4510354155364987608L ^ 2983926344819214999L;
                    continue block60;
                }
                case -616464557: {
                    v14 = -2135492568075224301L ^ -4798094223987536244L;
                    continue block60;
                }
                case 141306124: {
                    break block60;
                }
            }
            break;
        }
        v15 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl115
        block61: while (true) {
            v15 = v16 / (-8286219594409924167L ^ 3073027164770910609L);
lbl115:
            // 2 sources

            switch ((int)v15) {
                case -377639612: {
                    v16 = -1133440051599943281L - 2864746908706553924L;
                    continue block61;
                }
                case -143654364: {
                    v16 = -8965206389825839451L - 8606236630003079980L;
                    continue block61;
                }
                case 141306124: {
                    break block61;
                }
                case 1658157518: {
                    v16 = -4594374975456248949L ^ -6133256973662653971L;
                    continue block61;
                }
            }
            break;
        }
        v17 = new ConcurrentHashMap<Integer, Integer>();
        v18 = 89671427 ^ -938221994;
        v19 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl133
        block62: while (true) {
            v19 = v20 / (-7114956732024529717L - 8422505473211090329L);
lbl133:
            // 2 sources

            switch ((int)v19) {
                case 141306124: {
                    break block62;
                }
                case 466041272: {
                    v20 = 288188408093162952L ^ 3445813091475961525L;
                    continue block62;
                }
                case 1747194486: {
                    v20 = -8626877764249093461L ^ -4641214218657939716L;
                    continue block62;
                }
            }
            break;
        }
        8\u0105ja.t9\u0142U = v17;
        -1375079254 - -664703717;
        1873558367 - 1633910921;
        v21 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        block63: while (true) {
            switch ((int)v21) {
                case 141306124: {
                    break block63;
                }
                case 264858210: {
                    v21 = (1928471633761880750L ^ -7703172060337980104L) / (-8186843997352032762L - -2549145952059926425L);
                    continue block63;
                }
            }
            break;
        }
        v22 = new ConcurrentHashMap<Integer, String>();
        while (true) {
            if ((v23 = (cfr_temp_3 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (6412714007913379161L ^ -6411588070353172001L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v23 == (522893078 ^ 522893079)) break;
            v23 = 56901435 ^ 24385526;
        }
        8\u0105ja.\u0119\u0107\u017cV = v22;
        while (true) {
            v24 = 8161437095328983286L ^ -4876993660373545089L;
            cfr_temp_4 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - v24;
            v25 = cfr_temp_4 == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1);
            if (v25 == false) continue;
            if (v25 == (309459764 ^ 309459765)) break;
            v25 = -770901988 - -650504269;
        }
        295650026 ^ -2000806213;
        v26 = new ConcurrentHashMap<Integer, Double>();
        while (true) {
            if ((v27 = (cfr_temp_5 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (3903140721775321253L - 2997541440804408606L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v27 == (-733191705 ^ -733191706)) break;
            v27 = -414801373 ^ 515178145;
        }
        8\u0105ja.\u01189\u0107\u0105 = v26;
        while (true) {
            if ((v28 = (cfr_temp_6 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (6967357490905072084L - 833203002668554257L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v28 == (1869096141 ^ 1869096140)) break;
            v28 = -1692816298 - 1383298320;
        }
        while (true) {
            if ((v29 = (cfr_temp_7 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (9066657887663674104L ^ -8430989404446991566L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
            if (v29 == (490049618 ^ 490049619)) break;
            v29 = -372251224 ^ -1624445908;
        }
        v30 = new ConcurrentHashMap<String, Map<Integer, String>>();
        v31 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        block69: while (true) {
            switch ((int)v31) {
                case -1899743179: {
                    v31 = (1380097872763948485L ^ -7731225513390030761L) / (5116505311204099813L - 8529413011867134195L);
                    continue block69;
                }
                case 141306124: {
                    break block69;
                }
            }
            break;
        }
        8\u0105ja.\u017bxh\u0143 = v30;
        1966291818 ^ 960748632;
        v32 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl212
        block70: while (true) {
            v32 = v33 / (-6893301343668480948L >>> "\u0000\u0000".length());
lbl212:
            // 2 sources

            switch ((int)v32) {
                case -897742798: {
                    v33 = -4041143381702081189L ^ -4350496241164614160L;
                    continue block70;
                }
                case 141306124: {
                    break block70;
                }
                case 1465839931: {
                    v33 = 1021466626490151766L ^ 8280452682111790232L;
                    continue block70;
                }
            }
            break;
        }
        v34 = -1589259091 ^ 1558128650;
        v35 = new ConcurrentHashMap<String, Map<Integer, Integer>>();
        while (true) {
            v36 = -4336965694223656560L >>> "\u0000\u0000".length();
            cfr_temp_8 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - v36;
            v37 = cfr_temp_8 == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1);
            if (v37 == false) continue;
            if (v37 == (2030436727 ^ 2030436726)) break;
            v37 = 715478560 - 1886967118;
        }
        8\u0105ja.\u0107\u017ceK = v35;
        while (true) {
            block81: {
                v38 = -8723131870426600643L ^ -634235125108085967L;
                cfr_temp_9 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - v38;
                v39 = cfr_temp_9 == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1);
                if (v39 == false) continue;
                if (v39 != -1798462734 - -1798462733) break block81;
                8\u0105ja.\u0142Dzn = null;
                8\u0105ja.CG\u0142o = -8727329535291584790L ^ -8727329535291584790L;
                v40 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl252
            }
            v39 = 2055605829 ^ -862342974;
        }
        block73: while (true) {
            v40 = v41 / (363976547777705863L ^ -3968879405657931426L);
lbl252:
            // 2 sources

            switch ((int)v40) {
                case -1910994761: {
                    v41 = 1156054040069953864L ^ -2474082500262338467L;
                    continue block73;
                }
                case -981757419: {
                    v41 = 7500965656396717836L - 2411743433534644431L;
                    continue block73;
                }
                case 141306124: {
                    break block73;
                }
                case 1474435371: {
                    v41 = 7699071006405129758L - 2487465408403967593L;
                    continue block73;
                }
            }
            break;
        }
        v42 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl269
        block74: while (true) {
            v42 = v43 / (9217887967999617537L - 7563876524029672834L);
lbl269:
            // 2 sources

            switch ((int)v42) {
                case -1324983663: {
                    v43 = -1270424747468411045L ^ 6895230266803775173L;
                    continue block74;
                }
                case -696012244: {
                    v43 = 2904439716633401807L - 5378746698343421024L;
                    continue block74;
                }
                case 141306124: {
                    break block74;
                }
            }
            break;
        }
        v44 = new DRHn();
        while (true) {
            if ((v45 = (cfr_temp_10 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (3730019366725921041L - 9039537424997392240L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
            if (v45 == (-451638183 ^ -451638184)) break;
            v45 = -1727152460 ^ -377800497;
        }
        -1312767542 - -1306043786;
        while (true) {
            if ((v46 = (cfr_temp_11 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-8180682477602543641L ^ -3235934421112070885L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
            v47 = -663757258 - -663757257;
            if (v46 == v47) {
                v44.runTaskTimer((Plugin)zNb\u015b.Y\u017btq, 4119999257729271147L ^ 4119999257729271147L, 2266811075873092250L ^ 2266811075873092350L);
                return;
            }
            v46 = -2016355193 - 530434440;
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     */
    public static String iBOREOeUJkR6N4Y0(int n) {
        int CRACKME_b36ac47a_d044_44d8_b88f_fa4520a50117b4a02e78;
        long l = 0x1A29AFF794D5E536L ^ 0xB3E8A55A7B46FDA3L;
        if (CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == l) {
            int n2 = 0x93B48B54 ^ 0x93B48B55;
        } else {
            int cfr_ignored_3 = 0xBE0B6D91 ^ 0xBE0B6D91;
        }
        long l2 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        boolean bl = true;
        block16: while (true) {
            long l3;
            if (!bl || (bl = false) || !true) {
                long l4 = -8908133539104478176L >>> "\u0000\u0000".length();
                l2 = l3 / l4;
            }
            switch ((int)l2) {
                case -503095731: {
                    l3 = 0xE0BE1ADE7BC083E9L ^ 0x1D7D2F3F1D6AF216L;
                    continue block16;
                }
                case 141306124: {
                    break block16;
                }
                case 325191254: {
                    l3 = -1860261957029151884L - -5572953271310012710L;
                    continue block16;
                }
                case 1917281753: {
                    l3 = 0xC0207D47FFC5FD5DL ^ 0xDD22C5AEB2E7EE88L;
                    continue block16;
                }
            }
            break;
        }
        8\u0105ja.zsjN3N7fF6D1WUzb();
        long l5 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        boolean bl2 = true;
        block17: while (true) {
            long l6;
            if (!bl2 || (bl2 = false) || !true) {
                l5 = l6 / (7658377294570385977L - 7572195368606243742L);
            }
            switch ((int)l5) {
                case -1232046391: {
                    l6 = 0xE51C35BDB384C40CL ^ 0x89545D5346A33B28L;
                    continue block17;
                }
                case -877569229: {
                    l6 = 0x13926A1E7AEBE4B7L ^ 0x43DCD34C060894AAL;
                    continue block17;
                }
                case 141306124: {
                    break block17;
                }
                case 989311872: {
                    l6 = -1744943407349181900L >>> "\u0000\u0000".length();
                    continue block17;
                }
            }
            break;
        }
        int n3 = 0x63253C26 ^ 0x14D03DF6;
        long l7 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        boolean bl3 = true;
        block18: while (true) {
            long l8;
            if (!bl3 || (bl3 = false) || !true) {
                l7 = (0xED7524E8294913CBL ^ 0x9B8DFE68662C9C41L) / l8;
            }
            switch ((int)l7) {
                case 141306124: {
                    break block18;
                }
                case 941168270: {
                    l8 = 6677210103828600842L - 7643672205594612680L;
                    continue block18;
                }
            }
            break;
        }
        String CRACKME_b36ac47a_d044_44d8_b88f_fa4520a501174b65b8a4 = \u0118\u01790F.getOrDefault(CRACKME_b36ac47a_d044_44d8_b88f_fa4520a50117b4a02e78, null);
        if (CRACKME_b36ac47a_d044_44d8_b88f_fa4520a501174b65b8a4 != null) return CRACKME_b36ac47a_d044_44d8_b88f_fa4520a501174b65b8a4;
        int cfr_ignored_4 = 0xED675AB3 ^ 0x2D20573E;
        byte[] byArray = new byte[0xBDEBFA84 ^ 0xBDEBFA83];
        byArray[0x89C4F0B ^ 0x89C4F0B] = 0xD5906A00 ^ 0x2A6F95C2;
        byArray[0x59C13AC0 ^ 0x59C13AC6] = 0xF224FD3E ^ 0xF224FD75;
        int n4 = 0xDBAF243B ^ 0xDBAF243A;
        byArray[n4] = 0x862A2950 ^ 0x79D5D6F7;
        int n5 = 0xC69418C3 ^ 0xC69418C7;
        byArray[n5] = 0x2F219EE0 ^ 0x2F219EB2;
        byArray[0x6035B6D6 ^ 0x6035B6D4] = 0x8346DD56 ^ 0x8346DD35;
        byArray[0x2B8F4E11 ^ 0x2B8F4E12] = 0xAACF2636 ^ 0xAACF2674;
        int n6 = 0xCCC06D9E ^ 0xCCC06DDF;
        byArray[0x629EF703 ^ 0x629EF706] = n6;
        return new String(byArray, "UTF-8");
    }

    /*
     * Unable to fully structure code
     */
    private static void U1ikgPkTk-86L1xW(Map<String, Integer> var0, Map<Integer, String> var1_1, Map<Integer, Integer> var2_2) {
        if (8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == -1303773858720084541L - -666585259783321197L) {
            if ((1692211032 ^ -915099082 ^ (672319018 ^ 1475164629)) != 0) {
                -1545505671 ^ -1545505672;
            }
        } else {
            1940525422 ^ 1940525422;
        }
        while (true) {
            if ((v0 = (cfr_temp_0 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-8598835137513715668L ^ 3507067529732495218L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (-683959464 ^ -683959463)) break;
            v0 = 1036831526 - 869332187;
        }
        v1 = CRACKME_3356ac22_925e_4d47_ba1e_14b6a72cd106ea04817f.entrySet();
        while (true) {
            if ((v2 = (cfr_temp_1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (5711037525581531754L - 2391870284848557542L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v2 == (137810742 ^ 137810743)) break;
            v2 = -1912428136 ^ 1566552515;
        }
        CRACKME_3356ac22_925e_4d47_ba1e_14b6a72cd106943b5fc4 = new ArrayList<Map.Entry<String, Integer>>(v1);
        -1255164241 ^ -1571450971;
        1870221813 ^ 1016968574;
        while (true) {
            block44: {
                if ((v3 = (cfr_temp_2 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (2847999942492635647L ^ -1271403318227378706L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v3 != (-1372640764 ^ -1372640763)) break block44;
                v4 = Collections.reverseOrder(Map.Entry.<K, V>comparingByValue());
                v5 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl50
            }
            v3 = 62180255 ^ 39436194;
        }
        block31: while (true) {
            v5 = v6 / (3861340492050072467L == 3861340492050072468L ? -1547951501634064592L : -7718000065604345645L ^ -3797255010299566252L);
lbl50:
            // 2 sources

            switch ((int)v5) {
                case -668614811: {
                    if (-3965015148895622589L == -3965015148895622588L) {
                        v6 = -5218825806438789359L;
                        continue block31;
                    }
                    v6 = -6554488959024706060L ^ 3452895478961851436L;
                    continue block31;
                }
                case 141306124: {
                    break block31;
                }
                case 1049585045: {
                    v6 = -706068009430164556L - 6722429581271334395L;
                    continue block31;
                }
            }
            break;
        }
        CRACKME_3356ac22_925e_4d47_ba1e_14b6a72cd106943b5fc4.sort(v4);
        var4_4 = 940574258 ^ 940574258;
        while (true) {
            block45: {
                if ((v7 = (cfr_temp_3 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (5771037686870925943L == 5771037686870925944L ? -8583734766253467982L : -4307259481751138559L ^ 1714797279247357061L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v7 != (1624530212 ^ 1624530213)) break block45;
                if (CRACKME_3356ac22_925e_4d47_ba1e_14b6a72cd1060c9f942a >= CRACKME_3356ac22_925e_4d47_ba1e_14b6a72cd106943b5fc4.size()) return;
                v8 = CRACKME_3356ac22_925e_4d47_ba1e_14b6a72cd1060c9f942a + (1974206213 ^ 1974206212);
                v9 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl98
            }
            v7 = 1547219889 - 1497592814;
            continue;
            block33: while (true) {
                v9 = v10 / (-6823372514282826386L ^ 3909965203214212039L);
lbl98:
                // 2 sources

                switch ((int)v9) {
                    case 66629443: {
                        v10 = -1960913497585872312L ^ 2381339091576966214L;
                        continue block33;
                    }
                    case 141306124: {
                        break block33;
                    }
                    case 376177687: {
                        v10 = 7973162709168084493L ^ -2475239828200775705L;
                        continue block33;
                    }
                    case 916647150: {
                        if (-5738750986567056617L == -5738750986567056616L) {
                            v10 = 7683824177288437L;
                            continue block33;
                        }
                        v10 = 5195405186547422016L - 1351157290639710231L;
                        continue block33;
                    }
                }
                break;
            }
            v11 = (int)v8;
            v12 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
            if (true) ** GOTO lbl121
            block34: while (true) {
                v12 = v13 / (4336417249983652256L ^ -23361050738485440L);
lbl121:
                // 2 sources

                switch ((int)v12) {
                    case -170384569: {
                        v13 = -7290230699182138536L ^ -1556751851142477285L;
                        continue block34;
                    }
                    case -28664244: {
                        if (-8321061276740149219L == -8321061276740149218L) {
                            v13 = -1692941667702758720L;
                            continue block34;
                        }
                        v13 = 1598986947889761426L ^ -4265352452936480159L;
                        continue block34;
                    }
                    case 141306124: {
                        break block34;
                    }
                }
                break;
            }
            var6_5 = new byte[-589787228 ^ -589787225];
            var6_5[-1734248744 ^ -1734248743] = -6214892165113762792L == -6214892165113762791L ? 1781759736 : 950998799 ^ 950998844;
            var6_5[481114245 ^ 481114247] = -2054945236316672118L == -2054945236316672117L ? 1704611820 : 792468575 ^ 792468513;
            var6_5[-1145165228 ^ -1145165228] = -30817769 ^ -30817687;
            v14 = new String(var6_5, "UTF-8");
            var6_5 = new byte[5619913834346774805L == 5619913834346774806L ? 813878537 : 1781550221 ^ 1781550220];
            var6_5[9180627283406222517L == 9180627283406222518L ? -341108219 : 1170771862 ^ 1170771862] = -8511625917952068494L == -8511625917952068493L ? 1134632113 : 1610535480 ^ 1610535446;
            v15 = ((String)((Map.Entry)CRACKME_3356ac22_925e_4d47_ba1e_14b6a72cd106943b5fc4.get((int)CRACKME_3356ac22_925e_4d47_ba1e_14b6a72cd1060c9f942a)).getKey()).replace(v14, new String(var6_5, "UTF-8"));
            1109630204 - -890489080;
            while (true) {
                block46: {
                    if ((v16 = (cfr_temp_4 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-4288931515836779132L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                    if (v16 != (-9014470990283973462L == -9014470990283973461L ? -1993676367 : 1400249411 ^ 1400249410)) break block46;
                    CRACKME_3356ac22_925e_4d47_ba1e_14b6a72cd10646492434.put(v11, v15);
                    v17 = CRACKME_3356ac22_925e_4d47_ba1e_14b6a72cd1060c9f942a + (-1240317403 ^ -1240317404);
                    v18 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                    if (true) ** GOTO lbl159
                }
                v16 = -1900470504 >>> "\u0000\u0000".length();
            }
            block36: while (true) {
                v18 = v19 / (1149038054380834088L - -2518882901616009043L);
lbl159:
                // 2 sources

                switch ((int)v18) {
                    case -1433774651: {
                        v19 = 3717147694671700580L ^ 733256359839655992L;
                        continue block36;
                    }
                    case -595337943: {
                        v19 = 3871959314112928346L ^ -5832928793180612564L;
                        continue block36;
                    }
                    case 141306124: {
                        break block36;
                    }
                    case 1220652973: {
                        v19 = -3929745316349392028L >>> "\u0000\u0000".length();
                        continue block36;
                    }
                }
                break;
            }
            v20 = (int)v17;
            v21 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
            if (true) ** GOTO lbl180
            block37: while (true) {
                v21 = v22 / (2878083160764725754L ^ -1370286850842867707L);
lbl180:
                // 2 sources

                switch ((int)v21) {
                    case -319731056: {
                        v22 = 8216575384759690779L - 5974539481032101908L;
                        continue block37;
                    }
                    case 141306124: {
                        break block37;
                    }
                    case 639606318: {
                        v22 = 2877080892679176675L ^ 2066964346367075410L;
                        continue block37;
                    }
                    case 1304955081: {
                        v22 = -6197537968059453526L ^ 6846823497377044042L;
                        continue block37;
                    }
                }
                break;
            }
            CRACKME_3356ac22_925e_4d47_ba1e_14b6a72cd106d23e84f5.put(v20, (Integer)((Map.Entry)CRACKME_3356ac22_925e_4d47_ba1e_14b6a72cd106943b5fc4.get((int)CRACKME_3356ac22_925e_4d47_ba1e_14b6a72cd1060c9f942a)).getValue());
            ++CRACKME_3356ac22_925e_4d47_ba1e_14b6a72cd1060c9f942a;
        }
    }

    /*
     * Unable to fully structure code
     */
    private static synchronized void KiRG_7P2LsN0KTrf() {
        if (8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == (6384332119851782076L ^ 7967777128045852303L)) {
            v0 = -409951656 - 1737531993;
            if ((-1372911681 ^ 1697788887 ^ v0) != 0) {
                1538037272 ^ 1538037273;
            }
        } else {
            -1471366171 ^ -1471366171;
        }
        v1 = -971500877 ^ -1893273586;
        v2 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        block107: while (true) {
            switch ((int)v2) {
                case -929268146: {
                    v2 = (-3923559579068400737L ^ 4917857946873135153L) / (-3975030883137207007L - 4688616889049776065L);
                    continue block107;
                }
                case 141306124: {
                    break block107;
                }
            }
            break;
        }
        v3 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl31
        block108: while (true) {
            v4 = -5362323360100257196L ^ -899996501910492113L;
            v3 = v5 / v4;
lbl31:
            // 2 sources

            switch ((int)v3) {
                case -1702988824: {
                    v5 = 4965247230474654273L - 8287597583663037674L;
                    continue block108;
                }
                case 141306124: {
                    break block108;
                }
                case 545332045: {
                    v5 = -3597851299678067662L ^ -3649406536336551142L;
                    continue block108;
                }
                case 747392170: {
                    v5 = 1764420991115351654L ^ 2502123714277850590L;
                    continue block108;
                }
            }
            break;
        }
        v6 = zNb\u015b.Y\u017btq.getConfig();
        var10 = new byte[-1823784208 ^ -1823784197];
        var10[483121134 ^ 483121129] = -1859028878 ^ -1859028964;
        v7 = 628998557 ^ 628998555;
        var10[v7] = 1115545550 ^ 1115545489;
        var10[1516507682 ^ 1516507688] = 1376920637 ^ 1376920664;
        v8 = -2135664860 ^ -2135664859;
        var10[v8] = -1737104641 ^ -1737104746;
        v9 = 1780539367 ^ 1780539362;
        var10[v9] = -1446936751 ^ -1446936774;
        var10[-1697753900 ^ -1697753892] = -1426737277 ^ -1426737182;
        var10[115481347 ^ 115481354] = 167156514 ^ 167156559;
        var10[-1782640889 ^ -1782640889] = -260990037 ^ -260989985;
        v10 = -1194165881 ^ -1194165883;
        var10[v10] = 406467695 ^ 406467588;
        var10[1332220518 ^ 1332220517] = 967892140 ^ 967892184;
        var10[-1642360149 ^ -1642360145] = 80169392 ^ 80169439;
        v11 = new String(var10, "UTF-8");
        v12 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl65
        block109: while (true) {
            v12 = v13 / (4427471801812971652L >>> "\u0000\u0000".length());
lbl65:
            // 2 sources

            switch ((int)v12) {
                case 135492666: {
                    v13 = -7651039024764646600L ^ 7485608052846595802L;
                    continue block109;
                }
                case 141306124: {
                    break block109;
                }
            }
            break;
        }
        v14 = v6.getString(v11);
        var10 = new byte[-1923683061 ^ -1923683062];
        var10[1183769617 ^ 1183769617] = 994786682 ^ 994786644;
        v15 = new String(var10, "UTF-8");
        var10 = new byte[373837519 ^ 373837518];
        v16 = 1286212113 ^ 1286212113;
        v17 = 2140163276 ^ 2140163297;
        var10[v16] = v17;
        v18 = new String(var10, "UTF-8");
        -27064491 - 1311553162;
        while (true) {
            if ((v19 = (cfr_temp_0 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-8699250745033405913L ^ -1467270826080408070L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            v20 = -300342556 ^ 300342555;
            if (v19 == v20) break;
            v19 = 1640324461 - -2112603576;
        }
        var0_1 = v14.replace(v15, v18);
        -589779079 - 826178579;
        while (true) {
            block152: {
                if ((v21 = (cfr_temp_1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-2110140294491383205L - -5621502201178145231L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v21 != (384914488 ^ 384914489)) break block152;
                var1_2 = new ConcurrentHashMap<K, V>();
                v22 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl115
            }
            v21 = -784441871 ^ 249246710;
        }
        block112: while (true) {
            v22 = (-4593408049168817352L - -3805195104861719253L) / v23;
lbl115:
            // 2 sources

            switch ((int)v22) {
                case -166410974: {
                    v23 = -8121061212373704146L ^ 7087466635785845363L;
                    continue block112;
                }
                case 141306124: {
                    break block112;
                }
            }
            break;
        }
        while (true) {
            block153: {
                if ((v24 = (cfr_temp_2 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (1290330717971689507L ^ -1248075845407523375L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v24 != (-1522871307 ^ -1522871308)) break block153;
                var2_3 = new ConcurrentHashMap<K, V>();
                v25 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl142
            }
            v24 = -72785827 - -2104021441;
        }
        block114: while (true) {
            v26 = 7670107269374033802L - -8109628660868046977L;
            v25 = v27 / v26;
lbl142:
            // 2 sources

            switch ((int)v25) {
                case -912451521: {
                    v27 = 8643710338522035535L - 2511852815844595934L;
                    continue block114;
                }
                case -110576327: {
                    v27 = 990672607116831402L ^ -4238499920990101303L;
                    continue block114;
                }
                case 141306124: {
                    break block114;
                }
            }
            break;
        }
        var3_4 = new ConcurrentHashMap<K, V>();
        v28 = 1604452813 ^ -309828403;
        while (true) {
            v29 = -238125833926614682L ^ 2915238500275674405L;
            cfr_temp_3 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - v29;
            v30 = cfr_temp_3 == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1);
            if (v30 == false) continue;
            if (v30 == (762226320 ^ 762226321)) break;
            v30 = 1616069357 - -994679026;
        }
        while (true) {
            if ((v31 = (cfr_temp_4 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (9083965998856055134L - 4590415620475084493L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v31 == (-1390241285 ^ -1390241286)) break;
            v31 = 1567954107 ^ -1339342983;
        }
        CRACKME_27fb877a_8a84_42d0_afcc_9a7cd357181f6dfbd390 = new ConcurrentHashMap<Integer, Integer>();
        v32 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        block117: while (true) {
            switch ((int)v32) {
                case 141306124: {
                    break block117;
                }
                case 1414939024: {
                    v32 = (-4766430786144860715L - -5872814552423216082L) / (-4224870791755399403L ^ 3292739504520779920L);
                    continue block117;
                }
            }
            break;
        }
        -21339424 - -1321893704;
        while (true) {
            block154: {
                v33 = 3219822473737729195L ^ -7508491787710627828L;
                cfr_temp_5 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - v33;
                v34 = cfr_temp_5 == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1);
                if (v34 == false) continue;
                v35 = -2146259986 ^ -2146259985;
                if (v34 != v35) break block154;
                var5_6 = new ConcurrentHashMap<K, V>();
                v36 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl203
            }
            v34 = 834820348 - -162779212;
        }
        block119: while (true) {
            v36 = v37 / (-6510651655273061555L ^ 658776493162725120L);
lbl203:
            // 2 sources

            switch ((int)v36) {
                case -1638016365: {
                    v37 = -7943476703784228536L ^ -6016564948680844404L;
                    continue block119;
                }
                case 141306124: {
                    break block119;
                }
                case 2140898857: {
                    v37 = 3456163949355696578L ^ 7620658803775420969L;
                    continue block119;
                }
            }
            break;
        }
        v38 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        block120: while (true) {
            switch ((int)v38) {
                case 141306124: {
                    break block120;
                }
                case 1150825761: {
                    v38 = (1597246074099415804L >>> "\u0000\u0000".length()) / (-1705810542735211013L - 8456273710607174973L);
                    continue block120;
                }
            }
            break;
        }
        var6_7 = new ConcurrentHashMap<K, V>();
        v39 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl229
        block121: while (true) {
            v39 = v40 / (-3098693911637529681L ^ -6674810795852330160L);
lbl229:
            // 2 sources

            switch ((int)v39) {
                case -2121011389: {
                    v40 = 2720799273982308898L - 2954656428486390739L;
                    continue block121;
                }
                case -1243188285: {
                    v40 = 4440378942099406452L ^ 3123695605986461862L;
                    continue block121;
                }
                case -1097657519: {
                    v40 = 5267148361105363429L ^ -879375716529711673L;
                    continue block121;
                }
                case 141306124: {
                    break block121;
                }
            }
            break;
        }
        var7_8 = new ConcurrentHashMap<K, V>();
        v41 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl257
        block122: while (true) {
            v42 = -6917690551161579291L - 3651807633025339828L;
            v41 = v43 / v42;
lbl257:
            // 2 sources

            switch ((int)v41) {
                case -1863279284: {
                    v43 = 4596818433116464064L ^ 5498735360008186497L;
                    continue block122;
                }
                case -912126997: {
                    v43 = 6622018795040563404L ^ 3896351926935582857L;
                    continue block122;
                }
                case 141306124: {
                    break block122;
                }
            }
            break;
        }
        v44 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl272
        block123: while (true) {
            v45 = 1725793939253769484L >>> "\u0000\u0000".length();
            v44 = v46 / v45;
lbl272:
            // 2 sources

            switch ((int)v44) {
                case -1075238905: {
                    v46 = 6054289340333007279L ^ -3913061649553012155L;
                    continue block123;
                }
                case 141306124: {
                    break block123;
                }
                case 1269325724: {
                    v46 = -6998817176930729101L - 7602072847842057091L;
                    continue block123;
                }
                case 1993780108: {
                    v46 = 236788739535954300L >>> "\u0000\u0000".length();
                    continue block123;
                }
            }
            break;
        }
        CRACKME_27fb877a_8a84_42d0_afcc_9a7cd357181f02fa7b56 = new ConcurrentHashMap<String, Map<Integer, Integer>>();
        -727393731 - 1912864361;
        v47 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl300
        block124: while (true) {
            v48 = 6832607463785199317L ^ -6331832390646186754L;
            v47 = v49 / v48;
lbl300:
            // 2 sources

            switch ((int)v47) {
                case -1713577787: {
                    v49 = -545587391868096558L - -7525325891085936325L;
                    continue block124;
                }
                case -451120186: {
                    v49 = 7132307419673032668L ^ -496283162286704977L;
                    continue block124;
                }
                case 141306124: {
                    break block124;
                }
            }
            break;
        }
        8\u0105ja.56joq7rvWcJQhWto((String)CRACKME_27fb877a_8a84_42d0_afcc_9a7cd357181f31f83f56, (Map<Integer, String>)CRACKME_27fb877a_8a84_42d0_afcc_9a7cd357181f99082451, (Map<Integer, Integer>)CRACKME_27fb877a_8a84_42d0_afcc_9a7cd357181f3fee13df);
        while (true) {
            if ((v50 = (cfr_temp_6 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (7358170232735612289L ^ 2943026945588075511L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v50 == (2031388867 ^ 2031388866)) break;
            v50 = 1001379251 ^ -1124948;
        }
        8\u0105ja.e0u__HzQOcgTkM1m((String)CRACKME_27fb877a_8a84_42d0_afcc_9a7cd357181f31f83f56, (Map<Integer, String>)CRACKME_27fb877a_8a84_42d0_afcc_9a7cd357181f0dcf8916, CRACKME_27fb877a_8a84_42d0_afcc_9a7cd357181f6dfbd390);
        67006257 ^ 267808258;
        while (true) {
            if ((v51 = (cfr_temp_7 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (6497544250251430248L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
            if (v51 == (-1279179215 ^ -1279179216)) break;
            v51 = -252547846 - -2107730081;
        }
        8\u0105ja.ewJhNZpZ9rfUOKa5((String)CRACKME_27fb877a_8a84_42d0_afcc_9a7cd357181f31f83f56, (Map<Integer, String>)CRACKME_27fb877a_8a84_42d0_afcc_9a7cd357181fa8fddd95, (Map<Integer, Double>)CRACKME_27fb877a_8a84_42d0_afcc_9a7cd357181f733a464b);
        2019619605 - 679226640;
        while (true) {
            block155: {
                v52 = -1962661042468233061L ^ -7026283019617053981L;
                cfr_temp_8 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - v52;
                v53 = cfr_temp_8 == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1);
                if (v53 == false) continue;
                v54 = -750810451 - -750810450;
                if (v53 != v54) break block155;
                8\u0105ja.AaWsD1RkfCUBqn0M((String)CRACKME_27fb877a_8a84_42d0_afcc_9a7cd357181f31f83f56, (Map<String, Map<Integer, String>>)CRACKME_27fb877a_8a84_42d0_afcc_9a7cd357181f939817c4, CRACKME_27fb877a_8a84_42d0_afcc_9a7cd357181f02fa7b56);
                v55 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl357
            }
            v53 = 904404626 ^ 1390150886;
        }
        block128: while (true) {
            v56 = 5396581506669104751L ^ 8741926523958848875L;
            v55 = v57 / v56;
lbl357:
            // 2 sources

            switch ((int)v55) {
                case -735419115: {
                    v57 = -8526593794566811076L - -8991878251648400462L;
                    continue block128;
                }
                case -729423400: {
                    v57 = 7843786625627327232L ^ -2816289696729751596L;
                    continue block128;
                }
                case 141306124: {
                    break block128;
                }
            }
            break;
        }
        1513381805 - -1407755528;
        while (true) {
            block156: {
                if ((v58 = (cfr_temp_9 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-6691228930210202953L - -7675548431983711186L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                if (v58 != (-1485991409 ^ -1485991410)) break block156;
                8\u0105ja.\u0118\u01790F.clear();
                v59 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl381
            }
            v58 = -1322822761 - -505190839;
        }
        block130: while (true) {
            v59 = v60 / (-8213868491043617174L ^ 2436890721400599425L);
lbl381:
            // 2 sources

            switch ((int)v59) {
                case -1166817490: {
                    v60 = -7631244412857114927L - 5045418067597920199L;
                    continue block130;
                }
                case -1070963065: {
                    v60 = -4295203686626202732L >>> "\u0000\u0000".length();
                    continue block130;
                }
                case 141306124: {
                    break block130;
                }
                case 1926242892: {
                    v60 = 5641877458579127856L >>> "\u0000\u0000".length();
                    continue block130;
                }
            }
            break;
        }
        8\u0105ja.\u0118\u01790F.putAll((Map<Integer, String>)CRACKME_27fb877a_8a84_42d0_afcc_9a7cd357181f99082451);
        v61 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl403
        block131: while (true) {
            v61 = v62 / (8963003797784549278L - -2316926662993121922L);
lbl403:
            // 2 sources

            switch ((int)v61) {
                case 141306124: {
                    break block131;
                }
                case 230485918: {
                    v62 = -7671319216299184665L ^ -4997225236168111768L;
                    continue block131;
                }
                case 803796686: {
                    v62 = -4977127906632291540L ^ -5286005930240857936L;
                    continue block131;
                }
            }
            break;
        }
        while (true) {
            block157: {
                v63 = -637085367141350415L ^ 347717346155087052L;
                cfr_temp_10 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - v63;
                v64 = cfr_temp_10 == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1);
                if (v64 == false) continue;
                if (v64 != (225424080 ^ 225424081)) break block157;
                8\u0105ja.ENMJ.clear();
                v65 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl433
            }
            v64 = 1519153046 ^ -563986164;
        }
        block133: while (true) {
            v65 = v66 / (-285139125320325743L - -3414767560017673422L);
lbl433:
            // 2 sources

            switch ((int)v65) {
                case -1352374115: {
                    v66 = -7570731198890530621L ^ 5443514115046478401L;
                    continue block133;
                }
                case 141306124: {
                    break block133;
                }
                case 1713853262: {
                    v66 = 5080945406832212322L ^ 7217759931512499358L;
                    continue block133;
                }
                case 1807956133: {
                    v66 = -3191092921897432699L - -2856520255399252671L;
                    continue block133;
                }
            }
            break;
        }
        while (true) {
            if ((v67 = (cfr_temp_11 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (6925342394500467473L ^ 2112641552772236482L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
            if (v67 == 1473735075 - 1473735076) break;
            v67 = 1365974249 - -263624748;
        }
        8\u0105ja.ENMJ.putAll((Map<Integer, Integer>)CRACKME_27fb877a_8a84_42d0_afcc_9a7cd357181f3fee13df);
        while (true) {
            block158: {
                v68 = -418836732030374743L - 4052537410326740642L;
                cfr_temp_12 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - v68;
                v69 = cfr_temp_12 == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1);
                if (v69 == false) continue;
                if (v69 != (-180264555 ^ -180264556)) break block158;
                8\u0105ja.\u0119X\u01431.clear();
                v70 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl467
            }
            v69 = 1535454654 - 1678968150;
        }
        block136: while (true) {
            v71 = 2993676053543814725L - 2166987538785084955L;
            v70 = v72 / v71;
lbl467:
            // 2 sources

            switch ((int)v70) {
                case -1924489164: {
                    v72 = 7835289778524773375L ^ -6469908359305946861L;
                    continue block136;
                }
                case -850114396: {
                    v72 = -8433223720597069347L ^ 6923355195956645270L;
                    continue block136;
                }
                case 141306124: {
                    break block136;
                }
                case 537143624: {
                    v72 = -4428731418512811024L ^ -7903953660740576945L;
                    continue block136;
                }
            }
            break;
        }
        while (true) {
            if ((v73 = (cfr_temp_13 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-4218699322063771470L - 7974680858737484927L)) == 0L ? 0 : (cfr_temp_13 < 0L ? -1 : 1)) == false) continue;
            if (v73 == (-227080201 ^ -227080202)) break;
            v73 = -1155401697 ^ 1675815956;
        }
        8\u0105ja.\u0119X\u01431.putAll((Map<Integer, String>)CRACKME_27fb877a_8a84_42d0_afcc_9a7cd357181f0dcf8916);
        while (true) {
            if ((v74 = (cfr_temp_14 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (8139311355854567719L - 8270965209549438607L)) == 0L ? 0 : (cfr_temp_14 < 0L ? -1 : 1)) == false) continue;
            if (v74 == (76571234 ^ 76571235)) break;
            v74 = 2135078186 ^ 1834547104;
        }
        8\u0105ja.t9\u0142U.clear();
        -351093980 ^ 626330208;
        v75 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        block139: while (true) {
            switch ((int)v75) {
                case 141306124: {
                    break block139;
                }
                case 607936397: {
                    v75 = (5702800085584035570L ^ -1514580660104894316L) / (1474900477297390754L - -2585151417396419924L);
                    continue block139;
                }
            }
            break;
        }
        8\u0105ja.t9\u0142U.putAll(CRACKME_27fb877a_8a84_42d0_afcc_9a7cd357181f6dfbd390);
        while (true) {
            v76 = 5778133142835827108L - -990334116009657874L;
            cfr_temp_15 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - v76;
            v77 = cfr_temp_15 == 0L ? 0 : (cfr_temp_15 < 0L ? -1 : 1);
            if (v77 == false) continue;
            v78 = -1180961732 ^ 1180961731;
            if (v77 == v78) break;
            v77 = -1213755259 - 83447932;
        }
        8\u0105ja.\u0119\u0107\u017cV.clear();
        8\u0105ja.\u0119\u0107\u017cV.putAll((Map<Integer, String>)CRACKME_27fb877a_8a84_42d0_afcc_9a7cd357181fa8fddd95);
        -1871571190 - 1582607565;
        while (true) {
            if ((v79 = (cfr_temp_16 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (4761153311063626388L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_16 < 0L ? -1 : 1)) == false) continue;
            if (v79 == (2107974827 ^ 2107974826)) break;
            v79 = 871521950 - -825788389;
        }
        while (true) {
            v80 = -3462420270052145094L - 9025688348379302137L;
            cfr_temp_17 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - v80;
            v81 = cfr_temp_17 == 0L ? 0 : (cfr_temp_17 < 0L ? -1 : 1);
            if (v81 == false) continue;
            if (v81 == (478820584 ^ 478820585)) break;
            v81 = -301622963 - -204580340;
        }
        8\u0105ja.\u01189\u0107\u0105.clear();
        while (true) {
            if ((v82 = (cfr_temp_18 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (3780614675283134714L - -1198861641323149748L)) == 0L ? 0 : (cfr_temp_18 < 0L ? -1 : 1)) == false) continue;
            if (v82 == (-1571316172 ^ -1571316171)) break;
            v82 = -627548835 ^ 1621278980;
        }
        while (true) {
            v83 = -1850809991767370477L ^ -5429330770695415276L;
            cfr_temp_19 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - v83;
            v84 = cfr_temp_19 == 0L ? 0 : (cfr_temp_19 < 0L ? -1 : 1);
            if (v84 == false) continue;
            if (v84 == (484970343 ^ 484970342)) break;
            v84 = -146452501 - -2094768036;
        }
        8\u0105ja.\u01189\u0107\u0105.putAll((Map<Integer, Double>)CRACKME_27fb877a_8a84_42d0_afcc_9a7cd357181f733a464b);
        while (true) {
            block159: {
                if ((v85 = (cfr_temp_20 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (1052346002223999890L ^ 5216939790179121882L)) == 0L ? 0 : (cfr_temp_20 < 0L ? -1 : 1)) == false) continue;
                if (v85 != (-1551604435 ^ -1551604436)) break block159;
                8\u0105ja.\u017bxh\u0143.clear();
                v86 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl564
            }
            v85 = 1547658778 ^ 538572094;
        }
        block146: while (true) {
            v86 = v87 / (-7580768289789282719L - -4897995691465588441L);
lbl564:
            // 2 sources

            switch ((int)v86) {
                case -1317328264: {
                    v87 = 6566328259262221055L - -2048461026407650948L;
                    continue block146;
                }
                case -104212440: {
                    v87 = -2415022891286184643L ^ -6822730822143194681L;
                    continue block146;
                }
                case 141306124: {
                    break block146;
                }
                case 1142170069: {
                    v87 = -1285351317234784471L ^ -6309050806651910826L;
                    continue block146;
                }
            }
            break;
        }
        8\u0105ja.\u017bxh\u0143.putAll((Map<String, Map<Integer, String>>)CRACKME_27fb877a_8a84_42d0_afcc_9a7cd357181f939817c4);
        v88 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl584
        block147: while (true) {
            v88 = v89 / (5364745542403961019L - 7186480087962314113L);
lbl584:
            // 2 sources

            switch ((int)v88) {
                case -571659276: {
                    v89 = -4227512490773150066L ^ 7388595483437876576L;
                    continue block147;
                }
                case 141306124: {
                    break block147;
                }
                case 862075714: {
                    v89 = 8125040406814295723L ^ -2297184521474026814L;
                    continue block147;
                }
            }
            break;
        }
        v90 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl597
        block148: while (true) {
            v90 = v91 / (7858696093763286896L - -3571444335524179777L);
lbl597:
            // 2 sources

            switch ((int)v90) {
                case -98982325: {
                    v91 = 6823535721048769980L - -5882282750023275154L;
                    continue block148;
                }
                case 141306124: {
                    break block148;
                }
                case 1183714086: {
                    v91 = -8327854765117015991L ^ -3758459234107321933L;
                    continue block148;
                }
                case 1369059559: {
                    v91 = 8134788374965075836L ^ 7758636175174175544L;
                    continue block148;
                }
            }
            break;
        }
        8\u0105ja.\u0107\u017ceK.clear();
        8\u0105ja.\u0107\u017ceK.putAll(CRACKME_27fb877a_8a84_42d0_afcc_9a7cd357181f02fa7b56);
        8\u0105ja.CG\u0142o = System.currentTimeMillis();
    }

    /*
     * Unable to fully structure code
     */
    private static String gFOWaAfPEoX63PWz(String var0) {
        block68: {
            if (8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == 5587080366297331283L - 1815121517232599528L) {
                1758683595 ^ 1758683594;
            } else {
                v0 = -251601919 ^ -251601919;
            }
            v1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
            if (true) ** GOTO lbl14
            block46: while (true) {
                v1 = (9016437293693911458L ^ 7933555060713299349L) / v2;
lbl14:
                // 2 sources

                switch ((int)v1) {
                    case 141306124: {
                        break block46;
                    }
                    case 643804391: {
                        v2 = -1933677194079517763L ^ 4439891259815291227L;
                        continue block46;
                    }
                }
                break;
            }
            v3 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
            if (true) ** GOTO lbl24
            block47: while (true) {
                v3 = v4 / (-4951239304141738264L - 5593371127568663670L);
lbl24:
                // 2 sources

                switch ((int)v3) {
                    case -126421710: {
                        v4 = 1334037100640117165L ^ -997891000425928165L;
                        continue block47;
                    }
                    case 130724778: {
                        v4 = -7375545254306013458L - -4191006995808817809L;
                        continue block47;
                    }
                    case 141306124: {
                        break block47;
                    }
                }
                break;
            }
            v5 = zNb\u015b.Y\u017btq.getConfig();
            var4_1 = new byte[-1743066487 ^ -1743066494];
            var4_1[1387393805 ^ 1387393799] = -1856295240 ^ -1856295203;
            var4_1[-1133296703 ^ -1133296696] = 879148331 ^ 879148358;
            var4_1[882868825 ^ 882868828] = 1578742759 ^ 1578742668;
            var4_1[-1448541770 ^ -1448541771] = 1358220872 ^ 1358220860;
            var4_1[-155012273 ^ -155012277] = -1869857920 ^ -1869857809;
            v6 = -170531413 ^ -170531411;
            var4_1[v6] = 1588486915 ^ 1588487004;
            v7 = -1267350799 ^ -1267350791;
            v8 = -525586871 ^ -525586904;
            var4_1[v7] = v8;
            var4_1[2007882021 ^ 2007882020] = -1336836529 ^ -1336836570;
            var4_1[-508236341 ^ -508236343] = -1418969120 ^ -1418969205;
            v9 = -867130627 ^ -867130743;
            var4_1[-1735064579 ^ -1735064579] = v9;
            v10 = 409313757 ^ 409313754;
            var4_1[v10] = 823208518 ^ 823208488;
            v11 = new String(var4_1, "UTF-8");
            while (true) {
                if ((v12 = (cfr_temp_0 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-7780533874307768766L ^ 2118026947395357119L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v12 == (-644338098 ^ -644338097)) break;
                v12 = 1979759015 - -607199717;
            }
            v13 = v5.getString(v11);
            var4_1 = new byte[497601744 ^ 497601745];
            var4_1[542665328 ^ 542665328] = -1236275508 ^ -1236275486;
            v14 = new String(var4_1, "UTF-8");
            var4_1 = new byte[1005115714 ^ 1005115713];
            v15 = -627471681 ^ -627471732;
            var4_1[-909732173 ^ -909732174] = v15;
            v16 = -142673562 ^ -142673564;
            var4_1[v16] = -574609826 ^ -574609888;
            v17 = -1201943485 ^ -1201943485;
            v18 = -1424483529 ^ -1424483511;
            var4_1[v17] = v18;
            v19 = new String(var4_1, "UTF-8");
            while (true) {
                block67: {
                    if ((v20 = (cfr_temp_1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (38631363251001901L ^ -5740018159680857338L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                    if (v20 != (38599022 ^ 38599023)) break block67;
                    var1_2 = v13.replace(v14, v19);
                    960883795 ^ 292560957;
                    v21 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                    if (true) ** GOTO lbl89
                }
                v20 = 45854268 - -53636574;
            }
            block50: while (true) {
                v21 = v22 / (-9115259772984452703L ^ 7681889918502864132L);
lbl89:
                // 2 sources

                switch ((int)v21) {
                    case -2074196707: {
                        v22 = -9181203261677292191L - -6159318508121465695L;
                        continue block50;
                    }
                    case -2055714186: {
                        v22 = 5493911902270593816L >>> "\u0000\u0000".length();
                        continue block50;
                    }
                    case -1348636221: {
                        v22 = -5968157616030834937L - -9011287225075729934L;
                        continue block50;
                    }
                    case 141306124: {
                        break block50;
                    }
                }
                break;
            }
            v23 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
            if (true) ** GOTO lbl105
            block51: while (true) {
                v23 = (4313376957875619311L ^ -4119104913194218513L) / v24;
lbl105:
                // 2 sources

                switch ((int)v23) {
                    case 141306124: {
                        break block51;
                    }
                    case 2011761506: {
                        v24 = 6647145119769059224L - 5798459181281169622L;
                        continue block51;
                    }
                }
                break;
            }
            v25 = new StringBuilder();
            var4_1 = new byte[-694864134 ^ -694864150];
            v26 = -1077722303 ^ -1077722322;
            var4_1[2070000739 ^ 2070000740] = v26;
            var4_1[1277783961 ^ 1277783952] = -501126636 ^ -501126535;
            var4_1[1595898937 ^ 1595898938] = 846207478 ^ 846207364;
            var4_1[1038056177 ^ 1038056181] = -107620677 ^ -107620622;
            v27 = -552278894 ^ -552278816;
            var4_1[352235589 ^ 352235597] = v27;
            v28 = -394650783 ^ -394650774;
            v29 = -679290855 ^ -679290771;
            var4_1[v28] = v29;
            var4_1[-879183767 ^ -879183772] = -1670127805 ^ -1670127828;
            var4_1[-1255327910 ^ -1255327912] = -1692139108 ^ -1692139015;
            var4_1[-1361580628 ^ -1361580628] = 1712891658 ^ 1712891775;
            v30 = 1336496512 ^ 1336496627;
            var4_1[-859926415 ^ -859926416] = v30;
            var4_1[840771936 ^ 840771946] = -1597371762 ^ -1597371665;
            v31 = -1907791884 ^ -1907791910;
            var4_1[-565165131 ^ -565165126] = v31;
            var4_1[-1269001488 ^ -1269001483] = -364572181 ^ -364572283;
            var4_1[-599428830 ^ -599428828] = -1553788431 ^ -1553788521;
            var4_1[1513165159 ^ 1513165163] = -1693522100 ^ -1693522139;
            var4_1[1342402917 ^ 1342402923] = 1428614901 ^ 1428614811;
            v32 = new String(var4_1, "UTF-8");
            v33 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
            block52: while (true) {
                switch ((int)v33) {
                    case 141306124: {
                        break block52;
                    }
                    case 2111579498: {
                        v33 = (-809040849342652424L >>> "\u0000\u0000".length()) / (8481796262653505671L ^ -7599878785221495839L);
                        continue block52;
                    }
                }
                break;
            }
            v34 = v25.append(v32);
            v35 = -1227163357 ^ -1227163358;
            var4_1 = new byte[v35];
            v36 = -636590588 ^ -636590588;
            var4_1[v36] = -886245696 ^ -886245650;
            v37 = new String(var4_1, "UTF-8");
            var4_1 = new byte[1040669685 ^ 1040669686];
            var4_1[-133604050 ^ -133604052] = 597996200 ^ 597996246;
            var4_1[-1392896251 ^ -1392896251] = -296149612 ^ -296149526;
            v38 = 82880725 ^ 82880724;
            var4_1[v38] = -1285147191 ^ -1285147142;
            v39 = CRACKME_520b83e1_0719_4b1d_8f70_8254dec11735e3128394.replace(v37, new String(var4_1, "UTF-8"));
            v40 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
            if (true) ** GOTO lbl165
            block53: while (true) {
                v40 = v41 / (-5431523282960857022L ^ 4230137879376966494L);
lbl165:
                // 2 sources

                switch ((int)v40) {
                    case -728253265: {
                        v41 = 1680704846199288480L - -3269182866874147207L;
                        continue block53;
                    }
                    case 141306124: {
                        break block53;
                    }
                    case 436712798: {
                        v41 = 9217038157247525988L ^ -3520590045375510009L;
                        continue block53;
                    }
                }
                break;
            }
            v42 = v34.append(v39);
            var4_1 = new byte[1349762937 ^ 1349762934];
            v43 = 215997627 ^ 215997589;
            var4_1[1056390532 ^ 1056390532] = v43;
            v44 = 556727331 ^ 556727381;
            var4_1[915434510 ^ 915434498] = v44;
            v45 = 836301386 ^ 836301359;
            var4_1[1884155679 ^ 1884155668] = v45;
            var4_1[-281959914 ^ -281959917] = -1102471027 ^ -1102470961;
            var4_1[1339927272 ^ 1339927266] = 1714913334 ^ 1714913402;
            var4_1[985690629 ^ 985690627] = 1450289120 ^ 1450289025;
            var4_1[-1861839079 ^ -1861839088] = 1870181063 ^ 1870181026;
            v46 = 1832359954 ^ 1832359955;
            v47 = 1044892940 ^ 1044893035;
            var4_1[v46] = v47;
            var4_1[-1969157466 ^ -1969157471] = 1102859550 ^ 1102859642;
            var4_1[-380153407 ^ -380153406] = -708379045 ^ -708379075;
            v48 = -2126913417 ^ -2126913414;
            var4_1[v48] = 2031038478 ^ 2031038571;
            var4_1[1315470790 ^ 1315470786] = -258605879 ^ -258605891;
            var4_1[-1102256388 ^ -1102256396] = -1630012641 ^ -1630012552;
            var4_1[-2010372286 ^ -2010372276] = 1232660087 ^ 1232659995;
            v49 = -282213269 ^ -282213374;
            var4_1[1484015048 ^ 1484015050] = v49;
            v50 = new String(var4_1, "UTF-8");
            while (true) {
                if ((v51 = (cfr_temp_2 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-6134104949756425027L ^ -3427263121298942168L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v51 == (368886414 ^ -368886415)) break;
                v51 = 1125057400 >>> "\u0000\u0000".length();
            }
            v52 = v42.append(v50).toString();
            v53 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
            block55: while (true) {
                switch ((int)v53) {
                    case 141306124: {
                        break block55;
                    }
                    case 741685273: {
                        v53 = (5942205711841579911L ^ -6595731546176968995L) / (252402251222264720L ^ -6505477780551281674L);
                        continue block55;
                    }
                }
                break;
            }
            var2_3 = \u017b\u017c\u0107m.7\u015aCz.getString(v52);
            -1945807473 ^ 775842949;
            if (CRACKME_520b83e1_0719_4b1d_8f70_8254dec11735c5108fd6 != null) break block68;
            var4_1 = new byte[-639821945 ^ -639821946];
            var4_1[50995598 ^ 50995598] = -1988773195 ^ -1988773221;
            v54 = new String(var4_1, "UTF-8");
            var4_1 = new byte[1286872309 ^ 1286872310];
            var4_1[-749308830 ^ -749308832] = -1610539616 ^ -1610539554;
            var4_1[-1056778346 ^ -1056778346] = -1413424031 ^ -1413424097;
            var4_1[-1575545460 ^ -1575545459] = 1175117693 ^ 1175117646;
            if (!CRACKME_520b83e1_0719_4b1d_8f70_8254dec11735e3128394.replace(v54, new String(var4_1, "UTF-8")).equals(CRACKME_520b83e1_0719_4b1d_8f70_8254dec11735e9d28963)) break block68;
            v55 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
            block56: while (true) {
                switch ((int)v55) {
                    case 141306124: {
                        break block56;
                    }
                    case 1997871216: {
                        v55 = (2627819143857386795L ^ -69289849003495784L) / (5191389116050685088L - -8653187437530312655L);
                        continue block56;
                    }
                }
                break;
            }
            -1648411479 ^ 640270973;
            while (true) {
                if ((v56 = (cfr_temp_3 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (5908653774734456100L - 3756530804977827353L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v56 == (-602253877 ^ -602253878)) break;
                v56 = 1574019653 - -1152268314;
            }
            -448340320 ^ -1038640659;
            var4_1 = new byte[438351785 ^ 438351801];
            v57 = 722826471 ^ 722826468;
            v58 = 1841692592 ^ 1841692610;
            var4_1[v57] = v58;
            var4_1[-1465874431 ^ -1465874428] = 1556629344 ^ 1556629262;
            var4_1[1592727383 ^ 1592727385] = -525003351 ^ -525003321;
            v59 = -1445011760 ^ -1445011714;
            var4_1[658098537 ^ 658098534] = v59;
            var4_1[-1089195565 ^ -1089195558] = 1542777733 ^ 1542777832;
            var4_1[612083886 ^ 612083887] = 1553654542 ^ 1553654653;
            v60 = 418273667 ^ 418273766;
            var4_1[2003154669 ^ 2003154671] = v60;
            v61 = -1644684810 ^ -1644684925;
            var4_1[261040792 ^ 261040792] = v61;
            v62 = 1898777214 ^ 1898777105;
            var4_1[-1814002284 ^ -1814002279] = v62;
            var4_1[1349285099 ^ 1349285095] = -1649139264 ^ -1649139287;
            v63 = -1743730358 ^ -1743730395;
            var4_1[-1728749485 ^ -1728749484] = v63;
            var4_1[2055060909 ^ 2055060902] = -516256862 ^ -516256810;
            var4_1[-303800114 ^ -303800118] = 1842876734 ^ 1842876791;
            var4_1[284082733 ^ 284082727] = -417978710 ^ -417978677;
            var4_1[-568499594 ^ -568499600] = 531806002 ^ 531806036;
            var4_1[-257138759 ^ -257138767] = -1082573366 ^ -1082573384;
            v64 = new StringBuilder().append(new String(var4_1, "UTF-8"));
            while (true) {
                block69: {
                    v65 = 3211767962574536170L ^ -3488805039707516098L;
                    cfr_temp_4 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - v65;
                    v66 = cfr_temp_4 == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1);
                    if (v66 == false) continue;
                    if (v66 != (-728023199 ^ -728023200)) break block69;
                    v67 = v64.append((String)CRACKME_520b83e1_0719_4b1d_8f70_8254dec11735e9d28963);
                    v68 = 2077715773 ^ 2077715762;
                    var4_1 = new byte[v68];
                    v69 = -231457773 ^ -231457776;
                    v70 = 1257954963 ^ 1257955061;
                    var4_1[v69] = v70;
                    var4_1[1299675274 ^ 1299675264] = 1296468559 ^ 1296468483;
                    v71 = -157800289 ^ -157800198;
                    var4_1[-2064504778 ^ -2064504773] = v71;
                    var4_1[-216246660 ^ -216246662] = 1570987832 ^ 1570987865;
                    v72 = -2063472989 ^ -2063472939;
                    var4_1[994494728 ^ 994494724] = v72;
                    var4_1[-1387564227 ^ -1387564234] = -781223152 ^ -781223051;
                    v73 = 1509004181 ^ 1509004188;
                    var4_1[v73] = -1939170346 ^ -1939170381;
                    v74 = -1221600309 ^ -1221600321;
                    var4_1[-1509382812 ^ -1509382816] = v74;
                    v75 = -1959343121 ^ -1959343224;
                    var4_1[-1846846261 ^ -1846846269] = v75;
                    v76 = 1820820234 ^ 1820820235;
                    var4_1[v76] = -533467895 ^ -533467794;
                    var4_1[-2099767106 ^ -2099767108] = -484744223 ^ -484744312;
                    var4_1[62377809 ^ 62377812] = 526286152 ^ 526286090;
                    v77 = 992346848 ^ 992346848;
                    var4_1[v77] = -660600927 ^ -660600945;
                    var4_1[-1853312644 ^ -1853312645] = 953948851 ^ 953948887;
                    var4_1[1587742353 ^ 1587742367] = -65654700 ^ -65654728;
                    v78 = new String(var4_1, "UTF-8");
                    v79 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                    if (true) ** GOTO lbl343
                }
                v66 = -1539548634 ^ 2073866763;
            }
            block59: while (true) {
                v79 = v80 / (-5841733460509110018L ^ 2966330783676937554L);
lbl343:
                // 2 sources

                switch ((int)v79) {
                    case -1371522706: {
                        v80 = 8008088305970458220L ^ -247921966032773100L;
                        continue block59;
                    }
                    case -370514288: {
                        v80 = 5451213262512761871L - -5390239397891078233L;
                        continue block59;
                    }
                    case 97187038: {
                        v80 = -7411995424210435551L - -7549237930170453383L;
                        continue block59;
                    }
                    case 141306124: {
                        break block59;
                    }
                }
                break;
            }
            v81 = v67.append(v78);
            v82 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
            block60: while (true) {
                switch ((int)v82) {
                    case -195934271: {
                        v82 = (-30372844088349729L ^ 706419195371301603L) / (-4773295189729202163L ^ 4670075676979156120L);
                        continue block60;
                    }
                    case 141306124: {
                        break block60;
                    }
                }
                break;
            }
            v83 = v81.toString();
            while (true) {
                if ((v84 = (cfr_temp_5 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (2311234194868510542L ^ 5442464302476863831L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v84 == -2068790952 - -2068790951) {
                    CRACKME_520b83e1_0719_4b1d_8f70_8254dec11735c5108fd6 = \u017b\u017c\u0107m.7\u015aCz.getString(v83);
                    break;
                }
                v84 = -334791819 ^ 869508725;
            }
        }
        if (CRACKME_520b83e1_0719_4b1d_8f70_8254dec11735c5108fd6 != null) {
            v85 = CRACKME_520b83e1_0719_4b1d_8f70_8254dec11735c5108fd6;
        } else {
            var4_1 = new byte[1527345022 ^ 1527345023];
            var4_1[-1292622013 ^ -1292622013] = 37208863 ^ 37208879;
            v85 = new String(var4_1, "UTF-8");
        }
        77564401 ^ -1934720543;
        return v85;
    }

    /*
     * Unable to fully structure code
     */
    private static String 3c7pwrayAXd-4qg4(String var0) {
        block85: {
            block92: {
                block86: {
                    block90: {
                        block84: {
                            block89: {
                                block83: {
                                    if (8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == 3237527863231971692L >>> "\u0000\u0000".length()) {
                                        if ((276442962 ^ -1568057897 ^ (-819466828 ^ -1328016821)) != 0) {
                                            v0 = -2507682128810572298L == -2507682128810572297L ? 275438133 : 623953570 ^ 623953571;
                                        }
                                    } else {
                                        1462544070 ^ 1462544070;
                                    }
                                    v1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                                    block43: while (true) {
                                        switch ((int)v1) {
                                            case -1745302804: {
                                                v1 = (5696702317938251L ^ -7028222836712542430L) / (6963342387776536112L >>> "\u0000\u0000".length());
                                                continue block43;
                                            }
                                            case 141306124: {
                                                break block43;
                                            }
                                        }
                                        break;
                                    }
                                    v2 = zNb\u015b.Y\u017btq.getConfig();
                                    var4_1 = new byte[-1384053716 ^ -1384053721];
                                    var4_1[-1179541643 ^ -1179541641] = -1679724359 ^ -1679724334;
                                    var4_1[7083647048309138832L == 7083647048309138833L ? -1323974007 : 403556288 ^ 403556292] = 606238854 ^ 606238953;
                                    var4_1[-5140062633600569769L == -5140062633600569768L ? 855837162 : -839981327 ^ -839981319] = 2020845629 ^ 2020845660;
                                    var4_1[1091510471 ^ 1091510466] = 1320297558 ^ 1320297533;
                                    var4_1[-8213042109323096933L == -8213042109323096932L ? 490040252 : 835561973 ^ 835561983] = -1621525288 ^ -1621525315;
                                    var4_1[858989659 ^ 858989650] = -843181845 ^ -843181946;
                                    var4_1[-1454315012 ^ -1454315014] = -1427286935 ^ -1427286986;
                                    var4_1[-255419040 ^ -255419037] = 1373452071171179452L == 1373452071171179453L ? 1549557210 : 278110365 ^ 278110441;
                                    var4_1[1232812688 ^ 1232812695] = 1590880297 ^ 1590880327;
                                    var4_1[-1420342488 ^ -1420342487] = 1697778994 ^ 1697779035;
                                    var4_1[1183401715 ^ 1183401715] = 631603302 ^ 631603218;
                                    v3 = new String(var4_1, "UTF-8");
                                    while (true) {
                                        block87: {
                                            if ((v4 = (cfr_temp_0 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (8105096606711345490L ^ -2147469790424155967L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                                            if (v4 != (-1922316777 ^ -1922316778)) break block87;
                                            v5 = v2.getString(v3);
                                            var4_1 = new byte[-962122275 ^ -962122276];
                                            var4_1[-1372809501 ^ -1372809501] = -320178413 ^ -320178371;
                                            v6 = new String(var4_1, "UTF-8");
                                            var4_1 = new byte[-1084918292 ^ -1084918289];
                                            var4_1[-200964776 ^ -200964774] = 48477237 ^ 48477259;
                                            var4_1[587474192 ^ 587474193] = 643968307 ^ 643968256;
                                            var4_1[294707169 ^ 294707169] = 1037208031 ^ 1037207969;
                                            v7 = new String(var4_1, "UTF-8");
                                            v8 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                                            if (true) ** GOTO lbl52
                                        }
                                        v4 = 32074922 ^ 400342855;
                                    }
                                    block45: while (true) {
                                        v8 = v9 / (5422164042081755446L ^ -8744717410539972530L);
lbl52:
                                        // 2 sources

                                        switch ((int)v8) {
                                            case -1602129261: {
                                                if (-3001704023954172455L == -3001704023954172454L) {
                                                    v9 = -3461602632366584946L;
                                                    continue block45;
                                                }
                                                v9 = 3154519291473662259L - 3488004466693631287L;
                                                continue block45;
                                            }
                                            case -835065440: {
                                                v9 = 6475583921940954240L >>> "\u0000\u0000".length();
                                                continue block45;
                                            }
                                            case 141306124: {
                                                break block45;
                                            }
                                            case 635414059: {
                                                v9 = -1150777649884390768L ^ -6505561751569426706L;
                                                continue block45;
                                            }
                                        }
                                        break;
                                    }
                                    CRACKME_5e568973_bffa_4524_a663_6f1a10e9f0ec3dad29c3 = v5.replace(v6, v7);
                                    while (true) {
                                        block88: {
                                            if ((v10 = (cfr_temp_1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-1932103267120222191L ^ -942791290347463473L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                                            if (v10 != (-463135200 ^ -463135199)) break block88;
                                            v11 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                                            if (true) ** GOTO lbl79
                                        }
                                        v10 = 626179110 ^ -737341454;
                                    }
                                    block47: while (true) {
                                        v11 = v12 / (-4878975218288139680L == -4878975218288139679L ? -1031708836992532019L : 3988467890722437188L - -1139480287917091896L);
lbl79:
                                        // 2 sources

                                        switch ((int)v11) {
                                            case 141306124: {
                                                break block47;
                                            }
                                            case 333068145: {
                                                v12 = -2829924478292390872L ^ 809136395351922162L;
                                                continue block47;
                                            }
                                            case 1134164646: {
                                                v12 = -6354327317105432809L ^ -6925673255886584047L;
                                                continue block47;
                                            }
                                            case 1862610715: {
                                                if (-2553930226727594093L == -2553930226727594092L) {
                                                    v12 = -4077037915320554019L;
                                                    continue block47;
                                                }
                                                v12 = 8808158666199236104L ^ -6264283971569987962L;
                                                continue block47;
                                            }
                                        }
                                        break;
                                    }
                                    v13 = new StringBuilder();
                                    var4_1 = new byte[-6480765656204138826L == -6480765656204138825L ? -621052471 : 1851680464 ^ 1851680448];
                                    var4_1[1626347712 ^ 1626347727] = -1273607329 ^ -1273607311;
                                    var4_1[520404349 ^ 520404343] = -6309802585639159334L == -6309802585639159333L ? -362813074 : 784000382 ^ 784000287;
                                    var4_1[466547840 ^ 466547842] = 6136224613921817358L == 6136224613921817359L ? 1026035869 : 1149823288 ^ 1149823325;
                                    var4_1[51229933 ^ 51229933] = 1586694943 ^ 1586695018;
                                    var4_1[-1160019595 ^ -1160019587] = -6895641296984986852L == -6895641296984986851L ? 494658477 : -1105680460 ^ -1105680442;
                                    var4_1[-191445462 ^ -191445468] = 701177445 ^ 701177355;
                                    var4_1[542542601 ^ 542542602] = -8570053248553781348L == -8570053248553781347L ? -826245920 : 1563978435 ^ 1563978417;
                                    var4_1[440268655 ^ 440268646] = -1199858202 ^ -1199858293;
                                    var4_1[2058462841 ^ 2058462840] = 1636972936 ^ 1636973051;
                                    var4_1[1909393364 ^ 1909393362] = 1053567280 ^ 1053567318;
                                    var4_1[1947578999 ^ 1947578995] = -893110592 ^ -893110647;
                                    var4_1[4440143999104600039L == 4440143999104600040L ? -437040688 : 34318288 ^ 34318301] = 1934463847 ^ 1934463752;
                                    var4_1[2024250470 ^ 2024250474] = -1894588514 ^ -1894588425;
                                    var4_1[-1930362043 ^ -1930362046] = 4883929729654069252L == 4883929729654069253L ? -1481027618 : 1446514250 ^ 1446514213;
                                    var4_1[6599918198547065318L == 6599918198547065319L ? -1413170028 : 817119912 ^ 817119907] = -3827280751151486017L == -3827280751151486016L ? 68972063 : 1387023984 ^ 1387023876;
                                    var4_1[253247330 ^ 253247335] = 1431218937900584631L == 1431218937900584632L ? 1439927592 : -1222577246 ^ -1222577204;
                                    v14 = new String(var4_1, "UTF-8");
                                    -466710176 >>> "\u0000\u0000".length();
                                    while (true) {
                                        if ((v15 = (cfr_temp_2 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (4232072484560217915L == 4232072484560217916L ? 34112535952622118L : -8899668244863950733L ^ 232836161896145507L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                                        if (v15 == (-727449749 ^ -727449750)) {
                                            v16 = v13.append(v14);
                                            if (-2192852664110026406L == -2192852664110026405L) {
                                                break;
                                            }
                                            break block83;
                                        }
                                        v15 = 1635456370 - 969881985;
                                    }
                                    v17 = -1659419623;
                                    break block89;
                                }
                                v17 = 725176229 ^ 725176228;
                            }
                            var4_1 = new byte[v17];
                            var4_1[-8155820766981505319L == -8155820766981505318L ? -1908953361 : 1710129816 ^ 1710129816] = 90492442116068157L == 90492442116068158L ? 1524147366 : 1181764867 ^ 1181764909;
                            v18 = new String(var4_1, "UTF-8");
                            var4_1 = new byte[1549096485 ^ 1549096486];
                            var4_1[-3355553090067677820L == -3355553090067677819L ? -898586896 : -467516504 ^ -467516504] = 1180253606 ^ 1180253656;
                            var4_1[576208625 ^ 576208627] = 2856030323287605447L == 2856030323287605448L ? -1321503493 : 68314007 ^ 68314089;
                            var4_1[-510937559 ^ -510937560] = 355630342 ^ 355630389;
                            v19 = CRACKME_5e568973_bffa_4524_a663_6f1a10e9f0ec8a8e293d.replace(v18, new String(var4_1, "UTF-8"));
                            -581934003 ^ 1796953348;
                            v20 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                            if (true) ** GOTO lbl151
                            block49: while (true) {
                                v20 = v21 / (-5374730548898064497L - 3827088130027501518L);
lbl151:
                                // 2 sources

                                switch ((int)v20) {
                                    case -1628784513: {
                                        if (5454929193799016300L == 5454929193799016301L) {
                                            v21 = 1669516233204755045L;
                                            continue block49;
                                        }
                                        v21 = 3355653605200945970L ^ 2351700764146320495L;
                                        continue block49;
                                    }
                                    case 73758380: {
                                        v21 = -7604861642150939669L ^ 7576795671137414510L;
                                        continue block49;
                                    }
                                    case 141306124: {
                                        break block49;
                                    }
                                    case 1331053556: {
                                        v21 = -5390470066779069858L - -4617486728424636455L;
                                        continue block49;
                                    }
                                }
                                break;
                            }
                            v22 = v16.append(v19);
                            var4_1 = new byte[1863936386 ^ 1863936387];
                            var4_1[288177613 ^ 288177613] = -43781261 ^ -43781283;
                            v23 = new String(var4_1, "UTF-8");
                            v24 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                            if (true) ** GOTO lbl174
                            block50: while (true) {
                                v24 = v25 / (2696794033368346797L ^ -6143216198858537566L);
lbl174:
                                // 2 sources

                                switch ((int)v24) {
                                    case 141306124: {
                                        break block50;
                                    }
                                    case 641435038: {
                                        v25 = -7731968536236410834L ^ -536207603455508353L;
                                        continue block50;
                                    }
                                    case 1067658783: {
                                        v25 = -7362861618477764269L ^ 8338643192358750132L;
                                        continue block50;
                                    }
                                }
                                break;
                            }
                            v26 = v22.append(v23);
                            while (true) {
                                if ((v27 = (cfr_temp_3 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (1199061608761232245L - 6028884992893337496L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                                if (v27 == (-1321837234 ^ -1321837233)) {
                                    v28 = v26.append(CRACKME_5e568973_bffa_4524_a663_6f1a10e9f0ec3dad29c3);
                                    var4_1 = new byte[-1154827936 ^ -1154827922];
                                    var4_1[2007977041 ^ 2007977049] = -1036196863 ^ -1036196764;
                                    var4_1[-278829268 ^ -278829279] = 1206048730 ^ 1206048694;
                                    if (5416552103742901973L == 5416552103742901974L) {
                                        break;
                                    }
                                    break block84;
                                }
                                v27 = 2087464330 ^ 6231368;
                            }
                            v29 = -1823436311;
                            break block90;
                        }
                        v29 = 1997209164 ^ 1997209129;
                    }
                    var4_1[-1978600238 ^ -1978600226] = v29;
                    var4_1[-1245626398 ^ -1245626393] = 321234638093113969L == 321234638093113970L ? -824764815 : 1179824478 ^ 1179824447;
                    var4_1[1245602227 ^ 1245602234] = -1143082816 ^ -1143082868;
                    var4_1[-561003541466638649L == -561003541466638648L ? -89427545 : -1644651185 ^ -1644651186] = -7573421241506457017L == -7573421241506457016L ? 161908333 : 4985646 ^ 4985672;
                    var4_1[795188617 ^ 795188611] = 8461111105244177164L == 8461111105244177165L ? -661116246 : 1864384983 ^ 1864384946;
                    var4_1[232090420 ^ 232090431] = -905238077 ^ -905238091;
                    var4_1[624353541 ^ 624353539] = -1300167234 ^ -1300167206;
                    var4_1[377144943 ^ 377144941] = 682722007 ^ 682721974;
                    var4_1[-830228548 ^ -830228548] = 678585066 ^ 678585028;
                    var4_1[-715775108 ^ -715775112] = 1200593497 ^ 1200593435;
                    var4_1[1405013761 ^ 1405013762] = 654679177 ^ 654679271;
                    var4_1[6889729659144846847L == 6889729659144846848L ? -813123485 : -527078684 ^ -527078685] = 286429764 ^ 286429731;
                    v30 = new String(var4_1, "UTF-8");
                    while (true) {
                        block91: {
                            if ((v31 = (cfr_temp_4 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-2875654053734778668L - 7139625040510941728L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                            if (v31 != (-974481135 ^ 974481134)) break block91;
                            v32 = v28.append(v30);
                            v33 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                            if (true) ** GOTO lbl226
                        }
                        v31 = 308001294 - -707466209;
                    }
                    block53: while (true) {
                        v33 = v34 / (6275839203006640920L - 4201116974073794862L);
lbl226:
                        // 2 sources

                        switch ((int)v33) {
                            case -577439105: {
                                v34 = -8831843440457502829L ^ -8825908212888000427L;
                                continue block53;
                            }
                            case 141306124: {
                                break block53;
                            }
                            case 187744369: {
                                if (-9144282065548524698L == -9144282065548524697L) {
                                    v34 = -2831812939698744912L;
                                    continue block53;
                                }
                                v34 = 8176211653455156712L ^ 3505221899869400697L;
                                continue block53;
                            }
                        }
                        break;
                    }
                    v35 = v32.toString();
                    while (true) {
                        if ((v36 = (cfr_temp_5 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-5518682175433929104L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                        if (v36 == (2116215156 ^ 2116215157)) {
                            var2_3 = \u017b\u017c\u0107m.7\u015aCz.getString(v35);
                            384796232 ^ -637416499;
                            -957995608 >>> "\u0000\u0000".length();
                            if (CRACKME_5e568973_bffa_4524_a663_6f1a10e9f0ec02d8d270 == null) {
                                break;
                            }
                            break block85;
                        }
                        v36 = -1084174332 ^ -777999177;
                    }
                    var4_1 = new byte[-2128527658 ^ -2128527657];
                    var4_1[622565844 ^ 622565844] = 465270582 ^ 465270552;
                    v37 = new String(var4_1, "UTF-8");
                    var4_1 = new byte[369902475 ^ 369902472];
                    var4_1[-6466911302811956310L == -6466911302811956309L ? -1142823332 : 584080814 ^ 584080812] = -4817972560295217121L == -4817972560295217120L ? -1606439712 : -1944618691 ^ -1944618685;
                    var4_1[-1298313051 ^ -1298313051] = -20444808 ^ -20444922;
                    var4_1[-712554675 ^ -712554676] = 11573250 ^ 11573297;
                    v38 = CRACKME_5e568973_bffa_4524_a663_6f1a10e9f0ec8a8e293d.replace(v37, new String(var4_1, "UTF-8"));
                    while (true) {
                        if ((v39 = (cfr_temp_6 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (6600388836759262671L ^ 3788312828929245382L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                        if (v39 == (-1889630656980171101L == -1889630656980171100L ? 423002448 : -2029237830 - -2029237829)) {
                            if (v38.equals(CRACKME_5e568973_bffa_4524_a663_6f1a10e9f0ec3dad29c3)) {
                                break;
                            }
                            break block85;
                        }
                        v39 = 950796600 >>> "\u0000\u0000".length();
                    }
                    v40 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                    if (true) ** GOTO lbl275
                    block56: while (true) {
                        v40 = v41 / (-1806141840250435357L ^ 3789012163655940407L);
lbl275:
                        // 2 sources

                        switch ((int)v40) {
                            case -1387810841: {
                                if (4464864910955931940L == 4464864910955931941L) {
                                    v41 = 6528558018463005675L;
                                    continue block56;
                                }
                                v41 = -1787314899415676844L >>> "\u0000\u0000".length();
                                continue block56;
                            }
                            case -1305878851: {
                                v41 = -2190215952354449188L ^ 1846848545106262191L;
                                continue block56;
                            }
                            case 141306124: {
                                break block56;
                            }
                            case 495252231: {
                                if (-2896271057257354812L == -2896271057257354811L) {
                                    v41 = 3723564217170494816L;
                                    continue block56;
                                }
                                v41 = 8711141989728179624L ^ 1230044577528670337L;
                                continue block56;
                            }
                        }
                        break;
                    }
                    1818827331 - 1047511275;
                    var4_1 = new byte[2111575176 ^ 2111575192];
                    var4_1[-1003386984 ^ -1003386991] = 819767389 ^ 819767344;
                    var4_1[-5960609010957170145L == -5960609010957170144L ? -1204691422 : 617916241 ^ 617916250] = -1513451195 ^ -1513451215;
                    var4_1[2083956224039420830L == 2083956224039420831L ? -466954995 : 520442214 ^ 520442211] = 6859662147528848755L == 6859662147528848756L ? -13420894 : 1771241957 ^ 1771241867;
                    var4_1[-1766170138 ^ -1766170137] = 1843589696 ^ 1843589683;
                    var4_1[1125762016 ^ 1125762024] = -1260845765 ^ -1260845751;
                    var4_1[2656982950340312793L == 2656982950340312794L ? -1949657786 : -1593201717 ^ -1593201719] = 3099827126154848597L == 3099827126154848598L ? 26087157 : 971914702 ^ 971914667;
                    var4_1[1887365037 ^ 1887365038] = -652506061 ^ -652506047;
                    var4_1[2082532392 ^ 2082532392] = 858537981 ^ 858537864;
                    var4_1[619830569 ^ 619830564] = 1478162747 ^ 1478162772;
                    var4_1[-1831597518 ^ -1831597514] = 147622273684877890L == 147622273684877891L ? -1212378212 : -1552918516 ^ -1552918459;
                    var4_1[614234486 ^ 614234480] = -8145790459660156856L == -8145790459660156855L ? -1150724705 : -407991344 ^ -407991370;
                    var4_1[-694703763 ^ -694703769] = 1751829008 ^ 1751829105;
                    var4_1[-740928708 ^ -740928718] = -488030230 ^ -488030332;
                    var4_1[7028875322558138113L == 7028875322558138114L ? -994715945 : 596688055 ^ 596688056] = 1539184575 ^ 1539184529;
                    var4_1[2020559079 ^ 2020559072] = 1002752882 ^ 1002752797;
                    var4_1[-1989060270 ^ -1989060258] = -1453986497367837255L == -1453986497367837254L ? -196532946 : -1058234114 ^ -1058234217;
                    v42 = new StringBuilder().append(new String(var4_1, "UTF-8"));
                    var4_1 = new byte[1843850698 ^ 1843850699];
                    var4_1[-510324006 ^ -510324006] = 1042322392 ^ 1042322422;
                    v43 = new String(var4_1, "UTF-8");
                    var4_1 = new byte[1730966836 ^ 1730966839];
                    var4_1[557015916 ^ 557015916] = -837313818 ^ -837313896;
                    var4_1[-1104611072 ^ -1104611070] = 223513189 ^ 223513115;
                    var4_1[-1117640030 ^ -1117640029] = -6597153604418620485L == -6597153604418620484L ? 1587881587 : 1114769656 ^ 1114769611;
                    v44 = v42.append(CRACKME_5e568973_bffa_4524_a663_6f1a10e9f0ec8a8e293d.replace(v43, new String(var4_1, "UTF-8")));
                    var4_1 = new byte[-958804531 ^ -958804532];
                    var4_1[-1150039704 ^ -1150039704] = -718344015 ^ -718344033;
                    v45 = new String(var4_1, "UTF-8");
                    while (true) {
                        if ((v46 = (cfr_temp_7 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-3448167386820371111L - -1803829953142695931L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                        if (v46 == (-18636008 ^ -18636007)) {
                            v47 = v44.append(v45).append(CRACKME_5e568973_bffa_4524_a663_6f1a10e9f0ec3dad29c3);
                            var4_1 = new byte[1682917045 ^ 1682917051];
                            if (1677901388266122099L == 1677901388266122100L) {
                                break;
                            }
                            break block86;
                        }
                        v46 = -410421151 ^ -136592869;
                    }
                    v48 = -2021187697;
                    break block92;
                }
                v48 = 922858846 ^ 922858800;
            }
            var4_1[359874866 ^ 359874865] = v48;
            var4_1[-1695655929 ^ -1695655934] = 508524 ^ 508429;
            var4_1[779361876 ^ 779361885] = -1588728862 ^ -1588728914;
            var4_1[1771046744 ^ 1771046738] = -954499051 ^ -954498960;
            var4_1[-623940931 ^ -623940938] = 2095962693253883954L == 2095962693253883955L ? 1357295330 : -1643175239 ^ -1643175217;
            var4_1[-1587280599 ^ -1587280594] = 3884596378005978347L == 3884596378005978348L ? -894654538 : 882426495 ^ 882426392;
            var4_1[1046958056 ^ 1046958053] = -1324942799 ^ -1324942755;
            var4_1[1691922719 ^ 1691922719] = -449036790 ^ -449036764;
            var4_1[-685279016 ^ -685279014] = 128325590 ^ 128325559;
            var4_1[350628042 ^ 350628034] = 2237245040048333651L == 2237245040048333652L ? -1732385724 : 1684703048 ^ 1684703021;
            var4_1[-935641324 ^ -935641328] = -665546970 ^ -665546908;
            var4_1[-1373495499 ^ -1373495495] = 1635542558 ^ 1635542651;
            var4_1[286253710 ^ 286253704] = -764961303 ^ -764961395;
            var4_1[73562476 ^ 73562477] = 1322101141 ^ 1322101235;
            v49 = new String(var4_1, "UTF-8");
            while (true) {
                if ((v50 = (cfr_temp_8 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (807948076229657537L ^ -4268356415112573446L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                if (v50 == (-8438161920389927717L == -8438161920389927716L ? -68378204 : 117441047 ^ 117441046)) break;
                v50 = -1713961052 >>> "\u0000\u0000".length();
            }
            v51 = v47.append(v49);
            while (true) {
                block93: {
                    if ((v52 = (cfr_temp_9 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-1529114154831765227L ^ 2912263089632943881L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                    if (v52 != (-1757679058442502686L == -1757679058442502685L ? 2133644115 : -1911506829 ^ -1911506830)) break block93;
                    v53 = v51.toString();
                    259136775 ^ -1379568967;
                    v54 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                    if (true) ** GOTO lbl387
                }
                v52 = 1361800224 ^ -154967408;
            }
            block60: while (true) {
                v54 = v55 / (-4644860661287088616L ^ 4998182560072040574L);
lbl387:
                // 2 sources

                switch ((int)v54) {
                    case -1705517062: {
                        if (-7974701257075294289L == -7974701257075294288L) {
                            v55 = 4493254730714130040L;
                            continue block60;
                        }
                        v55 = -5042311952010591813L ^ 4505544215869448300L;
                        continue block60;
                    }
                    case 141306124: {
                        break block60;
                    }
                    case 1913272047: {
                        v55 = -6464225026037449413L - -7851857228536073755L;
                        continue block60;
                    }
                }
                break;
            }
            CRACKME_5e568973_bffa_4524_a663_6f1a10e9f0ec02d8d270 = \u017b\u017c\u0107m.7\u015aCz.getString(v53);
        }
        1124101186 - -1904408514;
        if (CRACKME_5e568973_bffa_4524_a663_6f1a10e9f0ec02d8d270 != null) {
            v56 = CRACKME_5e568973_bffa_4524_a663_6f1a10e9f0ec02d8d270;
        } else {
            var4_1 = new byte[-1879114670 ^ -1879114669];
            var4_1[-669834205 ^ -669834205] = 754381106 ^ 754381058;
            v56 = new String(var4_1, "UTF-8");
            -2106932703 ^ 935154058;
        }
        return v56;
    }

    /*
     * Unable to fully structure code
     */
    private static String mrVvLE3h-7jv8HUT(String var0) {
        block32: {
            block30: {
                v0 = 3615687797123459656L >>> "\u0000\u0000".length();
                if (8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == v0) {
                    v1 = 1328125924 - -1227498264;
                    v2 = -178167377 ^ -1969316272;
                    if ((v1 ^ v2) != 0) {
                        1023524336 ^ 1023524337;
                    }
                } else {
                    526784877 ^ 526784877;
                }
                v3 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl22
                block17: while (true) {
                    v3 = v4 / (-5078872015320505139L ^ 8159340620424139957L);
lbl22:
                    // 2 sources

                    switch ((int)v3) {
                        case -1944352470: {
                            v4 = 7606405797060133966L - 8960458763475642482L;
                            continue block17;
                        }
                        case 141306124: {
                            break block17;
                        }
                        case 1465548373: {
                            v4 = -989749752559378418L ^ 4918544941576301352L;
                            continue block17;
                        }
                    }
                    break;
                }
                while (true) {
                    if ((v5 = (cfr_temp_0 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (3699458653305641819L - 4389244161409963644L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                    if (v5 == (1318005453 ^ 1318005452)) break;
                    v5 = -470625632 ^ 206857716;
                }
                while (true) {
                    block31: {
                        v6 = -1902901900885127408L >>> "\u0000\u0000".length();
                        cfr_temp_1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - v6;
                        v7 = cfr_temp_1 == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1);
                        if (v7 == false) continue;
                        v8 = 204387928 ^ 204387929;
                        if (v7 != v8) break block31;
                        v9 = new StringBuilder();
                        var3_1 = new byte[-1090659479 ^ -1090659463];
                        v10 = -1521818439 ^ -1521818404;
                        var3_1[-2146359819 ^ -2146359817] = v10;
                        v11 = -1417117743 ^ -1417117731;
                        var3_1[v11] = 1843220437 ^ 1843220412;
                        var3_1[-1934849846 ^ -1934849849] = 227345795 ^ 227345900;
                        v12 = 90839949 ^ 90839942;
                        v13 = -1454908283 ^ -1454908175;
                        var3_1[v12] = v13;
                        var3_1[-1953320565 ^ -1953320573] = -1798884745 ^ -1798884859;
                        var3_1[-875745931 ^ -875745925] = 1151169904 ^ 1151169822;
                        var3_1[1839544780 ^ 1839544777] = 1875340713 ^ 1875340743;
                        var3_1[1870061416 ^ 1870061409] = -186923923 ^ -186924032;
                        var3_1[-421544666 ^ -421544667] = 958895436 ^ 958895422;
                        v14 = 273216153 ^ 273216208;
                        var3_1[-810400663 ^ -810400659] = v14;
                        v15 = -891282738 ^ -891282751;
                        var3_1[v15] = -1042403251 ^ -1042403229;
                        var3_1[1402744694 ^ 1402744695] = -2018598559 ^ -2018598638;
                        v16 = 1861241379 ^ 1861241413;
                        var3_1[176790005 ^ 176790003] = v16;
                        v17 = -1518328918 ^ -1518328915;
                        var3_1[v17] = -858836997 ^ -858837100;
                        v18 = 1509512390 ^ 1509512359;
                        var3_1[1375104014 ^ 1375104004] = v18;
                        var3_1[1276316836 ^ 1276316836] = 278429881 ^ 278429900;
                        v19 = new String(var3_1, "UTF-8");
                        v20 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                        if (true) ** GOTO lbl78
                    }
                    v7 = -900464424 ^ -1224442112;
                }
                block20: while (true) {
                    v20 = (8888200143845875052L >>> "\u0000\u0000".length()) / v21;
lbl78:
                    // 2 sources

                    switch ((int)v20) {
                        case 141306124: {
                            break block20;
                        }
                        case 1160149642: {
                            v21 = -5548467932307213841L ^ 699029946751345350L;
                            continue block20;
                        }
                    }
                    break;
                }
                v22 = v9.append(v19);
                v23 = -1962077783 ^ -1962077784;
                var3_1 = new byte[v23];
                v24 = -835170317 ^ -835170339;
                var3_1[-1168848293 ^ -1168848293] = v24;
                v25 = new String(var3_1, "UTF-8");
                v26 = 945907838 ^ 945907837;
                var3_1 = new byte[v26];
                var3_1[346646971 ^ 346646971] = -1592297602 ^ -1592297728;
                v27 = 827455082 ^ 827455080;
                var3_1[v27] = 405279731 ^ 405279629;
                var3_1[-39437700 ^ -39437699] = -1278679871 ^ -1278679822;
                v28 = new String(var3_1, "UTF-8");
                v29 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                block21: while (true) {
                    switch ((int)v29) {
                        case 141306124: {
                            break block21;
                        }
                        case 1149681928: {
                            v29 = (2293808693355055615L ^ -8744152073939060205L) / (-771238987981872980L ^ -6943245694667708093L);
                            continue block21;
                        }
                    }
                    break;
                }
                v30 = CRACKME_7ffb2ca4_6bd5_4ede_afc4_53cf69efeecc9033ea01.replace(v25, v28);
                v31 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl113
                block22: while (true) {
                    v31 = v32 / (8717892330628877376L ^ -1386385023640172136L);
lbl113:
                    // 2 sources

                    switch ((int)v31) {
                        case -1358362766: {
                            v32 = -3772487434322622967L - 1300464482536280050L;
                            continue block22;
                        }
                        case 141306124: {
                            break block22;
                        }
                    }
                    break;
                }
                v33 = v22.append(v30);
                v34 = 863210638 ^ 863210626;
                var3_1 = new byte[v34];
                var3_1[-1628485698 ^ -1628485703] = 54731850 ^ 0x3432433;
                v35 = 210843037 ^ 210843036;
                v36 = 393505853 ^ 393505881;
                var3_1[v35] = v36;
                v37 = -22255625 ^ -22255726;
                var3_1[-164176578 ^ -164176587] = v37;
                v38 = -1926721933 ^ -1926722022;
                var3_1[1012961927 ^ 1012961925] = v38;
                var3_1[1131942367 ^ 1131942357] = 1096557877 ^ 1096557912;
                var3_1[-1801042437 ^ -1801042435] = 1053933916 ^ 1053933885;
                v39 = -1215407874 ^ -1215407920;
                var3_1[150101424 ^ 150101424] = v39;
                v40 = 2139416789 ^ 2139416761;
                var3_1[-1451562322 ^ -1451562325] = v40;
                v41 = -1410376096 ^ -1410376088;
                var3_1[v41] = -1563841740 ^ -1563841702;
                var3_1[1995915925 ^ 1995915932] = -1184923124 ^ -1184923027;
                v42 = -1782000979 ^ -1782000978;
                var3_1[v42] = -447957284 ^ -447957329;
                v43 = -1969490785 ^ -1969490789;
                var3_1[v43] = 1721628715 ^ 1721628763;
                v44 = new String(var3_1, "UTF-8");
                while (true) {
                    if ((v45 = (cfr_temp_2 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-738285702154136437L ^ 1950475756702920000L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                    v46 = 251340551 ^ 251340550;
                    if (v45 == v46) break;
                    v45 = 1266210762 - 417217211;
                }
                v47 = v33.append(v44).toString();
                while (true) {
                    if ((v48 = (cfr_temp_3 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-2410562984693542438L ^ 2817486436104547935L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                    if (v48 == (1273561742 ^ 1273561743)) {
                        var1_2 = \u017b\u017c\u0107m.7\u015aCz.getString(v47);
                        v49 = 37203832 ^ -146975359;
                        if (CRACKME_7ffb2ca4_6bd5_4ede_afc4_53cf69efeeccee4a9b63 != null) {
                            break;
                        }
                        break block30;
                    }
                    v48 = 534849384 ^ -1398602959;
                }
                v50 = CRACKME_7ffb2ca4_6bd5_4ede_afc4_53cf69efeeccee4a9b63;
                break block32;
            }
            759897171 ^ -826044539;
            v50 = CRACKME_7ffb2ca4_6bd5_4ede_afc4_53cf69efeecc9033ea01;
        }
        v51 = -136403823 ^ 772534165;
        return v50;
    }

    /*
     * Unable to fully structure code
     */
    public static String lZSHCvvfZWn-7QKJ(int var0) {
        if (8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == (2772894950687691827L ^ -2027030342758900656L)) {
            if (((-2002099714893812153L == -2002099714893812152L ? 796086361 : -718342469 ^ 227117231) ^ (1066378426 ^ 1081105221)) != 0) {
                -1750146103 ^ -1750146104;
            }
        } else {
            -371082397 ^ -371082397;
        }
        -1374792299 ^ 283705108;
        1777569874 ^ -2141280311;
        v0 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl22
        block11: while (true) {
            v0 = v1 / (-4107459783849611402L ^ 8349664309641404422L);
lbl22:
            // 2 sources

            switch ((int)v0) {
                case -2077926033: {
                    v1 = 709920652444745669L - -9134897869033231608L;
                    continue block11;
                }
                case -1720303510: {
                    v1 = 1576708610199211711L - -6841039636049896001L;
                    continue block11;
                }
                case 141306124: {
                    break block11;
                }
            }
            break;
        }
        8\u0105ja.zsjN3N7fF6D1WUzb();
        while (true) {
            block21: {
                if ((v2 = (cfr_temp_0 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-1303613125524013413L == -1303613125524013412L ? -6715472034457799610L : -4127355948847130681L ^ 3755222925231143365L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v2 != (-228803561 ^ -228803562)) break block21;
                -1302545598 ^ -680322568;
                v3 = CRACKME_2b9f98cb_979f_4732_b042_d51034628946999c30a5;
                619276972 - -319722793;
                v4 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl56
            }
            v2 = -1477949857 ^ 1730947627;
        }
        block13: while (true) {
            v4 = v5 / (-547632693462931635L ^ -5719417935008753135L);
lbl56:
            // 2 sources

            switch ((int)v4) {
                case -1850722903: {
                    v5 = -9138899387539564758L ^ -8750073415592008104L;
                    continue block13;
                }
                case -1345364985: {
                    v5 = 7880109059213115668L - -439863179866730138L;
                    continue block13;
                }
                case 141306124: {
                    break block13;
                }
                case 1809801741: {
                    if (4118681788094992602L == 4118681788094992603L) {
                        v5 = 5043680436530557997L;
                        continue block13;
                    }
                    v5 = 7748575104215799763L ^ 3113760475629081213L;
                    continue block13;
                }
            }
            break;
        }
        CRACKME_2b9f98cb_979f_4732_b042_d51034628946a108f76a = 8\u0105ja.ENMJ.getOrDefault(v3, -1819059092 ^ -1819059092);
        while (true) {
            if ((v6 = (cfr_temp_1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-6516748140395252693L ^ -2496384543613150526L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v6 == -1118502165 - -1118502164) break;
            v6 = -1815190793 - 1448728530;
        }
        v7 = CRACKME_2b9f98cb_979f_4732_b042_d51034628946a108f76a;
        while (true) {
            if ((v8 = (cfr_temp_2 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-400850461363359548L == -400850461363359547L ? 1954024763996621097L : 1085195589969054391L ^ -5677885253241424435L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v8 == (-576701577 ^ -576701578)) {
                return 24XS.h_4UABwP3uGOOmhd((int)v7);
            }
            v8 = 821766578 - -961281057;
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     */
    private static /* synthetic */ Map jUN5k1jL9TVaq7_e(String string) {
        long l = 0x8E70C07315456509L ^ 0x181C064C3DA1D12FL;
        if (CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == l) {
            int cfr_ignored_1 = 0x3203B697 ^ 0x3203B696;
        } else {
            int n = 0x43F567D3 ^ 0x43F567D3;
        }
        long l2 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        boolean bl = true;
        block4: while (true) {
            long l3;
            if (!bl || (bl = false) || !true) {
                l2 = l3 / (-7651184317314090910L - 6941455296449617926L);
            }
            switch ((int)l2) {
                case 141306124: {
                    return new HashMap();
                }
                case 1872422396: {
                    l3 = -2835595041039022063L - -6504567723606827161L;
                    continue block4;
                }
            }
            break;
        }
        return new HashMap();
    }

    private static /* synthetic */ String BvJk0G9_NbgSZphb(\u00d3vR\u017a \u00f3vR\u017a) {
        if (CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == (0xD289D0F3694FFD9BL ^ 0x6E3676075C18FB53L)) {
            if (((2630974256610770876L == 2630974256610770877L ? 1457216921 : 1186543858 - 1029133019) ^ (-6271987137743045866L == -6271987137743045865L ? 1148501348 : 1806204275 - -341279372)) != 0) {
                int n = -8874471238925656940L == -8874471238925656939L ? -1988739187 : 0xFF3422BC ^ 0xFF3422BD;
            }
        } else {
            int n = 2492761110831101195L == 2492761110831101196L ? 383649486 : 0xD0E4E6EA ^ 0xD0E4E6EA;
        }
        int cfr_ignored_1 = 0x9D25714A ^ 0x202EB003;
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (0x5D1875A635D1B220L ^ 0xF83777CE84840C05L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0x29400581 ^ 0x29400580)) {
                \u00d3vR\u017a CRACKME_9fa9b218_5a66_42cb_83e6_d78c082030eb0b220813;
                return CRACKME_9fa9b218_5a66_42cb_83e6_d78c082030eb0b220813.\u0142W\u015aq;
            }
            l2 = 0xD3D3F099 ^ 0x8382C90F;
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * WARNING - void declaration
     */
    public static String W7kMqkVV2Syy2mGg(String string, int n) {
        String CRACKME_880a06a7_b214_40b0_9ed0_1b1d774edea4c02d842c;
        block37: {
            void CRACKME_880a06a7_b214_40b0_9ed0_1b1d774edea4a52d261a;
            String CRACKME_880a06a7_b214_40b0_9ed0_1b1d774edea4c45e6b15;
            if (CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == (0xC52851A08F93F902L ^ 0x6EE3BB28C5DB4D51L)) {
                int n2 = 0xE336A13A ^ 0x9CC95EC5;
                if ((0x4F7128C9 ^ 0x97A051AB ^ n2) != 0) {
                    int n3 = 0xBCBAE422 ^ 0xBCBAE423;
                }
            } else {
                int cfr_ignored_7 = 0xC5E5D70D ^ 0xC5E5D70D;
            }
            long l = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
            boolean bl = true;
            block21: while (true) {
                long l2;
                if (!bl || (bl = false) || !true) {
                    l = (-6521247550160805716L >>> "\u0000\u0000".length()) / l2;
                }
                switch ((int)l) {
                    case 141306124: {
                        break block21;
                    }
                    case 715639065: {
                        l2 = -921805879136890376L - 1539641439311749399L;
                        continue block21;
                    }
                }
                break;
            }
            8\u0105ja.zsjN3N7fF6D1WUzb();
            int cfr_ignored_8 = -774742845 - -198272619;
            long l3 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
            boolean bl2 = true;
            block22: while (true) {
                long l4;
                if (!bl2 || (bl2 = false) || !true) {
                    l3 = l4 / (0xB53E72900072FC89L ^ 0x6D80DB3F5877F32EL);
                }
                switch ((int)l3) {
                    case -869364704: {
                        l4 = 2971476436511137252L >>> "\u0000\u0000".length();
                        continue block22;
                    }
                    case 141306124: {
                        break block22;
                    }
                    case 517119515: {
                        l4 = 0x770EB4B891B627C8L ^ 0x5AB507C4354BE04AL;
                        continue block22;
                    }
                    case 1360733388: {
                        l4 = 0x3660AB4A8EE0A4D6L ^ 0xC040A16A5ED332A0L;
                        continue block22;
                    }
                }
                break;
            }
            int cfr_ignored_9 = 0xA9CB0250 ^ 0x7A88B0A2;
            String string2 = CRACKME_880a06a7_b214_40b0_9ed0_1b1d774edea4c45e6b15.toLowerCase();
            long l5 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
            boolean bl3 = true;
            block23: while (true) {
                long l6;
                if (!bl3 || (bl3 = false) || !true) {
                    l5 = l6 / (0x2CF229817B6573E3L ^ 0x88FDD2652D5ACEE7L);
                }
                switch ((int)l5) {
                    case -1843267912: {
                        l6 = 0x5C2499397EC6E4A5L ^ 0x9FA65526B27B2168L;
                        continue block23;
                    }
                    case 141306124: {
                        break block23;
                    }
                    case 1300934322: {
                        l6 = -5823916583907118925L - 1309200068368087108L;
                        continue block23;
                    }
                    case 1647242102: {
                        l6 = 0xBBCB34C593084806L ^ 0xD7CDBED0BE7CC6D6L;
                        continue block23;
                    }
                }
                break;
            }
            Map map = Collections.emptyMap();
            while (true) {
                long l7;
                long l8;
                if ((l8 = (l7 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (0x82F1A78DFC96229CL ^ 0xE679B354F3B8F838L)) == 0L ? 0 : (l7 < 0L ? -1 : 1)) == false) continue;
                int n4 = -147048128 - -147048127;
                if (l8 == n4) break;
                l8 = 1890881745 - 529613829;
            }
            int cfr_ignored_10 = 1386610316 >>> "\u0000\u0000".length();
            while (true) {
                long l9;
                long l10;
                if ((l10 = (l9 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (0xA7777C4D8D7E858L ^ 0x4DD8A0EDD8247D3AL)) == 0L ? 0 : (l9 < 0L ? -1 : 1)) == false) continue;
                if (l10 == (0xD8237709 ^ 0xD8237708)) break;
                l10 = 0xAD3638AC ^ 0x52A53BE9;
            }
            Integer n5 = (int)CRACKME_880a06a7_b214_40b0_9ed0_1b1d774edea4a52d261a;
            while (true) {
                long l11;
                long l12;
                if ((l12 = (l11 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (0xE6F92CD9955377B8L ^ 0x3A01209A5C4B70FL)) == 0L ? 0 : (l11 < 0L ? -1 : 1)) == false) continue;
                int n6 = 0x78E1B0D ^ 0x78E1B0C;
                if (l12 == n6) {
                    int cfr_ignored_11 = -1780716938 - 807664698;
                    CRACKME_880a06a7_b214_40b0_9ed0_1b1d774edea4c02d842c = \u017bxh\u0143.getOrDefault(string2, map).getOrDefault(n5, null);
                    if (CRACKME_880a06a7_b214_40b0_9ed0_1b1d774edea4c02d842c == null) {
                        break;
                    }
                    break block37;
                }
                l12 = 653537952 - 758360059;
            }
            byte[] byArray = new byte[0xCC052E6C ^ 0xCC052E6B];
            byArray[0x93244AB6 ^ 0x93244AB6] = 0x955734E1 ^ 0x6AA8CB23;
            byArray[0x82C255C3 ^ 0x82C255C5] = 0x23FB77C2 ^ 0x23FB7789;
            int n7 = 0x86DF6796 ^ 0x86DF6793;
            byArray[n7] = 0xE88CF035 ^ 0xE88CF074;
            int n8 = 0x1B05F103 ^ 0x1B05F101;
            byArray[n8] = 0xDA968776 ^ 0xDA968715;
            byArray[0xFF79BF6E ^ 0xFF79BF6F] = 0xFA7147B0 ^ 0x58EB817;
            byArray[0x1C843367 ^ 0x1C843363] = 0xBAC6B8EF ^ 0xBAC6B8BD;
            byArray[0x9AED8E76 ^ 0x9AED8E75] = 0xA7ECE0 ^ 0xA7ECA2;
            return new String(byArray, "UTF-8");
        }
        long l = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        boolean bl = true;
        block27: while (true) {
            long l13;
            if (!bl || (bl = false) || !true) {
                l = l13 / (0xAB7B8F8D72DC5CEBL ^ 0x5CDD96B6B57D38BBL);
            }
            switch ((int)l) {
                case -1214845031: {
                    l13 = -1263098804750382647L - -3408642415613791596L;
                    continue block27;
                }
                case -518312395: {
                    l13 = -6458892409428402278L - -4132427985110705480L;
                    continue block27;
                }
                case 141306124: {
                    return 8\u0105ja.mrVvLE3h-7jv8HUT(CRACKME_880a06a7_b214_40b0_9ed0_1b1d774edea4c02d842c);
                }
            }
            break;
        }
        return 8\u0105ja.mrVvLE3h-7jv8HUT(CRACKME_880a06a7_b214_40b0_9ed0_1b1d774edea4c02d842c);
    }

    /*
     * Unable to fully structure code
     */
    public static String YwU1zbOTf80bP18X(int var0) {
        if (8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == -3127771473981400817L - -3060622440550623368L) {
            if ((-1326947789 - 464976296 ^ (-256424422 ^ -1891059227)) != 0) {
                v0 = 8146878817207366524L == 8146878817207366525L ? -2019787984 : 1508430326 ^ 1508430327;
            }
        } else {
            -2039181218 ^ -2039181218;
        }
        8\u0105ja.zsjN3N7fF6D1WUzb();
        while (true) {
            block19: {
                if ((v1 = (cfr_temp_0 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (1666961771224305972L - 8665745737686035923L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v1 != (-1166710354 ^ -1166710353)) break block19;
                v2 = CRACKME_9436829f_6884_4983_a092_c21b26534137dd0339c7;
                v3 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl23
            }
            v1 = -565907409 ^ 153310569;
        }
        block11: while (true) {
            v3 = v4 / (6177049561267203004L ^ -8780732598722948833L);
lbl23:
            // 2 sources

            switch ((int)v3) {
                case -2048743836: {
                    v4 = -3787728310095504605L - 903499651419798480L;
                    continue block11;
                }
                case 141306124: {
                    break block11;
                }
                case 1505658057: {
                    v4 = -5072307443755954486L - -4891492235675523277L;
                    continue block11;
                }
            }
            break;
        }
        v5 = 0.0;
        v6 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl37
        block12: while (true) {
            v6 = v7 / (8556982288302548374L == 8556982288302548375L ? -5661487136962415265L : -6277667805036943885L - -6603744633066439317L);
lbl37:
            // 2 sources

            switch ((int)v6) {
                case -205620314: {
                    v7 = 1741403324498053032L ^ -8331137457518990538L;
                    continue block12;
                }
                case 141306124: {
                    break block12;
                }
                case 909154284: {
                    v7 = -3243650399112619765L ^ 6195393386354889819L;
                    continue block12;
                }
            }
            break;
        }
        var1_1 = 8\u0105ja.\u01189\u0107\u0105.getOrDefault(v2, v5);
        while (true) {
            if ((v8 = (cfr_temp_1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-3065018554286416476L ^ 1155802622069443282L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v8 == (-1466125244 ^ -1466125243)) break;
            v8 = 636046606 - -585134736;
        }
        v9 = CRACKME_9436829f_6884_4983_a092_c21b265341375d83dafa.doubleValue();
        while (true) {
            if ((v10 = (cfr_temp_2 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-6785428359665842279L ^ -86339585873475347L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v10 == (-1240920095758794616L == -1240920095758794615L ? -1171487176 : -972842353 - -972842352)) {
                return 24XS.mQJP1GRBa3RQGgTq((double)v9);
            }
            v10 = 1622174804 ^ -145390466;
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * WARNING - void declaration
     */
    private static void 5jpmx7hGc9mqJoxM(Map<String, Double> map, Map<Integer, String> map2, Map<Integer, Double> map3) {
        Map<String, Double> CRACKME_760c616c_fe0b_4bd0_a99e_caf47bbbb313346cad19;
        if (CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == -24142885342060170L - -4098013641971600478L) {
            int cfr_ignored_10 = 0x467D34B0 ^ 0x467D34B1;
        } else {
            int n = 0xEF11898C ^ 0xEF11898C;
        }
        long l = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        boolean bl = true;
        block8: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x60036A04E99042D3L ^ 0xB54B798DD629CD35L);
            }
            switch ((int)l) {
                case -1402268182: {
                    l2 = 0xD575E4E037213CECL ^ 0x6AD7F1E271F612D1L;
                    continue block8;
                }
                case 141306124: {
                    break block8;
                }
            }
            break;
        }
        ArrayList<Map.Entry<String, Double>> CRACKME_760c616c_fe0b_4bd0_a99e_caf47bbbb31395fa70a8 = new ArrayList<Map.Entry<String, Double>>(CRACKME_760c616c_fe0b_4bd0_a99e_caf47bbbb313346cad19.entrySet());
        int cfr_ignored_11 = 0x3E028424 ^ 0xA78ECEA2;
        while (true) {
            long l3 = 0xE6E90ACE36CAE556L ^ 0x6BDCC60496439530L;
            long l4 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - l3;
            long l5 = l4 == 0L ? 0 : (l4 < 0L ? -1 : 1);
            if (l5 == false) continue;
            if (l5 == (0x3C549ECF ^ 0x3C549ECE)) break;
            l5 = -2116628352 >>> "\u0000\u0000".length();
        }
        Comparator comparator = Collections.reverseOrder(Map.Entry.comparingByValue());
        while (true) {
            long l6;
            long l7;
            if ((l7 = (l6 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (676060099768251692L >>> "\u0000\u0000".length())) == 0L ? 0 : (l6 < 0L ? -1 : 1)) == false) continue;
            if (l7 == (0x2F4782D4 ^ 0x2F4782D5)) break;
            l7 = 0xA6CB0282 ^ 0xE0730AD8;
        }
        CRACKME_760c616c_fe0b_4bd0_a99e_caf47bbbb31395fa70a8.sort(comparator);
        int n = 0xF5F725CF ^ 0xF5F725CF;
        int n2 = n;
        void CRACKME_760c616c_fe0b_4bd0_a99e_caf47bbbb3132b4874da;
        block11: while (CRACKME_760c616c_fe0b_4bd0_a99e_caf47bbbb3132b4874da < CRACKME_760c616c_fe0b_4bd0_a99e_caf47bbbb31395fa70a8.size()) {
            void CRACKME_760c616c_fe0b_4bd0_a99e_caf47bbbb313a9545b17;
            int n3 = 0x4359883A ^ 0x4359883B;
            Integer n4 = (int)(CRACKME_760c616c_fe0b_4bd0_a99e_caf47bbbb3132b4874da + n3);
            long l8 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
            boolean bl2 = true;
            block12: while (true) {
                long l9;
                if (!bl2 || (bl2 = false) || !true) {
                    l8 = l9 / (-5823907600934892336L >>> "\u0000\u0000".length());
                }
                switch ((int)l8) {
                    case 141306124: {
                        break block12;
                    }
                    case 498823698: {
                        l9 = 0x18B7BEF824B20310L ^ 0x6C9DB9B2ABD5A6D3L;
                        continue block12;
                    }
                }
                break;
            }
            Map.Entry entry = (Map.Entry)CRACKME_760c616c_fe0b_4bd0_a99e_caf47bbbb31395fa70a8.get((int)CRACKME_760c616c_fe0b_4bd0_a99e_caf47bbbb3132b4874da);
            while (true) {
                long l10 = 0x5A9F32E738C505C1L ^ 0xC8DA9A7CFDC9457AL;
                long l11 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - l10;
                long l12 = l11 == 0L ? 0 : (l11 < 0L ? -1 : 1);
                if (l12 == false) continue;
                int n5 = 0x94E8F60B ^ 0x94E8F60A;
                if (l12 == n5) break;
                l12 = -23194180 >>> "\u0000\u0000".length();
            }
            String string = (String)entry.getKey();
            int n6 = 0x561D25D6 ^ 0x234EF07A;
            int n7 = 0xE1E672D6 ^ 0x67CC88EA;
            byte[] byArray = new byte[0xA223F810 ^ 0xA223F813];
            int n8 = 0x4F7259CF ^ 0x4F7259CE;
            byArray[n8] = 0x164987AC ^ 0x1649879F;
            int n9 = 0x5C255F0 ^ 0x5C255F0;
            byArray[n9] = 0x10F1D67E ^ 0x10F1D600;
            byArray[0x4BF7674E ^ 0x4BF7674C] = 0x1A23C5FB ^ 0x1A23C585;
            String string2 = new String(byArray, "UTF-8");
            byArray = new byte[0x6F9E6762 ^ 0x6F9E6763];
            byArray[0x494A830 ^ 0x494A830] = 0x1A824FC8 ^ 0x1A824FE6;
            String string3 = new String(byArray, "UTF-8");
            while (true) {
                long l13 = 0xF9F41B23F9C4DD6AL ^ 0x53D384289FCB3AD0L;
                long l14 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - l13;
                long l15 = l14 == 0L ? 0 : (l14 < 0L ? -1 : 1);
                if (l15 == false) continue;
                if (l15 == (0x803BF59B ^ 0x803BF59A)) break;
                l15 = 0xD89C6BAF ^ 0x9468EDC1;
            }
            String string4 = string.replace(string2, string3);
            int cfr_ignored_12 = 1696392148 - 1371111642;
            while (true) {
                long l16;
                long l17;
                if ((l17 = (l16 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (2708884411714858469L - -4386866673977012357L)) == 0L ? 0 : (l16 < 0L ? -1 : 1)) == false) continue;
                int n10 = 0xEB7F6FE1 ^ 0x1480901E;
                if (l17 == n10) break;
                l17 = 0x7824DBA3 ^ 0x66144557;
            }
            CRACKME_760c616c_fe0b_4bd0_a99e_caf47bbbb313a9545b17.put(n4, string4);
            int cfr_ignored_13 = 0x4FCF5B16 ^ 0xC54AF944;
            void v28 = CRACKME_760c616c_fe0b_4bd0_a99e_caf47bbbb3132b4874da + (0xCEC309C ^ 0xCEC309D);
            while (true) {
                long l18;
                long l19;
                if ((l19 = (l18 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (0xBD0FC6A451D2B3BBL ^ 0x57BC501D8175488L)) == 0L ? 0 : (l18 < 0L ? -1 : 1)) == false) continue;
                if (l19 == (0xACE39BC0 ^ 0xACE39BC1)) break;
                l19 = 2009712428 >>> "\u0000\u0000".length();
            }
            Integer n11 = (int)v28;
            Map.Entry entry2 = (Map.Entry)CRACKME_760c616c_fe0b_4bd0_a99e_caf47bbbb31395fa70a8.get((int)CRACKME_760c616c_fe0b_4bd0_a99e_caf47bbbb3132b4874da);
            while (true) {
                long l20 = 0x98954A09692247C9L ^ 0x6082C8A8E998A15EL;
                long l21 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - l20;
                long l22 = l21 == 0L ? 0 : (l21 < 0L ? -1 : 1);
                if (l22 == false) continue;
                if (l22 == (0xF2BAA85F ^ 0xF2BAA85E)) break;
                l22 = 0x6CD2EE5A ^ 0x6DFFC34;
            }
            Double d = (Double)entry2.getValue();
            int cfr_ignored_14 = -1106670487 - -1949956424;
            while (true) {
                long l23;
                long l24;
                if ((l24 = (l23 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (0x5EF450DB5D1F9211L ^ 0x6E9F06BD765EB0F5L)) == 0L ? 0 : (l23 < 0L ? -1 : 1)) == false) continue;
                if (l24 == (0x61620226 ^ 0x61620227)) {
                    void CRACKME_760c616c_fe0b_4bd0_a99e_caf47bbbb3133114bcb7;
                    CRACKME_760c616c_fe0b_4bd0_a99e_caf47bbbb3133114bcb7.put(n11, d);
                    int cfr_ignored_15 = -627367173 - 1669330575;
                    ++CRACKME_760c616c_fe0b_4bd0_a99e_caf47bbbb3132b4874da;
                    continue block11;
                }
                l24 = -1187768432 - 854129461;
            }
            break;
        }
        return;
    }

    /*
     * Unable to fully structure code
     */
    public static String dwgYX0tRM7_r1EXt(String var0) {
        v0 = 6177864764095007611L ^ -141098751334858459L;
        if (8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == v0) {
            1011546441 ^ 1011546440;
        } else {
            v1 = 1169800346 ^ 1169800346;
        }
        while (true) {
            if ((v2 = (cfr_temp_0 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (8584342349379433277L - 5030959638427666642L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v2 == (-1647757688 ^ -1647757687)) break;
            v2 = 1108145159 - -587738953;
        }
        while (true) {
            block97: {
                v3 = -5817806184531814703L ^ 5300416352487352558L;
                cfr_temp_1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - v3;
                v4 = cfr_temp_1 == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1);
                if (v4 == false) continue;
                if (v4 != (472485257 ^ 472485256)) break block97;
                var10_1 = new byte[-945132502 ^ -945132511];
                var10_1[436230962 ^ 436230967] = 688208677 ^ 688208718;
                v5 = -1647822431 ^ -1647822426;
                var10_1[v5] = -57527239 ^ -57527209;
                var10_1[1596783957 ^ 1596783958] = -890151626 ^ -890151614;
                v6 = 102543561 ^ 102543555;
                var10_1[v6] = -1183038061 ^ -1183037962;
                var10_1[1392415088 ^ 1392415092] = -767574668 ^ -767574757;
                var10_1[-1212908084 ^ -1212908086] = -577035414 ^ -577035467;
                v7 = -214709800 ^ -214709839;
                var10_1[1214880539 ^ 1214880538] = v7;
                var10_1[1518147063 ^ 1518147061] = 244613328 ^ 244613307;
                v8 = 771464429 ^ 771464421;
                var10_1[v8] = -2066228826 ^ -2066228793;
                var10_1[794688948 ^ 794688957] = -476890980 ^ -476890895;
                var10_1[233750709 ^ 233750709] = -1423910986 ^ -1423910974;
                v9 = zNb\u015b.Y\u017btq.getConfig().getString(new String(var10_1, "UTF-8"));
                var10_1 = new byte[1319916976 ^ 1319916977];
                var10_1[-610701507 ^ -610701507] = 1557277433 ^ 1557277399;
                v10 = new String(var10_1, "UTF-8");
                var10_1 = new byte[-825476559 ^ -825476560];
                var10_1[1982539994 ^ 1982539994] = 2051086532 ^ 2051086569;
                v11 = new String(var10_1, "UTF-8");
                v12 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl53
            }
            v4 = 1610500378 ^ 1827685628;
        }
        block70: while (true) {
            v12 = v13 / (-3562149044090078193L ^ -4803955622480698456L);
lbl53:
            // 2 sources

            switch ((int)v12) {
                case -2108160740: {
                    v13 = 6682747843516872088L - 8924858060542608093L;
                    continue block70;
                }
                case -496545961: {
                    v13 = -5422366924630052791L ^ -6473571462685507723L;
                    continue block70;
                }
                case -206158651: {
                    v13 = 7730583962757581463L ^ 4082520580430936094L;
                    continue block70;
                }
                case 141306124: {
                    break block70;
                }
            }
            break;
        }
        CRACKME_a8c1aebf_452f_4718_9cde_0f7cdd74481a33de4550 = v9.replace(v10, v11);
        v14 = -1954795841 ^ 1740814343;
        while (true) {
            block98: {
                v15 = -6186032773736769484L >>> "\u0000\u0000".length();
                cfr_temp_2 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - v15;
                v16 = cfr_temp_2 == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1);
                if (v16 == false) continue;
                v17 = -1525618662 ^ -1525618661;
                if (v16 != v17) break block98;
                v18 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl88
            }
            v16 = 1869495429 ^ -1028850926;
        }
        block72: while (true) {
            v18 = v19 / (1332858190772444094L - -5368072338486616848L);
lbl88:
            // 2 sources

            switch ((int)v18) {
                case -1854391866: {
                    v19 = 6066119027424846449L - 6794928604071567242L;
                    continue block72;
                }
                case -1802631681: {
                    v19 = 8065672359992847478L ^ -9149421372294354581L;
                    continue block72;
                }
                case 141306124: {
                    break block72;
                }
                case 1448157126: {
                    v19 = -8615379082866374589L - 6391945353006292924L;
                    continue block72;
                }
            }
            break;
        }
        v20 = new StringBuilder();
        v21 = -994977663 ^ -994977653;
        var10_1 = new byte[v21];
        v22 = -1701231693 ^ -1701231658;
        var10_1[1040706393 ^ 1040706385] = v22;
        var10_1[-574683619 ^ -574683618] = 201568382 ^ 201568266;
        v23 = -1006368951 ^ -1006368952;
        var10_1[v23] = 899685542 ^ 899685583;
        v24 = -1883457774 ^ -1883457765;
        var10_1[v24] = 1740063877 ^ 1740063915;
        var10_1[-1481831615 ^ -1481831613] = -254118034 ^ -254118136;
        var10_1[479796226 ^ 479796226] = -1941186279 ^ -1941186178;
        var10_1[1595162412 ^ 1595162409] = -1952550526 ^ -1952550410;
        v25 = 396639205 ^ 396639203;
        var10_1[v25] = 1973545245 ^ 1973545316;
        var10_1[200570849 ^ 200570853] = 109971517 ^ 109971472;
        var10_1[849937709 ^ 849937706] = 58267785 ^ 58267897;
        v26 = new String(var10_1, "UTF-8");
        v27 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl125
        block73: while (true) {
            v28 = -267249021811207981L ^ 5093922146398091098L;
            v27 = v29 / v28;
lbl125:
            // 2 sources

            switch ((int)v27) {
                case 141306124: {
                    break block73;
                }
                case 1396503350: {
                    v29 = -1081190855019449934L ^ 2390259030948985720L;
                    continue block73;
                }
            }
            break;
        }
        v30 = v20.append(v26).append(CRACKME_a8c1aebf_452f_4718_9cde_0f7cdd74481a33de4550);
        var10_1 = new byte[-838103187 ^ -838103188];
        v31 = 278148844 ^ 278148802;
        var10_1[301903693 ^ 301903693] = v31;
        v32 = new String(var10_1, "UTF-8");
        while (true) {
            block99: {
                if ((v33 = (cfr_temp_3 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-4117184826264828878L ^ 2673476871634853554L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v33 != (-611388676 ^ -611388675)) break block99;
                v34 = v30.append(v32);
                var10_1 = new byte[-960449931 ^ -960449932];
                var10_1[-1748847914 ^ -1748847914] = 1968636243 ^ 1968636285;
                v35 = new String(var10_1, "UTF-8");
                v36 = -1737494595 ^ -1737494594;
                var10_1 = new byte[v36];
                var10_1[-32469504 ^ -32469504] = -1554228203 ^ -1554228117;
                var10_1[1024388359 ^ 1024388357] = -1032048958 ^ -1032048964;
                var10_1[-1155914192 ^ -1155914191] = 1103763439 ^ 1103763420;
                v37 = new String(var10_1, "UTF-8");
                v38 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl158
            }
            v33 = 2077094522 ^ -249262758;
        }
        block75: while (true) {
            v39 = 5564219716626483269L ^ -3760664392812224433L;
            v38 = v40 / v39;
lbl158:
            // 2 sources

            switch ((int)v38) {
                case -271644963: {
                    v40 = -6346010939020413311L ^ -283107502913443338L;
                    continue block75;
                }
                case 141306124: {
                    break block75;
                }
                case 472280551: {
                    v40 = -5503777641830186218L ^ -6165804635808836509L;
                    continue block75;
                }
                case 1454273699: {
                    v40 = 405883490067445369L ^ 8943683623424020936L;
                    continue block75;
                }
            }
            break;
        }
        var2_3 = v34.append(CRACKME_a8c1aebf_452f_4718_9cde_0f7cdd74481a85717640.replace(v35, v37)).toString();
        -977866439 - -1272850007;
        v41 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl186
        block76: while (true) {
            v41 = v42 / (608695189168868262L - 5897704130726016555L);
lbl186:
            // 2 sources

            switch ((int)v41) {
                case 141306124: {
                    break block76;
                }
                case 540641198: {
                    v42 = 5648532742007355857L ^ -3320928186135047515L;
                    continue block76;
                }
                case 1670196949: {
                    v42 = 1279007229734956003L ^ 5841475047261814080L;
                    continue block76;
                }
            }
            break;
        }
        CRACKME_a8c1aebf_452f_4718_9cde_0f7cdd74481a63f6aba2 = \u017b\u017c\u0107m.7\u015aCz.getConfigurationSection((String)CRACKME_a8c1aebf_452f_4718_9cde_0f7cdd74481a39bc1862);
        if (CRACKME_a8c1aebf_452f_4718_9cde_0f7cdd74481a63f6aba2 == null) {
            v43 = -1587185884 - -714882661;
            v44 = 2129013443 ^ 2129013444;
            var10_1 = new byte[v44];
            v45 = 259069385 ^ 259069323;
            var10_1[1468261517 ^ 1468261518] = v45;
            var10_1[-1718564894 ^ -1718564893] = 504974333 ^ -504974246;
            var10_1[235340233 ^ 235340233] = 1582677016 ^ -1582677030;
            v46 = 2037044675 ^ 2037044677;
            var10_1[v46] = 1239479944 ^ 1239480003;
            var10_1[-42253559 ^ -42253556] = 330733621 ^ 330733684;
            var10_1[-281869141 ^ -281869143] = 1264264761 ^ 1264264794;
            v47 = 1192142224 ^ 1192142228;
            v48 = 1780383339 ^ 1780383289;
            var10_1[v47] = v48;
            return new String(var10_1, "UTF-8");
        }
        -1916976618 ^ -965901005;
        1331230226 ^ 1176487328;
        v49 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        block77: while (true) {
            switch ((int)v49) {
                case 141306124: {
                    break block77;
                }
                case 320364570: {
                    v49 = (-3850629027820025997L ^ -9055938561301653678L) / (-3037072482009387170L - -8535000997530979121L);
                    continue block77;
                }
            }
            break;
        }
        v50 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl236
        block78: while (true) {
            v50 = v51 / (5515128689771369380L ^ 3704980440063752528L);
lbl236:
            // 2 sources

            switch ((int)v50) {
                case -1763149136: {
                    v51 = -1278539902616744685L - -2644713622880970145L;
                    continue block78;
                }
                case -1180322706: {
                    v51 = -2382516787917762553L ^ 7497171739221338564L;
                    continue block78;
                }
                case 141306124: {
                    break block78;
                }
                case 677960034: {
                    v51 = 5017831322206298561L ^ 3942648678626481045L;
                    continue block78;
                }
            }
            break;
        }
        var4_5 = new HashMap<K, V>();
        1266690649 - -1150501890;
        -561387944 ^ 546946887;
        v52 = CRACKME_a8c1aebf_452f_4718_9cde_0f7cdd74481a63f6aba2.getKeys((boolean)(2100922530 ^ 2100922530));
        v53 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl266
        block79: while (true) {
            v53 = v54 / (2450560703666037288L >>> "\u0000\u0000".length());
lbl266:
            // 2 sources

            switch ((int)v53) {
                case -944515138: {
                    v54 = 808608033485090126L - -9012853630211288805L;
                    continue block79;
                }
                case -298629704: {
                    v54 = 2060058708751508608L ^ -235257725475902589L;
                    continue block79;
                }
                case 94155500: {
                    v54 = 1231022414223028397L - -5934839320722965042L;
                    continue block79;
                }
                case 141306124: {
                    break block79;
                }
            }
            break;
        }
        var5_6 = v52.iterator();
        block80: while (true) {
            if ((v55 = (cfr_temp_4 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-514242401332013075L ^ 7626793893156666825L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            v56 = -1086072701 ^ -1086072702;
            if (v55 == v56) {
                if (!var5_6.hasNext()) break;
            } else {
                v55 = 2061152360 ^ 62442134;
                continue;
            }
            v57 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
            if (true) ** GOTO lbl291
            block81: while (true) {
                v57 = v58 / (-1444872253225616772L >>> "\u0000\u0000".length());
lbl291:
                // 2 sources

                switch ((int)v57) {
                    case -198190086: {
                        v58 = 3076439828203401937L - -2796541206924339447L;
                        continue block81;
                    }
                    case 141306124: {
                        break block81;
                    }
                    case 1722823864: {
                        v58 = 4743988924538918777L - 4739975205015516177L;
                        continue block81;
                    }
                }
                break;
            }
            CRACKME_a8c1aebf_452f_4718_9cde_0f7cdd74481ac512e85a = (String)var5_6.next();
            v59 = 356990013 - 358545276;
            var7_9 = CRACKME_a8c1aebf_452f_4718_9cde_0f7cdd74481ac512e85a.toLowerCase();
            while (true) {
                if ((v60 = (cfr_temp_5 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-2121237369977346707L ^ -8614749728047930650L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v60 == (284661311 ^ -284661312)) break;
                v60 = 1540953266 ^ -1829206745;
            }
            CRACKME_a8c1aebf_452f_4718_9cde_0f7cdd74481a43362e91 = CRACKME_a8c1aebf_452f_4718_9cde_0f7cdd74481a63f6aba2.getInt(CRACKME_a8c1aebf_452f_4718_9cde_0f7cdd74481ac512e85a);
            -519346376 ^ -542659250;
            while (true) {
                if ((v61 = (cfr_temp_6 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-1800707331245880392L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                if (v61 == (-1157499290 ^ -1157499289)) {
                    CRACKME_a8c1aebf_452f_4718_9cde_0f7cdd74481ace68539a.merge(CRACKME_a8c1aebf_452f_4718_9cde_0f7cdd74481a79b439a0, CRACKME_a8c1aebf_452f_4718_9cde_0f7cdd74481a43362e91, (BiFunction<Integer, Integer, Integer>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;, sum(int int ), (Ljava/lang/Integer;Ljava/lang/Integer;)Ljava/lang/Integer;)());
                    continue block80;
                }
                v61 = -330498668 >>> "\u0000\u0000".length();
            }
            break;
        }
        v62 = -1996407250 ^ -1996407255;
        var10_1 = new byte[v62];
        v63 = 1521074036 - 1521074098;
        var10_1[1249560479 ^ 1249560479] = v63;
        v64 = 1395144201 ^ 1395144203;
        v65 = -532827348 ^ -532827313;
        var10_1[v64] = v65;
        var10_1[1806963680 ^ 1806963683] = -756957978 ^ -756958044;
        v66 = 487967314 ^ 487967318;
        var10_1[v66] = -1803132082 ^ -1803132132;
        v67 = -54423385 ^ -54423386;
        var10_1[v67] = 265949982 ^ -265950023;
        v68 = -297756411 ^ -297756416;
        var10_1[v68] = 1126233286 ^ 1126233223;
        var10_1[1211426208 ^ 1211426214] = 383715615 ^ 383715668;
        CRACKME_a8c1aebf_452f_4718_9cde_0f7cdd74481a2eb5f288 = new String(var10_1, "UTF-8");
        v69 = 1190508806 ^ 1190508806;
        CRACKME_a8c1aebf_452f_4718_9cde_0f7cdd74481ac512e85a = v69;
        var7_9 = CRACKME_a8c1aebf_452f_4718_9cde_0f7cdd74481ace68539a.entrySet().iterator();
        while (true) {
            498532706 ^ 2129428464;
            v70 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
            if (true) ** GOTO lbl372
            block85: while (true) {
                v70 = (-3769711847677751146L ^ -2568071927829770259L) / v71;
lbl372:
                // 2 sources

                switch ((int)v70) {
                    case -372012474: {
                        v71 = 855020197660340220L ^ -883255986388944331L;
                        continue block85;
                    }
                    case 141306124: {
                        break block85;
                    }
                }
                break;
            }
            if (!var7_9.hasNext()) {
                -2142172148 ^ 2110152545;
                return CRACKME_a8c1aebf_452f_4718_9cde_0f7cdd74481a2eb5f288;
            }
            v72 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
            block86: while (true) {
                switch ((int)v72) {
                    case -360440591: {
                        v72 = (3058519740155683L - 6817738849556374511L) / (9108492816365207320L - 8058605644215780595L);
                        continue block86;
                    }
                    case 141306124: {
                        break block86;
                    }
                }
                break;
            }
            CRACKME_a8c1aebf_452f_4718_9cde_0f7cdd74481a43362e91 = (Map.Entry)var7_9.next();
            if ((Integer)CRACKME_a8c1aebf_452f_4718_9cde_0f7cdd74481af47c7216.getValue() <= CRACKME_a8c1aebf_452f_4718_9cde_0f7cdd74481a75c3efc0) continue;
            while (true) {
                block100: {
                    if ((v73 = (cfr_temp_7 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-8801672033691572347L - -1410857965076884384L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                    if (v73 != (1826436481 ^ 1826436480)) break block100;
                    v74 = (Integer)CRACKME_a8c1aebf_452f_4718_9cde_0f7cdd74481af47c7216.getValue();
                    v75 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                    if (true) ** GOTO lbl418
                }
                v73 = -365872778 - 1804359925;
            }
            block88: while (true) {
                v75 = v76 / (1113701688866022003L - 8973254553268820235L);
lbl418:
                // 2 sources

                switch ((int)v75) {
                    case -1005504932: {
                        v76 = -7676917689106165950L ^ 5340181221551553316L;
                        continue block88;
                    }
                    case -884433419: {
                        v76 = -6859053427878227788L >>> "\u0000\u0000".length();
                        continue block88;
                    }
                    case 141306124: {
                        break block88;
                    }
                    case 1717810880: {
                        v76 = -7862400648050314397L ^ -3610986949099723293L;
                        continue block88;
                    }
                }
                break;
            }
            CRACKME_a8c1aebf_452f_4718_9cde_0f7cdd74481a75c3efc0 = v74;
            v77 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
            if (true) ** GOTO lbl438
            block89: while (true) {
                v77 = v78 / (4491693386031394897L ^ 8120781372733962291L);
lbl438:
                // 2 sources

                switch ((int)v77) {
                    case -1195715196: {
                        v78 = -8991287199235724513L - 869480784870268734L;
                        continue block89;
                    }
                    case 141306124: {
                        break block89;
                    }
                    case 655866115: {
                        v78 = 5644300780806599290L ^ -726590764540806933L;
                        continue block89;
                    }
                    case 1768399946: {
                        v78 = 2405457901426739478L ^ 8321226505259383858L;
                        continue block89;
                    }
                }
                break;
            }
            CRACKME_a8c1aebf_452f_4718_9cde_0f7cdd74481a2eb5f288 = (String)CRACKME_a8c1aebf_452f_4718_9cde_0f7cdd74481af47c7216.getKey();
            371262988 - 1417345096;
        }
    }

    /*
     * Exception decompiling
     */
    private static void AaWsD1RkfCUBqn0M(String var0, Map<String, Map<Integer, String>> var1_1, Map<String, Map<Integer, Integer>> var2_2) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 38[SWITCH]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doClass(Driver.java:84)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:78)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompile(CFRDecompiler.java:89)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompileToZip(CFRDecompiler.java:133)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.decompileSaveAll(ResourceDecompiling.java:261)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.lambda$decompileSaveAll$0(ResourceDecompiling.java:111)
         *     at java.base/java.lang.Thread.run(Thread.java:1575)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Unable to fully structure code
     */
    public static String kI2bP4AcH0qK6Mvp(String var0, int var1_1) {
        block48: {
            block47: {
                if (8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == -4536204165282645786L - 740337795597711657L) {
                    if (((4868321972720725409L == 4868321972720725410L ? -435558503 : 1891960479 ^ -1057967061) ^ (1657412552 ^ 490071095)) != 0) {
                        v0 = 6355688787312016372L == 6355688787312016373L ? -713387851 : 366820313 ^ 366820312;
                    }
                } else {
                    346122851 ^ 346122851;
                }
                while (true) {
                    if ((v1 = (cfr_temp_0 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (1169934294200598553L ^ 7316417518216691053L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                    if (v1 == (723672299 ^ -723672300)) break;
                    v1 = -981113948 ^ -789076999;
                }
                8\u0105ja.zsjN3N7fF6D1WUzb();
                1602453224 >>> "\u0000\u0000".length();
                while (true) {
                    if ((v2 = (cfr_temp_1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-1318051799667747364L ^ -5746050476207480387L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                    if (v2 == -2030162060 - -2030162059) {
                        v3 = CRACKME_e4fdff7d_37b2_4d48_934b_7822fab97e0ecb1f6b54.toLowerCase();
                        if (-5502708178981836011L == -5502708178981836010L) {
                            break;
                        }
                        break block47;
                    }
                    v2 = 684277280 - -1354737681;
                }
                v4 = -1513857310;
                break block48;
            }
            v4 = -428540466 ^ 317604356;
        }
        v5 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl40
        block28: while (true) {
            v5 = v6 / (3513330978523876053L == 3513330978523876054L ? -5816317919609915059L : -6813262902342462018L - 8138437982905047983L);
lbl40:
            // 2 sources

            switch ((int)v5) {
                case -1251586384: {
                    v6 = -1721884681527750041L ^ -4264259633365615881L;
                    continue block28;
                }
                case -38470775: {
                    if (-6441268538428384556L == -6441268538428384555L) {
                        v6 = -2377645812315873484L;
                        continue block28;
                    }
                    v6 = -5448047988321837812L ^ -6899125508577461697L;
                    continue block28;
                }
                case 141306124: {
                    break block28;
                }
            }
            break;
        }
        v7 = Collections.emptyMap();
        v8 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl58
        block29: while (true) {
            v8 = v9 / (9162126855195161605L ^ -2647240432351686052L);
lbl58:
            // 2 sources

            switch ((int)v8) {
                case -1835682733: {
                    v9 = 2146408193401407137L ^ 6060246726950605599L;
                    continue block29;
                }
                case 140313900: {
                    v9 = -657075843072937321L - 8809123930026061400L;
                    continue block29;
                }
                case 141306124: {
                    break block29;
                }
            }
            break;
        }
        v10 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl75
        block30: while (true) {
            v10 = v11 / (-1899216651957865593L - -2463899080454470077L);
lbl75:
            // 2 sources

            switch ((int)v10) {
                case -2080809580: {
                    v11 = -9013587428296104135L ^ -626705933629185010L;
                    continue block30;
                }
                case -639563426: {
                    v11 = 8001932733926636674L ^ -2981804324447385889L;
                    continue block30;
                }
                case 141306124: {
                    break block30;
                }
                case 2046038617: {
                    if (-132311040390820205L == -132311040390820204L) {
                        v11 = 4618957925647326940L;
                        continue block30;
                    }
                    v11 = -4171982354346632604L >>> "\u0000\u0000".length();
                    continue block30;
                }
            }
            break;
        }
        v12 = (int)CRACKME_e4fdff7d_37b2_4d48_934b_7822fab97e0ee666cd43;
        1873476767 ^ -2004278791;
        v13 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl106
        block31: while (true) {
            v13 = v14 / (-8740010278488170304L >>> "\u0000\u0000".length());
lbl106:
            // 2 sources

            switch ((int)v13) {
                case -1229752838: {
                    v14 = -3976122805509784369L ^ 410055121285852641L;
                    continue block31;
                }
                case 141306124: {
                    break block31;
                }
                case 939728902: {
                    v14 = -1581349672316612468L - 7025782651651182982L;
                    continue block31;
                }
                case 1064192736: {
                    v14 = -2176822218495790433L ^ 1628498542329732395L;
                    continue block31;
                }
            }
            break;
        }
        v15 = -8683967193133958735L == -8683967193133958734L ? -2085368946 : -449771205 ^ -1878805265;
        CRACKME_e4fdff7d_37b2_4d48_934b_7822fab97e0e1b73227b = 8\u0105ja.\u017bxh\u0143.getOrDefault(v3, v7).getOrDefault(v12, null);
        if (CRACKME_e4fdff7d_37b2_4d48_934b_7822fab97e0e1b73227b == null) {
            v16 = -3694586506995764526L == -3694586506995764525L ? 350073369 : -1981033696 >>> "\u0000\u0000".length();
            var4_3 = new byte[732830845 ^ 732830845];
            return new String(var4_3, "UTF-8");
        }
        v17 = new StringBuilder();
        var4_4 = new byte[66471172 ^ 66471183];
        var4_4[777426602 ^ 777426594] = 891124009 ^ 891124044;
        var4_4[-1538351469 ^ -1538351463] = -1131743302 ^ -1131743273;
        var4_4[558332845 ^ 558332846] = -1804542777861450644L == -1804542777861450643L ? 1461313110 : 1697276803 ^ 1697276919;
        var4_4[-138084373 ^ -138084373] = 6097387151419125900L == 6097387151419125901L ? -885580208 : 652188664 ^ 652188571;
        var4_4[-1622145333 ^ -1622145334] = 1439288331 ^ 1439288446;
        var4_4[435314281170352974L == 435314281170352975L ? -1407041572 : -439905248 ^ -439905244] = -1854810840 ^ -1854810809;
        var4_4[312151581 ^ 312151576] = -8237920672573757487L == -8237920672573757486L ? -80287757 : 843409185 ^ 843409228;
        var4_4[1770148012 ^ 1770148005] = -206841003 ^ -206841036;
        var4_4[2404644788436767027L == 2404644788436767028L ? -460945053 : 351886465 ^ 351886470] = -1407663676 ^ -1407663696;
        var4_4[929649191 ^ 929649185] = 652929764 ^ 652929723;
        var4_4[445355180 ^ 445355182] = 823069101 ^ 823069150;
        v18 = new String(var4_4, "UTF-8");
        while (true) {
            if ((v19 = (cfr_temp_2 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-8609883419141322712L ^ -1733466079579508982L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v19 == (804462558199877378L == 804462558199877379L ? -1376614637 : -1815791041 ^ 1815791040)) break;
            v19 = -756620691 ^ -1980282439;
        }
        v20 = v17.append(v18);
        while (true) {
            if ((v21 = (cfr_temp_3 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (3917585694732268078L == 3917585694732268079L ? -455826329787178656L : -6308120296108331766L - -6485209173473339035L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v21 == (2055091188 ^ 2055091189)) break;
            v21 = -13202165 ^ 1956940720;
        }
        v22 = 8\u0105ja.3c7pwrayAXd-4qg4(CRACKME_e4fdff7d_37b2_4d48_934b_7822fab97e0e1b73227b);
        v23 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        block34: while (true) {
            switch ((int)v23) {
                case 141306124: {
                    break block34;
                }
                case 242963984: {
                    v23 = (2952612509725324636L ^ 9121659086881486489L) / (-4303639033595593930L ^ 9001513172074536409L);
                    continue block34;
                }
            }
            break;
        }
        v24 = v20.append(v22);
        while (true) {
            if ((v25 = (cfr_temp_4 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (7001810454129395865L ^ 2426899049756106323L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v25 == (1953439073 ^ 1953439072)) break;
            if (2126756794799325655L == 2126756794799325656L) {
                v25 = 1870052556;
                continue;
            }
            v25 = 1974736719 - -1752913173;
        }
        v26 = v24.toString();
        while (true) {
            if ((v27 = (cfr_temp_5 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-4884701543654393955L ^ -1915317917388485120L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v27 == 1064788715 - 1064788716) {
                return e4wV.2al_94WjzQTnIzkU((String)v26);
            }
            v27 = 1069989794 ^ 1503559478;
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * WARNING - void declaration
     */
    private static /* synthetic */ boolean wqiqXJfNJJeGSNMZ(String string, String string2) {
        int n;
        String CRACKME_f82509dd_0d8e_4bea_bb8f_b0c1e2e9836493f1cdb8;
        void CRACKME_f82509dd_0d8e_4bea_bb8f_b0c1e2e98364b07d4ecf;
        long l = 0x77A731000EB33A47L ^ 0x829471AABF366101L;
        if (CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == l) {
            int n2 = 0xA21B1EF9 ^ 0xA21B1EF8;
        } else {
            int n3 = 0x69D6DD02 ^ 0x69D6DD02;
        }
        long l2 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        boolean bl = true;
        block4: while (true) {
            long l3;
            if (!bl || (bl = false) || !true) {
                l2 = l3 / (0x39C3DD5AA29E9A8FL ^ 0x5C956B4AE224C099L);
            }
            switch ((int)l2) {
                case 141306124: {
                    break block4;
                }
                case 1081255567: {
                    l3 = 5324750844406004702L - -1762664519993943580L;
                    continue block4;
                }
            }
            break;
        }
        if (!CRACKME_f82509dd_0d8e_4bea_bb8f_b0c1e2e98364b07d4ecf.equalsIgnoreCase(CRACKME_f82509dd_0d8e_4bea_bb8f_b0c1e2e9836493f1cdb8)) {
            byte[] byArray = new byte[0x41F94C38 ^ 0x41F94C39];
            byArray[0x9C756DE ^ 0x9C756DE] = 0x44E209BD ^ 0x44E2099D;
            String string3 = new String(byArray, "UTF-8");
            byArray = new byte[0x577EB858 ^ 0x577EB859];
            byArray[0x57F902D0 ^ 0x57F902D0] = 0x6B6CFA76 ^ 0x6B6CFA5B;
            String string4 = CRACKME_f82509dd_0d8e_4bea_bb8f_b0c1e2e98364b07d4ecf.replace(string3, new String(byArray, "UTF-8"));
            while (true) {
                long l4;
                long l5;
                if ((l5 = (l4 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (90312425634964620L - -1583507510038987872L)) == 0L ? 0 : (l4 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (l5 == (0xB7ABD0C0 ^ 0xB7ABD0C1)) {
                    if (string4.equalsIgnoreCase(CRACKME_f82509dd_0d8e_4bea_bb8f_b0c1e2e9836493f1cdb8)) break;
                    n = 0x5DA0975B ^ 0x5DA0975B;
                    int cfr_ignored_2 = -1511921615 - -1498832796;
                    return n != 0;
                }
                l5 = 0xAE36F2B2 ^ 0xD58D2977;
            }
        }
        n = 0x5551FA54 ^ 0x5551FA55;
        return n != 0;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     */
    public static String isqk4R50Q1Q2B3PR(String string) {
        String CRACKME_33acfdbd_dbe1_4b98_8776_9ac40ec09a199d30fe46;
        if (CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == (0x198830FF0B42403BL ^ 0x941E08B062B9002CL)) {
            int cfr_ignored_4 = 0xE6548B58 ^ 0xE6548B59;
        } else {
            int cfr_ignored_5 = 0xA5C7C118 ^ 0xA5C7C118;
        }
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-4986769302463864322L - -8697246170725562768L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0xAD41F0E2 ^ 0xAD41F0E3)) break;
            l2 = 0x66BD963F ^ 0x9CF14210;
        }
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-1773159510769332788L - 1600706249386386588L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            int n = 0x3F4C16BE ^ 0x3F4C16BF;
            if (l3 == n) break;
            l3 = 638733584 - -1016805996;
        }
        StringBuilder stringBuilder = new StringBuilder();
        byte[] byArray = new byte[0x1E043BCD ^ 0x1E043BC6];
        int n = 0x71DF575D ^ 0x71DF5730;
        byArray[0x96B7E8C0 ^ 0x96B7E8CA] = n;
        int n2 = 0xBBA16C60 ^ 0xBBA16C14;
        byArray[0xE04041A4 ^ 0xE04041A3] = n2;
        byArray[0x3C029E33 ^ 0x3C029E36] = 0xEBA33709 ^ 0xEBA33764;
        int n3 = 0xE393F0E9 ^ 0xE393F0E1;
        byArray[n3] = 0x7D9BBEDA ^ 0x7D9BBEBF;
        byArray[0x820FC6AA ^ 0x820FC6A3] = 0x7E480362 ^ 0x7E480303;
        int n4 = 0xA10F769F ^ 0xA10F769F;
        byArray[n4] = 0xDE06CA47 ^ 0xDE06CA24;
        int n5 = 0x91385D7F ^ 0x91385D7B;
        int n6 = 0x2B0C1DD6 ^ 0x2B0C1DB9;
        byArray[n5] = n6;
        byArray[0x53832694 ^ 0x53832692] = 0x2126521F ^ 0x21265240;
        byArray[0x4DD56783 ^ 0x4DD56782] = 0x5FCDE1B3 ^ 0x5FCDE1C6;
        byArray[0x2C76DBA2 ^ 0x2C76DBA0] = 0x77D7A44E ^ 0x77D7A43D;
        byArray[0xD9150EFF ^ 0xD9150EFC] = 0xCF3D03D0 ^ 0xCF3D03A4;
        String string2 = new String(byArray, "UTF-8");
        while (true) {
            long l;
            long l4;
            if ((l4 = (l = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-3506647905125737175L - 6628633841556526190L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l4 == (0x9451191F ^ 0x6BAEE6E0)) break;
            l4 = 0x548F1A06 ^ 0x8E2FF26E;
        }
        StringBuilder stringBuilder2 = stringBuilder.append(string2);
        int n7 = 598651348 >>> "\u0000\u0000".length();
        long l = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        block16: while (true) {
            switch ((int)l) {
                case 141306124: {
                    break block16;
                }
                case 619129168: {
                    l = (7536027840537549263L - -4890505895509849919L) / (0xA9AF0DA2416A72F2L ^ 0x7A81BAAAA01F96FDL);
                    continue block16;
                }
            }
            break;
        }
        String string3 = 8\u0105ja.3c7pwrayAXd-4qg4(CRACKME_33acfdbd_dbe1_4b98_8776_9ac40ec09a199d30fe46);
        long l5 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        block17: while (true) {
            switch ((int)l5) {
                case 141306124: {
                    break block17;
                }
                case 808523129: {
                    l5 = (0x4399DC890782907EL ^ 0xE57A35F3F18007FBL) / (-3884814171027594774L - -8637533132138015258L);
                    continue block17;
                }
            }
            break;
        }
        String string4 = stringBuilder2.append(string3).toString();
        long l6 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        boolean bl = true;
        block18: while (true) {
            long l7;
            if (!bl || (bl = false) || !true) {
                l6 = l7 / (-6375017033944861227L - -1690960759369673495L);
            }
            switch ((int)l6) {
                case 141306124: {
                    return e4wV.2al_94WjzQTnIzkU((String)string4);
                }
                case 1282484687: {
                    l7 = 0x47D763CEE9888278L ^ 0x9602E6EA7D5126ACL;
                    continue block18;
                }
                case 1948923838: {
                    l7 = 0x49C142184E756F64L ^ 0x879FFC1ABFEF1BD7L;
                    continue block18;
                }
            }
            break;
        }
        return e4wV.2al_94WjzQTnIzkU((String)string4);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     */
    public static String HDI5RgWorueWpl57(String string) {
        Map.Entry<Integer, String> CRACKME_3c3922c5_33d2_42e3_b7e9_ea93ca8d1aa2211209cf;
        if (CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == (0x69B84E50D61A2AABL ^ 0x9019BDA3848D77AFL)) {
            int cfr_ignored_7 = 0xBC8D3460 ^ 0xBC8D3461;
        } else {
            int cfr_ignored_8 = 0x702BBB71 ^ 0x702BBB71;
        }
        int n = 1059720910 - 1405098807;
        long l = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        block24: while (true) {
            switch ((int)l) {
                case -1516419337: {
                    l = (-8749343698734673480L - -366313727816679213L) / (0x4184361016576903L ^ 0x6568CE1EC5116E6L);
                    continue block24;
                }
                case 141306124: {
                    break block24;
                }
            }
            break;
        }
        8\u0105ja.zsjN3N7fF6D1WUzb();
        long l2 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        block25: while (true) {
            switch ((int)l2) {
                case -2043155660: {
                    l2 = (0xAAEFAAFC382A4700L ^ 0xCFD93AC33E20F3EEL) / (0x246221EE5251C39L ^ 0x6C92333014682673L);
                    continue block25;
                }
                case 141306124: {
                    break block25;
                }
            }
            break;
        }
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (0x5260CBE875FCA34EL ^ 0x99BA74D5DE3624B8L)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
            if (l4 == (0xEF3A8D08 ^ 0xEF3A8D09)) break;
            l4 = 0x843F0F75 ^ 0x3CC59938;
        }
        Iterator<Map.Entry<Integer, String>> iterator = \u0119X\u01431.entrySet().iterator();
        block27: while (true) {
            int cfr_ignored_9 = 0x36A55121 ^ 0x4C591C50;
            long l5 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
            boolean bl = true;
            block28: while (true) {
                long l6;
                if (!bl || (bl = false) || !true) {
                    long l7 = 0xB0701F731F3C5A03L ^ 0x3B0DC5CE01D9C385L;
                    l5 = l6 / l7;
                }
                switch ((int)l5) {
                    case -1455514446: {
                        l6 = -5225179901115316827L - 3786371280927900915L;
                        continue block28;
                    }
                    case -339336956: {
                        l6 = 0x14B44A3721D214C6L ^ 0xBAEE6072C7C0B176L;
                        continue block28;
                    }
                    case 141306124: {
                        break block28;
                    }
                    case 332902749: {
                        l6 = 0x67393548B29CB63L ^ 0x2EE4100592497149L;
                        continue block28;
                    }
                }
                break;
            }
            if (!iterator.hasNext()) {
                byte[] byArray = new byte[0xEC661A5D ^ 0xEC661A58];
                byArray[0xABAFC33E ^ 0xABAFC33D] = 0x4CF7F0CB ^ 0x4CF7F0E6;
                byArray[0x8AE67F77 ^ 0x8AE67F75] = 0x97603A0B ^ 0x97603A68;
                int n2 = 0x94D5A395 ^ 0x94D5A391;
                int n3 = 0x61AE6ABD ^ 0x61AE6A90;
                byArray[n2] = n3;
                int n4 = 0xE2458577 ^ 0xE2458576;
                int n5 = 0xD3D08172 ^ 0x2C2F7ED5;
                byArray[n4] = n5;
                byArray[0x26B7060B ^ 0x26B7060B] = 0xCFE18952 ^ 0x301E7690;
                return new String(byArray, "UTF-8");
            }
            long l8 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
            boolean bl2 = true;
            block29: while (true) {
                long l9;
                if (!bl2 || (bl2 = false) || !true) {
                    long l10 = 0x3D767D4C4FCCA2B0L ^ 0xED4646873EB7AB6L;
                    l8 = l9 / l10;
                }
                switch ((int)l8) {
                    case 141306124: {
                        break block29;
                    }
                    case 405033769: {
                        l9 = 0x44E42BA99F2C4C62L ^ 0xED1C9E015048BFFDL;
                        continue block29;
                    }
                    case 437314558: {
                        l9 = 0x5AA0FE8621E8E504L ^ 0x8A2C5D2B69E98366L;
                        continue block29;
                    }
                }
                break;
            }
            int cfr_ignored_10 = -707992996 - -1079433605;
            CRACKME_3c3922c5_33d2_42e3_b7e9_ea93ca8d1aa2211209cf = iterator.next();
            while (true) {
                long l11;
                long l12;
                if ((l12 = (l11 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-7649380206757377716L - 7843182610607452323L)) == 0L ? 0 : (l11 < 0L ? -1 : 1)) == false) continue;
                int n6 = 0x88444268 ^ 0x88444269;
                if (l12 == n6) {
                    String CRACKME_3c3922c5_33d2_42e3_b7e9_ea93ca8d1aa276aad55d;
                    if (!CRACKME_3c3922c5_33d2_42e3_b7e9_ea93ca8d1aa2211209cf.getValue().equalsIgnoreCase(CRACKME_3c3922c5_33d2_42e3_b7e9_ea93ca8d1aa276aad55d)) continue block27;
                    break block27;
                }
                l12 = 0x2577556B ^ 0x4F1A698;
            }
            break;
        }
        int cfr_ignored_11 = 0x89CE666 ^ 0x73D48380;
        long l13 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        boolean bl = true;
        block31: while (true) {
            long l14;
            if (!bl || (bl = false) || !true) {
                l13 = l14 / (0x95BB45DA3BC9AC3FL ^ 0x2652C306C4950265L);
            }
            switch ((int)l13) {
                case -628066560: {
                    l14 = -1334770626888536920L - 5376347284261592023L;
                    continue block31;
                }
                case -612034354: {
                    l14 = 5312188749029676149L - 1975898274692378392L;
                    continue block31;
                }
                case 141306124: {
                    break block31;
                }
            }
            break;
        }
        byte[] byArray = new byte[0xE3E2EA97 ^ 0xE3E2EA96];
        byArray[0x54BF1A4D ^ 0x54BF1A4D] = 0x83B9FDB5 ^ 0x83B9FD96;
        StringBuilder stringBuilder = new StringBuilder().append(new String(byArray, "UTF-8"));
        while (true) {
            long l15;
            long l16;
            if ((l16 = (l15 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (0x707A873036753BF9L ^ 0xF71E6091F745832EL)) == 0L ? 0 : (l15 < 0L ? -1 : 1)) == false) continue;
            if (l16 == (0x164EE744 ^ 0x164EE745)) break;
            l16 = -267694640 - -1568938635;
        }
        StringBuilder stringBuilder2 = stringBuilder.append(CRACKME_3c3922c5_33d2_42e3_b7e9_ea93ca8d1aa2211209cf.getKey());
        while (true) {
            long l17;
            long l18;
            if ((l18 = (l17 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (0x51C4711BBB93B010L ^ 0x2B28AE6646C365B1L)) == 0L ? 0 : (l17 < 0L ? -1 : 1)) == false) continue;
            if (l18 == 771989363 - 771989364) {
                return stringBuilder2.toString();
            }
            l18 = 0xC58F3553 ^ 0x4F683FA6;
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     */
    public static String 4q-1n32pjem4tAIC(int n) {
        String CRACKME_dbb15400_bfaa_4ef3_b77a_435b1d013e6bfa9878f2;
        block42: {
            int CRACKME_dbb15400_bfaa_4ef3_b77a_435b1d013e6bb5ef340b;
            if (CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == 3225221825728863810L - -5249974242122569583L) {
                int cfr_ignored_7 = 0x1A975CDF ^ 0x1A975CDE;
            } else {
                int cfr_ignored_8 = 0xA14CFB66 ^ 0xA14CFB66;
            }
            8\u0105ja.zsjN3N7fF6D1WUzb();
            long l = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
            boolean bl = true;
            block25: while (true) {
                long l2;
                if (!bl || (bl = false) || !true) {
                    long l3 = 6888713924544129743L - 3962432942411379846L;
                    l = l2 / l3;
                }
                switch ((int)l) {
                    case -1901659165: {
                        l2 = 0x84641A3837B0F38DL ^ 0x5D2F4800182973FEL;
                        continue block25;
                    }
                    case -1434142831: {
                        l2 = 6634343273523736013L - 623294327189014558L;
                        continue block25;
                    }
                    case -1184680874: {
                        l2 = 0xAB9982AE0D003ECBL ^ 0xFC270A5BDBD46BA2L;
                        continue block25;
                    }
                    case 141306124: {
                        break block25;
                    }
                }
                break;
            }
            long l4 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
            block26: while (true) {
                switch ((int)l4) {
                    case -859140293: {
                        l4 = (-5009780309654793416L - 6242561719639322556L) / (0x405654FDFA9B0EA8L ^ 0xB1BC611A3E0A52FDL);
                        continue block26;
                    }
                    case 141306124: {
                        break block26;
                    }
                }
                break;
            }
            Integer n2 = CRACKME_dbb15400_bfaa_4ef3_b77a_435b1d013e6bb5ef340b;
            int cfr_ignored_9 = 0xD5039660 ^ 0x843E754D;
            while (true) {
                long l5;
                long l6;
                if ((l6 = (l5 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-3758224697486115824L - -806230817220690874L)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
                if (l6 == (0xC3D975BB ^ 0xC3D975BA)) {
                    CRACKME_dbb15400_bfaa_4ef3_b77a_435b1d013e6bfa9878f2 = \u0118\u01790F.getOrDefault(n2, null);
                    int cfr_ignored_10 = 0xF9A4EEF6 ^ 0xB7507261;
                    if (CRACKME_dbb15400_bfaa_4ef3_b77a_435b1d013e6bfa9878f2 == null) {
                        break;
                    }
                    break block42;
                }
                l6 = 0x45299730 ^ 0xBA694D1F;
            }
            byte[] byArray = new byte[0x86F0D748 ^ 0x86F0D749];
            byArray[0xE684E48E ^ 0xE684E48E] = 0xF7BFF3E0 ^ 0xF7BFF3D0;
            return new String(byArray, "UTF-8");
        }
        long l = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        boolean bl = true;
        block28: while (true) {
            long l7;
            if (!bl || (bl = false) || !true) {
                l = l7 / (-5769594048908359384L - -435126633425199672L);
            }
            switch ((int)l) {
                case -1449990536: {
                    l7 = -7237766323235130657L - -4046676958894452405L;
                    continue block28;
                }
                case -1318899119: {
                    l7 = 2581138988067035939L - 5463097568176151338L;
                    continue block28;
                }
                case 141306124: {
                    break block28;
                }
            }
            break;
        }
        while (true) {
            long l8;
            long l9;
            if ((l9 = (l8 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (0xFA3EBB178C85FB00L ^ 0x21FFA50D09B7B127L)) == 0L ? 0 : (l8 < 0L ? -1 : 1)) == false) continue;
            if (l9 == (0x8363C09 ^ 0x8363C08)) break;
            l9 = 0xBED3EDD8 ^ 0xE976501A;
        }
        int n3 = 0xFD5F8398 ^ 0xFD5F8393;
        byte[] byArray = new byte[n3];
        byArray[0x5893E4C0 ^ 0x5893E4C0] = 0xCD7A7DEE ^ 0xCD7A7D8D;
        int n4 = 0xF57343F7 ^ 0xF57343F4;
        int n5 = 0xBE7CE778 ^ 0xBE7CE70C;
        byArray[n4] = n5;
        int n6 = 0xE9484E6B ^ 0xE9484E62;
        int n7 = 0x9B3FE262 ^ 0x9B3FE203;
        byArray[n6] = n7;
        byArray[0xC391E9D7 ^ 0xC391E9DD] = 0xA82D6105 ^ 0xA82D6168;
        byArray[0x2949F0AE ^ 0x2949F0AB] = 0x9614DBF4 ^ 0x9614DB99;
        int n8 = 0x7536DD0E ^ 0x7536DD09;
        byArray[n8] = 0xF36CBC34 ^ 0xF36CBC40;
        byArray[0xC29F064E ^ 0xC29F064C] = 0xBBD67E1B ^ 0xBBD67E68;
        int n9 = 0x8EB25E31 ^ 0x8EB25E6E;
        byArray[0xEAB6A765 ^ 0xEAB6A763] = n9;
        int n10 = 0x690413F ^ 0x690413B;
        int n11 = 0xBF760A10 ^ 0xBF760A7F;
        byArray[n10] = n11;
        int n12 = 0x110AA569 ^ 0x110AA568;
        byArray[n12] = 0x48CA8304 ^ 0x48CA8371;
        byArray[0xCE46A425 ^ 0xCE46A42D] = 0x154DD51E ^ 0x154DD57B;
        StringBuilder stringBuilder = new StringBuilder().append(new String(byArray, "UTF-8"));
        int cfr_ignored_11 = 0xB0295BF5 ^ 0x7220213A;
        long l10 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        block30: while (true) {
            switch ((int)l10) {
                case 141306124: {
                    break block30;
                }
                case 514798931: {
                    l10 = (1315507465847645772L - -5588615193588519459L) / (0xE1DB6028321385F8L ^ 0xA1E916A0310D487EL);
                    continue block30;
                }
            }
            break;
        }
        String string = 8\u0105ja.3c7pwrayAXd-4qg4(CRACKME_dbb15400_bfaa_4ef3_b77a_435b1d013e6bfa9878f2);
        int cfr_ignored_12 = -10556240 - 1603862570;
        long l11 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        boolean bl2 = true;
        block31: while (true) {
            long l12;
            if (!bl2 || (bl2 = false) || !true) {
                l11 = l12 / (0x266F4A81811D21D6L ^ 0xE45FB65B8A102401L);
            }
            switch ((int)l11) {
                case -2058972820: {
                    l12 = -4161597323283700216L - -6511751490231984848L;
                    continue block31;
                }
                case -1682210890: {
                    l12 = -3199112358761842923L - -2291814439089194752L;
                    continue block31;
                }
                case -1076807346: {
                    l12 = 156717463141519906L - -7288327499322057237L;
                    continue block31;
                }
                case 141306124: {
                    break block31;
                }
            }
            break;
        }
        StringBuilder stringBuilder2 = stringBuilder.append(string);
        int cfr_ignored_13 = 956512371 - 213249563;
        while (true) {
            long l13;
            long l14;
            if ((l14 = (l13 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (0xB9AF5DB6F706331EL ^ 0xCA2068F680E5F363L)) == 0L ? 0 : (l13 < 0L ? -1 : 1)) == false) continue;
            int n13 = 0x3DD460F ^ 0xFC22B9F0;
            if (l14 == n13) break;
            l14 = 0x8B185D29 ^ 0xEDE25394;
        }
        String string2 = stringBuilder2.toString();
        while (true) {
            long l15;
            long l16;
            if ((l16 = (l15 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (0xD15C9AF0162F4368L ^ 0xC4C25569432E1966L)) == 0L ? 0 : (l15 < 0L ? -1 : 1)) == false) continue;
            int n14 = 0x5B04E818 ^ 0x5B04E819;
            if (l16 == n14) {
                return e4wV.2al_94WjzQTnIzkU((String)string2);
            }
            l16 = 0x6F939343 ^ 0x730C83A4;
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * WARNING - void declaration
     */
    public static Integer 29x0Qgm99hDNrRxo(String string) {
        void CRACKME_eeb38838_1f52_4b9d_b4f1_c84655f607aa1f404e14;
        String CRACKME_eeb38838_1f52_4b9d_b4f1_c84655f607aa74ee6121;
        long l = 0xD36B52B11567744DL ^ 0xD1C936D90C72185DL;
        if (CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == l) {
            int cfr_ignored_8 = 0x73C3DAA7 ^ 0x73C3DAA6;
        } else {
            int n = 0x30C2B01F ^ 0x30C2B01F;
        }
        if (\u0142Dzn == null) {
            8\u0105ja.DQJ-rNp6qH1KLeAn();
            while (true) {
                long l2 = 0x7F4E4D4174E4811CL ^ 0x3A43570650ED4E96L;
                long l3 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - l2;
                long l4 = l3 == 0L ? 0 : (l3 < 0L ? -1 : 1);
                if (l4 == false) continue;
                int n = 0x29C51DA3 ^ 0x29C51DA2;
                if (l4 == n) {
                    if (\u0142Dzn == null) {
                        return null;
                    }
                    break;
                }
                l4 = 428297339 - -2083953744;
            }
        }
        String string2 = CRACKME_eeb38838_1f52_4b9d_b4f1_c84655f607aa74ee6121.toLowerCase();
        long l5 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        boolean bl = true;
        block21: while (true) {
            long l6;
            if (!bl || (bl = false) || !true) {
                long l7 = 0x224DFCBE9207C8DAL ^ 0xB193ADF731EA7919L;
                l5 = l6 / l7;
            }
            switch ((int)l5) {
                case -1752425139: {
                    l6 = 0x8602686FA6EFA803L ^ 0x7B456CF8EF922D34L;
                    continue block21;
                }
                case -1494151913: {
                    l6 = -6907285153411827588L >>> "\u0000\u0000".length();
                    continue block21;
                }
                case 141306124: {
                    break block21;
                }
            }
            break;
        }
        long l8 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        boolean bl2 = true;
        block22: while (true) {
            long l9;
            if (!bl2 || (bl2 = false) || !true) {
                l8 = l9 / (0xE4AFD55292C2B149L ^ 0x8716AF41630317C1L);
            }
            switch ((int)l8) {
                case 141306124: {
                    break block22;
                }
                case 239986965: {
                    l9 = 0x57F9BD55EADBF7FAL ^ 0x54A0995A120D2289L;
                    continue block22;
                }
                case 1193376318: {
                    l9 = 2669036353590792760L >>> "\u0000\u0000".length();
                    continue block22;
                }
                case 1241530299: {
                    l9 = 0x9B0487F534EF8388L ^ 0xBAAEED111B29BF6DL;
                    continue block22;
                }
            }
            break;
        }
        Collection<\u00d3vR\u017a> collection = \u0142Dzn.values();
        long l10 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        boolean bl3 = true;
        block23: while (true) {
            long l11;
            if (!bl3 || (bl3 = false) || !true) {
                long l12 = 0x1FF537478A1CCEFFL ^ 0xA94E681CEECE80EFL;
                l10 = l11 / l12;
            }
            switch ((int)l10) {
                case -1366089598: {
                    l11 = -4803959494394520152L >>> "\u0000\u0000".length();
                    continue block23;
                }
                case 141306124: {
                    break block23;
                }
                case 1759532272: {
                    l11 = -1905394566468691903L - -4962324233792456882L;
                    continue block23;
                }
            }
            break;
        }
        Iterator<\u00d3vR\u017a> iterator = collection.iterator();
        block24: while (true) {
            long l13 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
            boolean bl4 = true;
            block25: while (true) {
                long l14;
                if (!bl4 || (bl4 = false) || !true) {
                    l13 = (7361768079544820964L - 4593082147518811118L) / l14;
                }
                switch ((int)l13) {
                    case -409031136: {
                        l14 = -2500403590512663340L - -90241307678102657L;
                        continue block25;
                    }
                    case 141306124: {
                        break block25;
                    }
                }
                break;
            }
            if (!iterator.hasNext()) return null;
            int cfr_ignored_9 = 0x6FE8BC57 ^ 0x76800B1;
            \u00d3vR\u017a \u00f3vR\u017a = iterator.next();
            int n = -1535334396 - -1269075626;
            while (true) {
                long l15;
                long l16;
                if ((l16 = (l15 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (5598799462081066521L - -3160318715616745147L)) == 0L ? 0 : (l15 < 0L ? -1 : 1)) == false) continue;
                int n2 = 0x7E5A05BB ^ 0x81A5FA44;
                if (l16 == n2) break;
                l16 = 0x80763DEF ^ 0x7C664998;
            }
            String string3 = CRACKME_eeb38838_1f52_4b9d_b4f1_c84655f607aa1f404e14.\u0142W\u015aq.toLowerCase();
            while (true) {
                long l17;
                long l18;
                if ((l18 = (l17 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (0xD2F3E5E242D05446L ^ 0x2B19CA502B13D321L)) == 0L ? 0 : (l17 < 0L ? -1 : 1)) == false) continue;
                if (l18 == (0xE3A8D242 ^ 0xE3A8D243)) {
                    void CRACKME_eeb38838_1f52_4b9d_b4f1_c84655f607aad368dc18;
                    if (!string3.equals(CRACKME_eeb38838_1f52_4b9d_b4f1_c84655f607aad368dc18)) continue block24;
                    break block24;
                }
                l18 = 0xD1659B69 ^ 0x347D9FFD;
            }
            break;
        }
        while (true) {
            long l19;
            long l20;
            if ((l20 = (l19 = CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (2460220251928723604L - -1606399344256799592L)) == 0L ? 0 : (l19 < 0L ? -1 : 1)) == false) continue;
            if (l20 == (0x2DBFD412 ^ 0x2DBFD413)) {
                return CRACKME_eeb38838_1f52_4b9d_b4f1_c84655f607aa1f404e14.kSX0;
            }
            l20 = 1676205696 - -2007116069;
        }
    }

    /*
     * Exception decompiling
     */
    private static void 56joq7rvWcJQhWto(String var0, Map<Integer, String> var1_1, Map<Integer, Integer> var2_2) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 17[SWITCH]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doClass(Driver.java:84)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:78)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompile(CFRDecompiler.java:89)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompileToZip(CFRDecompiler.java:133)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.decompileSaveAll(ResourceDecompiling.java:261)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.lambda$decompileSaveAll$0(ResourceDecompiling.java:111)
         *     at java.base/java.lang.Thread.run(Thread.java:1575)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Unable to fully structure code
     */
    public static String EqG0rr8ENpzB71Op(String var0, int var1_1) {
        if (8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == (-1847104990904134469L == -1847104990904134468L ? 5492914296204716553L : 6220736659826799835L - 1289796194210547083L)) {
            if ((-198133004 ^ 1480782900 ^ (126306731 ^ 2021176916)) != 0) {
                -249699068 ^ -249699067;
            }
        } else {
            -309302236 ^ -309302236;
        }
        while (true) {
            if ((v0 = (cfr_temp_0 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-7703340009621144665L == -7703340009621144664L ? 248323532412909908L : -6536854882703494646L ^ -4908850947446067193L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (1077493750 ^ 1077493751)) break;
            if (3271813852158791512L == 3271813852158791513L) {
                v0 = -1409127199;
                continue;
            }
            v0 = -610760958 ^ 129446133;
        }
        8\u0105ja.zsjN3N7fF6D1WUzb();
        while (true) {
            block35: {
                if ((v1 = (cfr_temp_1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-4513240668591263951L == -4513240668591263950L ? 117761410569287555L : -5411215691506891389L - 5270108697839933620L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v1 != -1906510852 - -1906510851) break block35;
                v2 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl30
            }
            v1 = -1910659736 >>> "\u0000\u0000".length();
        }
        block22: while (true) {
            v2 = v3 / (598765839914477888L == 598765839914477889L ? -8752643168893884437L : 4341803997381982757L ^ 8683793268010491256L);
lbl30:
            // 2 sources

            switch ((int)v2) {
                case 82499006: {
                    v3 = 3060608310166677993L ^ 5302039180294468870L;
                    continue block22;
                }
                case 141306124: {
                    break block22;
                }
                case 1183399939: {
                    v3 = -2927889443476168586L - 5185544514958383371L;
                    continue block22;
                }
                case 1872938564: {
                    v3 = 7966249263146471100L >>> "\u0000\u0000".length();
                    continue block22;
                }
            }
            break;
        }
        v4 = CRACKME_71d8bc7b_f48e_4952_8190_5484e1f27a487fdd9eff.toLowerCase();
        v5 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        block23: while (true) {
            switch ((int)v5) {
                case 141306124: {
                    break block23;
                }
                case 1208322563: {
                    v5 = (-1076539901868114839L ^ -4814198085276205236L) / (7871391482891508180L ^ 1237751429687934524L);
                    continue block23;
                }
            }
            break;
        }
        v6 = Collections.emptyMap();
        while (true) {
            block36: {
                if ((v7 = (cfr_temp_2 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-3298859116315878062L == -3298859116315878061L ? 8575013375409015229L : -3009350242351783222L ^ 2338371454298994362L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v7 != (1613680529 ^ 1613680528)) break block36;
                v8 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl65
            }
            if (-6197687292638774852L == -6197687292638774851L) {
                v7 = 1980030586;
                continue;
            }
            v7 = 772125623 - -1316140319;
        }
        block25: while (true) {
            v8 = v9 / (2726805392577283751L ^ -2550588620670919504L);
lbl65:
            // 2 sources

            switch ((int)v8) {
                case -1442019973: {
                    v9 = 5507614163045119656L ^ 4275779395032146774L;
                    continue block25;
                }
                case 141306124: {
                    break block25;
                }
                case 611548301: {
                    if (1450441732344651982L == 1450441732344651983L) {
                        v9 = 6961649621344389558L;
                        continue block25;
                    }
                    v9 = 3527700473742627245L - 6708114759180797274L;
                    continue block25;
                }
            }
            break;
        }
        v10 = (int)CRACKME_71d8bc7b_f48e_4952_8190_5484e1f27a488f884b5e;
        v11 = 1785598023 ^ 1785598023;
        v12 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl83
        block26: while (true) {
            v12 = v13 / (-926272690450177131L ^ 7395045393836240744L);
lbl83:
            // 2 sources

            switch ((int)v12) {
                case 141306124: {
                    break block26;
                }
                case 474668355: {
                    if (1893499012948552948L == 1893499012948552949L) {
                        v13 = 6542528283826057492L;
                        continue block26;
                    }
                    v13 = -5825084763130594442L - 3951991531326152573L;
                    continue block26;
                }
                case 687629493: {
                    if (8056456555504124695L == 8056456555504124696L) {
                        v13 = 1366536431414364090L;
                        continue block26;
                    }
                    v13 = 1257397001879862979L - -9083350009686281332L;
                    continue block26;
                }
            }
            break;
        }
        var2_2 = 8\u0105ja.\u0107\u017ceK.getOrDefault(v4, v6).getOrDefault(v10, v11);
        555966985 ^ -1438408231;
        return 24XS.h_4UABwP3uGOOmhd((int)CRACKME_71d8bc7b_f48e_4952_8190_5484e1f27a48816b505d.intValue());
    }

    /*
     * Exception decompiling
     */
    private static void ewJhNZpZ9rfUOKa5(String var0, Map<Integer, String> var1_1, Map<Integer, Double> var2_2) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Extractable last case doesn't follow previous, and can't clone.
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:611)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.rebuildSwitches(SwitchReplacer.java:406)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:601)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doClass(Driver.java:84)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:78)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompile(CFRDecompiler.java:89)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompileToZip(CFRDecompiler.java:133)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.decompileSaveAll(ResourceDecompiling.java:261)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.lambda$decompileSaveAll$0(ResourceDecompiling.java:111)
         *     at java.base/java.lang.Thread.run(Thread.java:1575)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Unable to fully structure code
     */
    public static \u00d3vR\u017a BQptGjO0la9wx-GD(String var0) {
        if (8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == 1907741456454046462L - 3790354521991005830L) {
            1562305427 ^ 1562305426;
        } else {
            -50891336 ^ -50891336;
        }
        if (8\u0105ja.\u0142Dzn == null) {
            while (true) {
                v0 = -914486343117887844L ^ 1308468592533490652L;
                cfr_temp_0 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - v0;
                v1 = cfr_temp_0 == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1);
                if (v1 == false) continue;
                v2 = -844011070 ^ -844011069;
                if (v1 == v2) break;
                v1 = 1571058568 ^ -880699482;
            }
            8\u0105ja.DQJ-rNp6qH1KLeAn();
            v3 = 1647686818 ^ -1979188978;
            while (true) {
                if ((v4 = (cfr_temp_1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (8724540986075926014L ^ -3772385168563856269L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v4 == (-740453160 ^ -740453159)) {
                    if (8\u0105ja.\u0142Dzn == null) {
                        return null;
                    }
                    break;
                }
                v4 = 382182589 ^ -189067508;
            }
        }
        v5 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        block93: while (true) {
            switch ((int)v5) {
                case 141306124: {
                    break block93;
                }
                case 1358264252: {
                    v5 = (3101181074807065661L ^ 5312200865171843130L) / (-8021763368838064157L - 4289965261125186911L);
                    continue block93;
                }
            }
            break;
        }
        while (true) {
            block141: {
                if ((v6 = (cfr_temp_2 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (5474741126566864641L ^ -576659392425516304L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                v7 = -119199704 ^ -119199703;
                if (v6 != v7) break block141;
                v8 = zNb\u015b.Y\u017btq.getConfig();
                var13_1 = new byte[1951995746 ^ 1951995753];
                v9 = -1595868475 ^ -1595868500;
                var13_1[-1783650447 ^ -1783650448] = v9;
                v10 = 1408119227 ^ 1408119258;
                var13_1[-621819530 ^ -621819522] = v10;
                v11 = -1961784598 ^ -1961784703;
                var13_1[363304820 ^ 363304817] = v11;
                v12 = -1251084823 ^ -1251084926;
                var13_1[-1325171610 ^ -1325171612] = v12;
                var13_1[1327647292 ^ 1327647290] = 951054109 ^ 951054146;
                v13 = 1763266112 ^ 1763266115;
                v14 = 1902002427 ^ 1902002319;
                var13_1[v13] = v14;
                var13_1[740956898 ^ 740956907] = 575637554 ^ 575637599;
                var13_1[786615701 ^ 786615711] = 32152811 ^ 32152718;
                v15 = -1594708101 ^ -1594708203;
                var13_1[605302264 ^ 605302271] = v15;
                var13_1[-1151288116 ^ -1151288120] = 2000309206 ^ 2000309177;
                var13_1[-165020579 ^ -165020579] = 1504235368 ^ 1504235292;
                v16 = new String(var13_1, "UTF-8");
                v17 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl80
            }
            v6 = -830513338 - 1085070093;
        }
        block95: while (true) {
            v18 = -7990252755078809833L - 180142607999889066L;
            v17 = v19 / v18;
lbl80:
            // 2 sources

            switch ((int)v17) {
                case -1693855850: {
                    v19 = 6049241517408577054L ^ -5977037159123566481L;
                    continue block95;
                }
                case -1677431243: {
                    v19 = -4113951046146614749L ^ -8964473402749241589L;
                    continue block95;
                }
                case -191932481: {
                    v19 = -4976870588436624757L ^ 3448000279950486058L;
                    continue block95;
                }
                case 141306124: {
                    break block95;
                }
            }
            break;
        }
        v20 = v8.getString(v16);
        v21 = -978216180 ^ -978216179;
        var13_1 = new byte[v21];
        var13_1[-385307293 ^ -385307293] = -1695175164 ^ -1695175126;
        v22 = new String(var13_1, "UTF-8");
        var13_1 = new byte[625469636 ^ 625469637];
        v23 = 1754119100 ^ 1754119100;
        var13_1[v23] = 47310010 ^ 47309975;
        v24 = new String(var13_1, "UTF-8");
        v25 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        block96: while (true) {
            switch ((int)v25) {
                case -1415407727: {
                    v25 = (4973763817939120077L - -3212726671355911249L) / (-4453057147796867344L ^ 432775841604527776L);
                    continue block96;
                }
                case 141306124: {
                    break block96;
                }
            }
            break;
        }
        var1_2 = v20.replace(v22, v24);
        while (true) {
            block142: {
                if ((v26 = (cfr_temp_3 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (8348693980464788395L ^ -4503151523940227540L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v26 != (-898676532 ^ -898676531)) break block142;
                v27 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl124
            }
            v26 = -92159763 - -494168783;
        }
        block98: while (true) {
            v28 = 1824318423997767855L ^ 8803003418440173146L;
            v27 = v29 / v28;
lbl124:
            // 2 sources

            switch ((int)v27) {
                case -1643506522: {
                    v29 = 4366250013087256065L ^ 5290984144777844377L;
                    continue block98;
                }
                case -816160468: {
                    v29 = -2284034267014417147L ^ 1481455491568757070L;
                    continue block98;
                }
                case 141306124: {
                    break block98;
                }
                case 954066731: {
                    v29 = 6715315134707993183L - -1769188556583857481L;
                    continue block98;
                }
            }
            break;
        }
        v30 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl141
        block99: while (true) {
            v30 = v31 / (-6928015958318110878L ^ -3892266280460652926L);
lbl141:
            // 2 sources

            switch ((int)v30) {
                case -1516547663: {
                    v31 = 8088958913735615668L ^ -4632835621171938686L;
                    continue block99;
                }
                case 141306124: {
                    break block99;
                }
                case 1474645493: {
                    v31 = 8677195291849681361L ^ -1396031726377973040L;
                    continue block99;
                }
            }
            break;
        }
        v32 = new StringBuilder();
        var13_1 = new byte[-1948171616 ^ -1948171606];
        v33 = -467331024 ^ -467331042;
        var13_1[1761700656 ^ 1761700665] = v33;
        var13_1[-1972098276 ^ -1972098284] = -122670463 ^ -122670364;
        v34 = -444087437 ^ -444087549;
        var13_1[1157662526 ^ 1157662521] = v34;
        var13_1[1677289499 ^ 1677289503] = -1931265905 ^ -1931265886;
        var13_1[-384178767 ^ -384178764] = -531109593 ^ -531109549;
        v35 = -277632463 ^ -277632440;
        var13_1[1599294951 ^ 1599294945] = v35;
        v36 = 783557459 ^ 783557428;
        var13_1[1687055847 ^ 1687055847] = v36;
        v37 = 703677292 ^ 703677295;
        var13_1[v37] = -1928537151 ^ -1928537163;
        var13_1[-265229073 ^ -265229075] = 1153386566 ^ 1153386528;
        var13_1[546741416 ^ 546741417] = 1409327734 ^ 1409327647;
        v38 = new String(var13_1, "UTF-8");
        while (true) {
            block143: {
                if ((v39 = (cfr_temp_4 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-6070251967125680847L ^ 4137075701762888530L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v39 != (2058777444 ^ 2058777445)) break block143;
                v40 = v32.append(v38).append((String)CRACKME_ed43c8a3_a509_4057_93a0_8057686b973bc6175790);
                var13_1 = new byte[1432585866 ^ 1432585867];
                var13_1[-1425015246 ^ -1425015246] = 1367364163 ^ 1367364205;
                v41 = new String(var13_1, "UTF-8");
                v42 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl188
            }
            v39 = -739127103 ^ 2117903466;
        }
        block101: while (true) {
            v42 = v43 / (-61783248915160702L ^ 6108590212267064399L);
lbl188:
            // 2 sources

            switch ((int)v42) {
                case 141306124: {
                    break block101;
                }
                case 185022229: {
                    v43 = 529032999074263120L ^ 5851441657369488354L;
                    continue block101;
                }
                case 2111133421: {
                    v43 = -7131513112161691432L - -580245629486520748L;
                    continue block101;
                }
            }
            break;
        }
        v44 = v40.append(v41);
        var13_1 = new byte[299826776 ^ 299826777];
        v45 = -802283981 ^ -802283981;
        var13_1[v45] = 1940830228 ^ 1940830266;
        v46 = new String(var13_1, "UTF-8");
        v47 = 141135258 ^ 141135257;
        var13_1 = new byte[v47];
        var13_1[33434386 ^ 33434386] = 616946059 ^ 616946165;
        v48 = -2043560133 ^ -2043560134;
        v49 = -1878921526 ^ -1878921479;
        var13_1[v48] = v49;
        v50 = 671103708 ^ 671103710;
        var13_1[v50] = 1813911861 ^ 1813911883;
        v51 = new String(var13_1, "UTF-8");
        v52 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl218
        block102: while (true) {
            v52 = v53 / (-1650643216204964203L - 2636734979566881028L);
lbl218:
            // 2 sources

            switch ((int)v52) {
                case 141306124: {
                    break block102;
                }
                case 294514364: {
                    v53 = -876668810898156176L - -1541353421516797125L;
                    continue block102;
                }
                case 1800691011: {
                    v53 = 5076861078581887469L - -2710854073518921745L;
                    continue block102;
                }
            }
            break;
        }
        v54 = CRACKME_ed43c8a3_a509_4057_93a0_8057686b973b1cd2014b.replace(v46, v51);
        v55 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl232
        block103: while (true) {
            v55 = v56 / (-5918489411119469141L ^ 7447209696153123893L);
lbl232:
            // 2 sources

            switch ((int)v55) {
                case -170760933: {
                    v56 = 7606412848799358432L >>> "\u0000\u0000".length();
                    continue block103;
                }
                case 141306124: {
                    break block103;
                }
            }
            break;
        }
        CRACKME_ed43c8a3_a509_4057_93a0_8057686b973b1dd4d6d2 = \u017b\u017c\u0107m.7\u015aCz.getConfigurationSection(v44.append(v54).toString());
        v57 = -338791991 ^ -2004527366;
        if (CRACKME_ed43c8a3_a509_4057_93a0_8057686b973b1dd4d6d2 == null) {
            return null;
        }
        v58 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl257
        block104: while (true) {
            v59 = -6340404383779125921L ^ 9093814585471322810L;
            v58 = v60 / v59;
lbl257:
            // 2 sources

            switch ((int)v58) {
                case -782423175: {
                    v60 = 8336448360980703363L - 7293974601482906330L;
                    continue block104;
                }
                case 141306124: {
                    break block104;
                }
                case 1254206900: {
                    v60 = 1872742965606604680L - -4381709708531273940L;
                    continue block104;
                }
            }
            break;
        }
        387970807 ^ -1798643736;
        v61 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl275
        block105: while (true) {
            v62 = 7491590156065043083L - 3912818753971424715L;
            v61 = v63 / v62;
lbl275:
            // 2 sources

            switch ((int)v61) {
                case -1976129322: {
                    v63 = -8003639005698932769L ^ -8036310632676485563L;
                    continue block105;
                }
                case -1343178435: {
                    v63 = 1720762548455508406L ^ -606468191704672396L;
                    continue block105;
                }
                case 141306124: {
                    break block105;
                }
                case 1516587927: {
                    v63 = 1153789844132278549L - 7914421067555835213L;
                    continue block105;
                }
            }
            break;
        }
        var3_4 = new HashMap<K, V>();
        while (true) {
            if ((v64 = (cfr_temp_5 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (8633269258092366428L ^ -768178706628402481L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            v65 = -1101158850 ^ -1101158849;
            if (v64 == v65) break;
            v64 = 205897872 ^ -1275804627;
        }
        v66 = CRACKME_ed43c8a3_a509_4057_93a0_8057686b973b1dd4d6d2.getKeys((boolean)(-579101119 ^ -579101119));
        -866538583 - -1920446094;
        while (true) {
            v67 = -933240372454871496L ^ -84388356197942447L;
            cfr_temp_6 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - v67;
            v68 = cfr_temp_6 == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1);
            if (v68 == false) continue;
            v69 = 362016836 ^ 362016837;
            if (v68 == v69) break;
            v68 = -516075358 ^ -1469533728;
        }
        var4_5 = v66.iterator();
        block108: while (true) {
            if ((v70 = (cfr_temp_7 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-3071286987228804937L ^ 7910969192588939261L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
            v71 = 597612298 ^ 597612299;
            if (v70 == v71) {
                if (!var4_5.hasNext()) break;
            } else {
                v70 = 1035445992 ^ 1895684382;
                continue;
            }
            var5_6 = (String)var4_5.next();
            CRACKME_ed43c8a3_a509_4057_93a0_8057686b973b44c0e8c9 = CRACKME_ed43c8a3_a509_4057_93a0_8057686b973b047fc839.toLowerCase();
            var7_9 = CRACKME_ed43c8a3_a509_4057_93a0_8057686b973b1dd4d6d2.getInt((String)CRACKME_ed43c8a3_a509_4057_93a0_8057686b973b047fc839);
            v72 = 848244088 ^ 1318446480;
            v73 = (int)CRACKME_ed43c8a3_a509_4057_93a0_8057686b973bd5a1c3f8;
            v74 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
            if (true) ** GOTO lbl352
            block109: while (true) {
                v75 = 6946337959020695585L ^ -2613889950857018205L;
                v74 = v76 / v75;
lbl352:
                // 2 sources

                switch ((int)v74) {
                    case -1428022674: {
                        v76 = 5575712246713122181L ^ 4755744049343487514L;
                        continue block109;
                    }
                    case 141306124: {
                        break block109;
                    }
                    case 310186655: {
                        v76 = 2630789890450002244L - 5540069219647681194L;
                        continue block109;
                    }
                    case 683044185: {
                        v76 = -7620523549429516885L ^ 9103834637917216729L;
                        continue block109;
                    }
                }
                break;
            }
            v77 = (BiFunction<Integer, Integer, Integer>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;, sum(int int ), (Ljava/lang/Integer;Ljava/lang/Integer;)Ljava/lang/Integer;)();
            while (true) {
                if ((v78 = (cfr_temp_8 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-7080880917173314823L ^ 1830342037536366844L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                if (v78 == (-1562205402 ^ -1562205401)) {
                    CRACKME_ed43c8a3_a509_4057_93a0_8057686b973b062f2818.merge(CRACKME_ed43c8a3_a509_4057_93a0_8057686b973b44c0e8c9, v73, v77);
                    continue block108;
                }
                v78 = -1332481333 ^ 1084045504;
            }
            break;
        }
        987150538 ^ -282565455;
        var4_5 = null;
        v79 = -1956117006 - -1072225106;
        v80 = -2105604695 ^ -2105604695;
        CRACKME_ed43c8a3_a509_4057_93a0_8057686b973b047fc839 = v80;
        v81 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        block111: while (true) {
            switch ((int)v81) {
                case 141306124: {
                    break block111;
                }
                case 1095235397: {
                    v81 = (5544584851225613904L ^ 2080533588205317991L) / (-9168873583558982929L ^ -3073418754612562911L);
                    continue block111;
                }
            }
            break;
        }
        v82 = CRACKME_ed43c8a3_a509_4057_93a0_8057686b973b062f2818.entrySet();
        while (true) {
            v83 = -7387192424185662286L - -8714662584511303382L;
            cfr_temp_9 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - v83;
            v84 = cfr_temp_9 == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1);
            if (v84 == false) continue;
            if (v84 == (-1350329324 ^ -1350329323)) break;
            v84 = 1963781384 - 217207351;
        }
        var6_8 = v82.iterator();
        block113: while (true) {
            block140: {
                v85 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl421
                block114: while (true) {
                    v85 = v86 / (7696509746129458303L ^ -211403348846005861L);
lbl421:
                    // 2 sources

                    switch ((int)v85) {
                        case -875915710: {
                            v86 = -3258235229457825598L ^ -2409744705071737877L;
                            continue block114;
                        }
                        case -264479683: {
                            v86 = 5440773375663302942L ^ -237011310047025359L;
                            continue block114;
                        }
                        case -148930654: {
                            v86 = 3863479938080254489L ^ 8315388098026339676L;
                            continue block114;
                        }
                        case 141306124: {
                            break block114;
                        }
                    }
                    break;
                }
                if (!var6_8.hasNext()) {
                    if (CRACKME_ed43c8a3_a509_4057_93a0_8057686b973b6d20e536 == null) {
                        return null;
                    }
                    -529574513 - 760980771;
                    v87 = 1731783635 - -291307601;
                    CRACKME_ed43c8a3_a509_4057_93a0_8057686b973b6d20e536.N\u0142d\u0105 = CRACKME_ed43c8a3_a509_4057_93a0_8057686b973b9afd8e23;
                    return CRACKME_ed43c8a3_a509_4057_93a0_8057686b973b6d20e536;
                }
                1887338249 ^ 1290466453;
                while (true) {
                    v88 = -9024567523690876628L - -585022660740286283L;
                    cfr_temp_10 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - v88;
                    v89 = cfr_temp_10 == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1);
                    if (v89 == false) continue;
                    if (v89 == (529621045 ^ 529621044)) break;
                    v89 = -1521846761 ^ 1161042694;
                }
                CRACKME_ed43c8a3_a509_4057_93a0_8057686b973be846a43c = var6_8.next();
                v90 = -2128552485 ^ -235294822;
                -1147379728 >>> "\u0000\u0000".length();
                while (true) {
                    if ((v91 = (cfr_temp_11 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-2604287720423859276L - 7605534192995306062L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
                    if (v91 == (-2067045158 ^ 2067045157)) break;
                    v91 = -1190021230 ^ 1993013570;
                }
                -660660168 - -1130367068;
                var8_11 = (String)CRACKME_ed43c8a3_a509_4057_93a0_8057686b973be846a43c.getKey();
                var9_12 = null;
                while (true) {
                    block144: {
                        v92 = 451867814432782439L ^ 5201176996713762758L;
                        cfr_temp_12 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - v92;
                        v93 = cfr_temp_12 == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1);
                        if (v93 == false) continue;
                        v94 = -786598141 ^ -786598142;
                        if (v93 != v94) break block144;
                        v95 = 8\u0105ja.\u0142Dzn.values();
                        v96 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                        if (true) ** GOTO lbl511
                    }
                    v93 = 1435927070 - -1951317963;
                }
                block118: while (true) {
                    v96 = v97 / (6028249733955309496L >>> "\u0000\u0000".length());
lbl511:
                    // 2 sources

                    switch ((int)v96) {
                        case -1545639536: {
                            v97 = 6762847779839145955L - -4531426019938980460L;
                            continue block118;
                        }
                        case -542418696: {
                            v97 = -2626758472710771425L - 3857630041721957947L;
                            continue block118;
                        }
                        case 141306124: {
                            break block118;
                        }
                        case 1125208409: {
                            v97 = 3035906191552418987L ^ -5549497494339692283L;
                            continue block118;
                        }
                    }
                    break;
                }
                var10_13 = v95.iterator();
                do {
                    v98 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                    if (true) ** GOTO lbl533
                    block120: while (true) {
                        v98 = (1205417240026450258L ^ 6475824171312595402L) / v99;
lbl533:
                        // 2 sources

                        switch ((int)v98) {
                            case 141306124: {
                                break block120;
                            }
                            case 1714547471: {
                                v99 = -7439286012521352046L ^ 2734778276431147946L;
                                continue block120;
                            }
                        }
                        break;
                    }
                    if (!var10_13.hasNext()) break block140;
                    while (true) {
                        if ((v100 = (cfr_temp_13 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-6282639763390464117L - -8912671217754107267L)) == 0L ? 0 : (cfr_temp_13 < 0L ? -1 : 1)) == false) continue;
                        if (v100 == (1263915660 ^ 1263915661)) break;
                        v100 = 1175726814 ^ 1060483757;
                    }
                    398043714 ^ -2132639971;
                    var11_15 = var10_13.next();
                    v101 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                    block122: while (true) {
                        switch ((int)v101) {
                            case -510658506: {
                                v101 = (-5641611816290460526L - 8401828690327866188L) / (-8594340801458770299L ^ 6085453971863083862L);
                                continue block122;
                            }
                            case 141306124: {
                                break block122;
                            }
                        }
                        break;
                    }
                    v102 = CRACKME_ed43c8a3_a509_4057_93a0_8057686b973b110ed6e3.\u0142W\u015aq;
                    421235236 ^ -645469316;
                    v103 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                    if (true) ** GOTO lbl578
                    block123: while (true) {
                        v103 = v104 / (-8230844949152433108L - 7802942920445679575L);
lbl578:
                        // 2 sources

                        switch ((int)v103) {
                            case 141306124: {
                                break block123;
                            }
                            case 383832867: {
                                v104 = -8684270763971591850L - -3512221528713645311L;
                                continue block123;
                            }
                            case 989706931: {
                                v104 = -8899271366402609182L ^ 315497589455246768L;
                                continue block123;
                            }
                        }
                        break;
                    }
                    v105 = v102.toLowerCase();
                    v106 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                    if (true) ** GOTO lbl592
                    block124: while (true) {
                        v106 = v107 / (8318488901659418224L - 8572538490765055935L);
lbl592:
                        // 2 sources

                        switch ((int)v106) {
                            case -1857148591: {
                                v107 = 3971957022958701256L >>> "\u0000\u0000".length();
                                continue block124;
                            }
                            case -915685773: {
                                v107 = -5158483108376064615L - 7314809838385721402L;
                                continue block124;
                            }
                            case 141306124: {
                                break block124;
                            }
                            case 2125495173: {
                                v107 = -9194435931689378823L - 2765711493920068535L;
                                continue block124;
                            }
                        }
                        break;
                    }
                    v108 = -51976361 ^ 831636700;
                    -1350808938 - 1655797635;
                } while (!v105.equals(CRACKME_ed43c8a3_a509_4057_93a0_8057686b973ba631a38d));
                -1633806006 ^ 1237759432;
                CRACKME_ed43c8a3_a509_4057_93a0_8057686b973b1d035385 = CRACKME_ed43c8a3_a509_4057_93a0_8057686b973b110ed6e3;
                v109 = 845637120 - -1432448065;
            }
            64988639 ^ -1026731132;
            if (CRACKME_ed43c8a3_a509_4057_93a0_8057686b973b1d035385 == null) {
                continue;
            }
            -1098091775 ^ -608081258;
            CRACKME_ed43c8a3_a509_4057_93a0_8057686b973ba5769e27 = (Integer)CRACKME_ed43c8a3_a509_4057_93a0_8057686b973be846a43c.getValue();
            v110 = 786918637 ^ 1178680267;
            if (CRACKME_ed43c8a3_a509_4057_93a0_8057686b973b6d20e536 != null) {
                while (true) {
                    if ((v111 = (cfr_temp_14 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (-8052770684240110501L ^ 4640201558638863077L)) == 0L ? 0 : (cfr_temp_14 < 0L ? -1 : 1)) == false) continue;
                    v112 = 1168938712 ^ 1168938713;
                    if (v111 == v112) {
                        if (CRACKME_ed43c8a3_a509_4057_93a0_8057686b973b1d035385.kSX0 <= CRACKME_ed43c8a3_a509_4057_93a0_8057686b973b6d20e536.kSX0) continue block113;
                        break;
                    }
                    v111 = 289067797 ^ 1013443094;
                }
            }
            CRACKME_ed43c8a3_a509_4057_93a0_8057686b973b6d20e536 = CRACKME_ed43c8a3_a509_4057_93a0_8057686b973b1d035385;
            147371644 ^ 1493869676;
            CRACKME_ed43c8a3_a509_4057_93a0_8057686b973b9afd8e23 = CRACKME_ed43c8a3_a509_4057_93a0_8057686b973ba5769e27;
        }
    }

    /*
     * Unable to fully structure code
     */
    public static String kxxRWCLxZpwgB8Cu(int var0) {
        if (8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == 3243948865409267868L - -44350985633011198L) {
            if ((1159617683 - 1498072722 ^ (1335125289 ^ 812358358)) != 0) {
                1149888343 ^ 1149888342;
            }
        } else {
            -1359846950 ^ -1359846950;
        }
        while (true) {
            if ((v0 = (cfr_temp_0 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (2789101318000605030L ^ -8420446383634006254L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (-63291405181080156L == -63291405181080155L ? 1315570312 : -2115413080 ^ -2115413079)) break;
            v0 = -701127799 - 1509954319;
        }
        8\u0105ja.zsjN3N7fF6D1WUzb();
        v1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        block20: while (true) {
            switch ((int)v1) {
                case 141306124: {
                    break block20;
                }
                case 1989763027: {
                    v1 = (-1259334310312933999L ^ 9130681380453130042L) / (-4424836081356165087L ^ 3127254233010833887L);
                    continue block20;
                }
            }
            break;
        }
        v2 = CRACKME_8c82a06b_9237_471e_8751_8522637ff61147c5ad10;
        while (true) {
            block28: {
                if ((v3 = (cfr_temp_1 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c - (6090177479427715622L ^ 3808446104450425261L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v3 != -1735932432 - -1735932431) break block28;
                v4 = 559272044 ^ 559272044;
                v5 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
                if (true) ** GOTO lbl38
            }
            v3 = 1295742801 ^ 1824626455;
        }
        block22: while (true) {
            v5 = v6 / (3882762653644690858L - 376472543193804272L);
lbl38:
            // 2 sources

            switch ((int)v5) {
                case 141306124: {
                    break block22;
                }
                case 190210990: {
                    v6 = -6580766175038154442L - 7481149705864487598L;
                    continue block22;
                }
                case 1536664129: {
                    v6 = 8719364094056531505L - -8195614001774824964L;
                    continue block22;
                }
            }
            break;
        }
        CRACKME_8c82a06b_9237_471e_8751_8522637ff6115f446322 = 8\u0105ja.t9\u0142U.getOrDefault(v2, v4);
        -82591894 ^ -1393799552;
        v7 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        block23: while (true) {
            switch ((int)v7) {
                case 141306124: {
                    break block23;
                }
                case 1899372427: {
                    v7 = (1806382126994781381L ^ -1955634339884892409L) / (-8170072725319523140L - -2248873211224523139L);
                    continue block23;
                }
            }
            break;
        }
        v8 = CRACKME_8c82a06b_9237_471e_8751_8522637ff6115f446322;
        v9 = 8\u0105ja.CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c;
        if (true) ** GOTO lbl67
        block24: while (true) {
            v9 = v10 / (7973609297677011247L ^ 3186327145968640199L);
lbl67:
            // 2 sources

            switch ((int)v9) {
                case 141306124: {
                    break block24;
                }
                case 696778551: {
                    v10 = -2277010549692107640L - -1684539276336352105L;
                    continue block24;
                }
                case 1376656874: {
                    v10 = -166694680155510879L ^ 1506895244036592362L;
                    continue block24;
                }
                case 1536817451: {
                    v10 = 5968236746141792713L ^ 127573283251566369L;
                    continue block24;
                }
            }
            break;
        }
        return 24XS.h_4UABwP3uGOOmhd((int)v8);
    }

    static /* synthetic */ void 3UXvh3CMhqrM4kD2() {
        if (CRACKME_1d87f682_df2a_4e9f_ba82_f7228f310c2a_3177528c == (0x2E1C266744FB205CL ^ 0xA421D95EA5CECE79L)) {
            if (((-234140380286429106L == -234140380286429105L ? -1201957182 : 0xBA3F426B ^ 0x3E278DD6) ^ -328152829 - 1819330820) != 0) {
                int cfr_ignored_0 = 0x38089B42 ^ 0x38089B43;
            }
        } else {
            int cfr_ignored_1 = 0x4DCB7756 ^ 0x4DCB7756;
        }
        8\u0105ja.zsjN3N7fF6D1WUzb();
    }
}
