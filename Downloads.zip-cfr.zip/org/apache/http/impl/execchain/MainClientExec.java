/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.logging.Log
 *  org.apache.commons.logging.LogFactory
 *  org.apache.http.ConnectionReuseStrategy
 *  org.apache.http.HttpClientConnection
 *  org.apache.http.HttpEntity
 *  org.apache.http.HttpEntityEnclosingRequest
 *  org.apache.http.HttpException
 *  org.apache.http.HttpHost
 *  org.apache.http.HttpRequest
 *  org.apache.http.HttpRequestInterceptor
 *  org.apache.http.HttpResponse
 *  org.apache.http.annotation.Contract
 *  org.apache.http.annotation.ThreadingBehavior
 *  org.apache.http.auth.AuthProtocolState
 *  org.apache.http.auth.AuthState
 *  org.apache.http.client.AuthenticationStrategy
 *  org.apache.http.client.NonRepeatableRequestException
 *  org.apache.http.client.UserTokenHandler
 *  org.apache.http.client.config.RequestConfig
 *  org.apache.http.client.methods.CloseableHttpResponse
 *  org.apache.http.client.methods.HttpExecutionAware
 *  org.apache.http.client.methods.HttpRequestWrapper
 *  org.apache.http.client.protocol.HttpClientContext
 *  org.apache.http.concurrent.Cancellable
 *  org.apache.http.conn.ConnectionKeepAliveStrategy
 *  org.apache.http.conn.ConnectionRequest
 *  org.apache.http.conn.HttpClientConnectionManager
 *  org.apache.http.conn.routing.BasicRouteDirector
 *  org.apache.http.conn.routing.HttpRoute
 *  org.apache.http.conn.routing.HttpRouteDirector
 *  org.apache.http.conn.routing.RouteInfo
 *  org.apache.http.conn.routing.RouteTracker
 *  org.apache.http.entity.BufferedHttpEntity
 *  org.apache.http.impl.auth.HttpAuthenticator
 *  org.apache.http.impl.conn.ConnectionShutdownException
 *  org.apache.http.impl.execchain.ClientExecChain
 *  org.apache.http.impl.execchain.ConnectionHolder
 *  org.apache.http.impl.execchain.HttpResponseProxy
 *  org.apache.http.impl.execchain.RequestAbortedException
 *  org.apache.http.impl.execchain.RequestEntityProxy
 *  org.apache.http.impl.execchain.TunnelRefusedException
 *  org.apache.http.message.BasicHttpRequest
 *  org.apache.http.protocol.HttpContext
 *  org.apache.http.protocol.HttpProcessor
 *  org.apache.http.protocol.HttpRequestExecutor
 *  org.apache.http.protocol.ImmutableHttpProcessor
 *  org.apache.http.protocol.RequestTargetHost
 *  org.apache.http.util.Args
 *  org.apache.http.util.EntityUtils
 */
package org.apache.http.impl.execchain;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.ConnectionReuseStrategy;
import org.apache.http.HttpClientConnection;
import org.apache.http.HttpEntity;
import org.apache.http.HttpEntityEnclosingRequest;
import org.apache.http.HttpException;
import org.apache.http.HttpHost;
import org.apache.http.HttpRequest;
import org.apache.http.HttpRequestInterceptor;
import org.apache.http.HttpResponse;
import org.apache.http.annotation.Contract;
import org.apache.http.annotation.ThreadingBehavior;
import org.apache.http.auth.AuthProtocolState;
import org.apache.http.auth.AuthState;
import org.apache.http.client.AuthenticationStrategy;
import org.apache.http.client.NonRepeatableRequestException;
import org.apache.http.client.UserTokenHandler;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpExecutionAware;
import org.apache.http.client.methods.HttpRequestWrapper;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.concurrent.Cancellable;
import org.apache.http.conn.ConnectionKeepAliveStrategy;
import org.apache.http.conn.ConnectionRequest;
import org.apache.http.conn.HttpClientConnectionManager;
import org.apache.http.conn.routing.BasicRouteDirector;
import org.apache.http.conn.routing.HttpRoute;
import org.apache.http.conn.routing.HttpRouteDirector;
import org.apache.http.conn.routing.RouteInfo;
import org.apache.http.conn.routing.RouteTracker;
import org.apache.http.entity.BufferedHttpEntity;
import org.apache.http.impl.auth.HttpAuthenticator;
import org.apache.http.impl.conn.ConnectionShutdownException;
import org.apache.http.impl.execchain.ClientExecChain;
import org.apache.http.impl.execchain.ConnectionHolder;
import org.apache.http.impl.execchain.HttpResponseProxy;
import org.apache.http.impl.execchain.RequestAbortedException;
import org.apache.http.impl.execchain.RequestEntityProxy;
import org.apache.http.impl.execchain.TunnelRefusedException;
import org.apache.http.message.BasicHttpRequest;
import org.apache.http.protocol.HttpContext;
import org.apache.http.protocol.HttpProcessor;
import org.apache.http.protocol.HttpRequestExecutor;
import org.apache.http.protocol.ImmutableHttpProcessor;
import org.apache.http.protocol.RequestTargetHost;
import org.apache.http.util.Args;
import org.apache.http.util.EntityUtils;

@Contract(threading=ThreadingBehavior.IMMUTABLE_CONDITIONAL)
public class MainClientExec
implements ClientExecChain {
    private final HttpAuthenticator authenticator;
    private final HttpRouteDirector routeDirector;
    private final HttpRequestExecutor requestExecutor;
    private final ConnectionReuseStrategy reuseStrategy;
    private final HttpClientConnectionManager connManager;
    private final HttpProcessor proxyHttpProcessor;
    private final Log log = LogFactory.getLog(this.getClass());
    private final AuthenticationStrategy targetAuthStrategy;
    private final UserTokenHandler userTokenHandler;
    private final AuthenticationStrategy proxyAuthStrategy;
    private final ConnectionKeepAliveStrategy keepAliveStrategy;

    public MainClientExec(HttpRequestExecutor requestExecutor, HttpClientConnectionManager connManager, ConnectionReuseStrategy reuseStrategy, ConnectionKeepAliveStrategy keepAliveStrategy, AuthenticationStrategy targetAuthStrategy, AuthenticationStrategy proxyAuthStrategy, UserTokenHandler userTokenHandler) {
        this(requestExecutor, connManager, reuseStrategy, keepAliveStrategy, (HttpProcessor)new ImmutableHttpProcessor(new HttpRequestInterceptor[]{new RequestTargetHost()}), targetAuthStrategy, proxyAuthStrategy, userTokenHandler);
    }

    private boolean createTunnelToTarget(AuthState proxyAuthState, HttpClientConnection managedConn, HttpRoute route, HttpRequest request, HttpClientContext context) throws IOException, HttpException {
        HttpEntity entity;
        int status;
        RequestConfig config = context.getRequestConfig();
        int timeout = config.getConnectTimeout();
        HttpHost target = route.getTargetHost();
        HttpHost proxy = route.getProxyHost();
        HttpResponse response = null;
        String authority = target.toHostString();
        BasicHttpRequest connect = new BasicHttpRequest("CONNECT", authority, request.getProtocolVersion());
        this.requestExecutor.preProcess((HttpRequest)connect, this.proxyHttpProcessor, (HttpContext)context);
        while (response == null) {
            if (!managedConn.isOpen()) {
                this.connManager.connect(managedConn, route, timeout > 0 ? timeout : 0, (HttpContext)context);
            }
            connect.removeHeaders("Proxy-Authorization");
            this.authenticator.generateAuthResponse((HttpRequest)connect, proxyAuthState, (HttpContext)context);
            response = this.requestExecutor.execute((HttpRequest)connect, managedConn, (HttpContext)context);
            this.requestExecutor.postProcess(response, this.proxyHttpProcessor, (HttpContext)context);
            status = response.getStatusLine().getStatusCode();
            if (status < 200) {
                throw new HttpException("Unexpected response to CONNECT request: " + response.getStatusLine());
            }
            if (!config.isAuthenticationEnabled() || !this.authenticator.isAuthenticationRequested(proxy, response, this.proxyAuthStrategy, proxyAuthState, (HttpContext)context) || !this.authenticator.handleAuthChallenge(proxy, response, this.proxyAuthStrategy, proxyAuthState, (HttpContext)context)) continue;
            if (this.reuseStrategy.keepAlive(response, (HttpContext)context)) {
                this.log.debug((Object)"Connection kept alive");
                entity = response.getEntity();
                EntityUtils.consume((HttpEntity)entity);
            } else {
                managedConn.close();
            }
            response = null;
        }
        status = response.getStatusLine().getStatusCode();
        if (status <= 299) return false;
        entity = response.getEntity();
        if (entity != null) {
            response.setEntity((HttpEntity)new BufferedHttpEntity(entity));
        }
        managedConn.close();
        throw new TunnelRefusedException("CONNECT refused by proxy: " + response.getStatusLine(), response);
    }

    void establishRoute(AuthState proxyAuthState, HttpClientConnection managedConn, HttpRoute route, HttpRequest request, HttpClientContext context) throws HttpException, IOException {
        int step;
        RequestConfig config = context.getRequestConfig();
        int timeout = config.getConnectTimeout();
        RouteTracker tracker = new RouteTracker(route);
        do {
            HttpRoute fact = tracker.toRoute();
            step = this.routeDirector.nextStep((RouteInfo)route, (RouteInfo)fact);
            switch (step) {
                case 1: {
                    this.connManager.connect(managedConn, route, timeout > 0 ? timeout : 0, (HttpContext)context);
                    tracker.connectTarget(route.isSecure());
                    break;
                }
                case 2: {
                    this.connManager.connect(managedConn, route, timeout > 0 ? timeout : 0, (HttpContext)context);
                    HttpHost proxy = route.getProxyHost();
                    tracker.connectProxy(proxy, route.isSecure() && !route.isTunnelled());
                    break;
                }
                case 3: {
                    boolean secure = this.createTunnelToTarget(proxyAuthState, managedConn, route, request, context);
                    this.log.debug((Object)"Tunnel to target created.");
                    tracker.tunnelTarget(secure);
                    break;
                }
                case 4: {
                    int hop = fact.getHopCount() - 1;
                    boolean secure = this.createTunnelToProxy(route, hop, context);
                    this.log.debug((Object)"Tunnel to proxy created.");
                    tracker.tunnelProxy(route.getHopTarget(hop), secure);
                    break;
                }
                case 5: {
                    this.connManager.upgrade(managedConn, route, (HttpContext)context);
                    tracker.layerProtocol(route.isSecure());
                    break;
                }
                case -1: {
                    throw new HttpException("Unable to establish route: planned = " + route + "; current = " + fact);
                }
                case 0: {
                    this.connManager.routeComplete(managedConn, route, (HttpContext)context);
                    break;
                }
                default: {
                    throw new IllegalStateException("Unknown step indicator " + step + " from RouteDirector.");
                }
            }
        } while (step > 0);
    }

    public MainClientExec(HttpRequestExecutor requestExecutor, HttpClientConnectionManager connManager, ConnectionReuseStrategy reuseStrategy, ConnectionKeepAliveStrategy keepAliveStrategy, HttpProcessor proxyHttpProcessor, AuthenticationStrategy targetAuthStrategy, AuthenticationStrategy proxyAuthStrategy, UserTokenHandler userTokenHandler) {
        Args.notNull((Object)requestExecutor, (String)"HTTP request executor");
        Args.notNull((Object)connManager, (String)"Client connection manager");
        Args.notNull((Object)reuseStrategy, (String)"Connection reuse strategy");
        Args.notNull((Object)keepAliveStrategy, (String)"Connection keep alive strategy");
        Args.notNull((Object)proxyHttpProcessor, (String)"Proxy HTTP processor");
        Args.notNull((Object)targetAuthStrategy, (String)"Target authentication strategy");
        Args.notNull((Object)proxyAuthStrategy, (String)"Proxy authentication strategy");
        Args.notNull((Object)userTokenHandler, (String)"User token handler");
        this.authenticator = new HttpAuthenticator();
        this.routeDirector = new BasicRouteDirector();
        this.requestExecutor = requestExecutor;
        this.connManager = connManager;
        this.reuseStrategy = reuseStrategy;
        this.keepAliveStrategy = keepAliveStrategy;
        this.proxyHttpProcessor = proxyHttpProcessor;
        this.targetAuthStrategy = targetAuthStrategy;
        this.proxyAuthStrategy = proxyAuthStrategy;
        this.userTokenHandler = userTokenHandler;
    }

    public CloseableHttpResponse execute(HttpRoute route, HttpRequestWrapper request, HttpClientContext context, HttpExecutionAware execAware) throws IOException, HttpException {
        HttpClientConnection managedConn;
        AuthState proxyAuthState;
        Args.notNull((Object)route, (String)"HTTP route");
        Args.notNull((Object)request, (String)"HTTP request");
        Args.notNull((Object)context, (String)"HTTP context");
        AuthState targetAuthState = context.getTargetAuthState();
        if (targetAuthState == null) {
            targetAuthState = new AuthState();
            context.setAttribute("http.auth.target-scope", (Object)targetAuthState);
        }
        if ((proxyAuthState = context.getProxyAuthState()) == null) {
            proxyAuthState = new AuthState();
            context.setAttribute("http.auth.proxy-scope", (Object)proxyAuthState);
        }
        if (request instanceof HttpEntityEnclosingRequest) {
            RequestEntityProxy.enhance((HttpEntityEnclosingRequest)((HttpEntityEnclosingRequest)request));
        }
        Object userToken = context.getUserToken();
        ConnectionRequest connRequest = this.connManager.requestConnection(route, userToken);
        if (execAware != null) {
            if (execAware.isAborted()) {
                connRequest.cancel();
                throw new RequestAbortedException("Request aborted");
            }
            execAware.setCancellable((Cancellable)connRequest);
        }
        RequestConfig config = context.getRequestConfig();
        try {
            int timeout = config.getConnectionRequestTimeout();
            managedConn = connRequest.get(timeout > 0 ? (long)timeout : 0L, TimeUnit.MILLISECONDS);
        }
        catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
            throw new RequestAbortedException("Request aborted", (Throwable)interrupted);
        }
        catch (ExecutionException ex) {
            Throwable cause = ex.getCause();
            if (cause != null) throw new RequestAbortedException("Request execution failed", cause);
            cause = ex;
            throw new RequestAbortedException("Request execution failed", cause);
        }
        context.setAttribute("http.connection", (Object)managedConn);
        if (config.isStaleConnectionCheckEnabled() && managedConn.isOpen()) {
            this.log.debug((Object)"Stale connection check");
            if (managedConn.isStale()) {
                this.log.debug((Object)"Stale connection detected");
                managedConn.close();
            }
        }
        ConnectionHolder connHolder = new ConnectionHolder(this.log, this.connManager, managedConn);
        try {
            HttpEntity entity;
            HttpResponse response;
            if (execAware != null) {
                execAware.setCancellable((Cancellable)connHolder);
            }
            int execCount = 1;
            while (true) {
                int timeout;
                if (execCount > 1 && !RequestEntityProxy.isRepeatable((HttpRequest)request)) {
                    throw new NonRepeatableRequestException("Cannot retry request with a non-repeatable request entity.");
                }
                if (execAware != null && execAware.isAborted()) {
                    throw new RequestAbortedException("Request aborted");
                }
                if (!managedConn.isOpen()) {
                    this.log.debug((Object)("Opening connection " + route));
                    try {
                        this.establishRoute(proxyAuthState, managedConn, route, (HttpRequest)request, context);
                    }
                    catch (TunnelRefusedException ex) {
                        if (this.log.isDebugEnabled()) {
                            this.log.debug((Object)ex.getMessage());
                        }
                        response = ex.getResponse();
                        break;
                    }
                }
                if ((timeout = config.getSocketTimeout()) >= 0) {
                    managedConn.setSocketTimeout(timeout);
                }
                if (execAware != null && execAware.isAborted()) {
                    throw new RequestAbortedException("Request aborted");
                }
                if (this.log.isDebugEnabled()) {
                    this.log.debug((Object)("Executing request " + request.getRequestLine()));
                }
                if (!request.containsHeader("Authorization")) {
                    if (this.log.isDebugEnabled()) {
                        this.log.debug((Object)("Target auth state: " + targetAuthState.getState()));
                    }
                    this.authenticator.generateAuthResponse((HttpRequest)request, targetAuthState, (HttpContext)context);
                }
                if (!request.containsHeader("Proxy-Authorization") && !route.isTunnelled()) {
                    if (this.log.isDebugEnabled()) {
                        this.log.debug((Object)("Proxy auth state: " + proxyAuthState.getState()));
                    }
                    this.authenticator.generateAuthResponse((HttpRequest)request, proxyAuthState, (HttpContext)context);
                }
                context.setAttribute("http.request", (Object)request);
                response = this.requestExecutor.execute((HttpRequest)request, managedConn, (HttpContext)context);
                if (this.reuseStrategy.keepAlive(response, (HttpContext)context)) {
                    long duration = this.keepAliveStrategy.getKeepAliveDuration(response, (HttpContext)context);
                    if (this.log.isDebugEnabled()) {
                        String s = duration > 0L ? "for " + duration + " " + (Object)((Object)TimeUnit.MILLISECONDS) : "indefinitely";
                        this.log.debug((Object)("Connection can be kept alive " + s));
                    }
                    connHolder.setValidFor(duration, TimeUnit.MILLISECONDS);
                    connHolder.markReusable();
                } else {
                    connHolder.markNonReusable();
                }
                if (!this.needAuthentication(targetAuthState, proxyAuthState, route, response, context)) break;
                HttpEntity entity2 = response.getEntity();
                if (connHolder.isReusable()) {
                    EntityUtils.consume((HttpEntity)entity2);
                } else {
                    managedConn.close();
                    if (proxyAuthState.getState() == AuthProtocolState.SUCCESS && proxyAuthState.isConnectionBased()) {
                        this.log.debug((Object)"Resetting proxy auth state");
                        proxyAuthState.reset();
                    }
                    if (targetAuthState.getState() == AuthProtocolState.SUCCESS && targetAuthState.isConnectionBased()) {
                        this.log.debug((Object)"Resetting target auth state");
                        targetAuthState.reset();
                    }
                }
                HttpRequest original = request.getOriginal();
                if (!original.containsHeader("Authorization")) {
                    request.removeHeaders("Authorization");
                }
                if (!original.containsHeader("Proxy-Authorization")) {
                    request.removeHeaders("Proxy-Authorization");
                }
                ++execCount;
            }
            if (userToken == null) {
                userToken = this.userTokenHandler.getUserToken((HttpContext)context);
                context.setAttribute("http.user-token", userToken);
            }
            if (userToken != null) {
                connHolder.setState(userToken);
            }
            if ((entity = response.getEntity()) != null) {
                if (entity.isStreaming()) return new HttpResponseProxy(response, connHolder);
            }
            connHolder.releaseConnection();
            return new HttpResponseProxy(response, null);
        }
        catch (ConnectionShutdownException ex) {
            InterruptedIOException ioex = new InterruptedIOException("Connection has been shut down");
            ioex.initCause(ex);
            throw ioex;
        }
        catch (HttpException ex) {
            connHolder.abortConnection();
            throw ex;
        }
        catch (IOException ex) {
            connHolder.abortConnection();
            if (proxyAuthState.isConnectionBased()) {
                proxyAuthState.reset();
            }
            if (!targetAuthState.isConnectionBased()) throw ex;
            targetAuthState.reset();
            throw ex;
        }
        catch (RuntimeException ex) {
            connHolder.abortConnection();
            if (proxyAuthState.isConnectionBased()) {
                proxyAuthState.reset();
            }
            if (!targetAuthState.isConnectionBased()) throw ex;
            targetAuthState.reset();
            throw ex;
        }
        catch (Error error) {
            this.connManager.shutdown();
            throw error;
        }
    }

    private boolean createTunnelToProxy(HttpRoute route, int hop, HttpClientContext context) throws HttpException {
        throw new HttpException("Proxy chains are not supported.");
    }

    private boolean needAuthentication(AuthState targetAuthState, AuthState proxyAuthState, HttpRoute route, HttpResponse response, HttpClientContext context) {
        RequestConfig config = context.getRequestConfig();
        if (!config.isAuthenticationEnabled()) return false;
        HttpHost target = context.getTargetHost();
        if (target == null) {
            target = route.getTargetHost();
        }
        if (target.getPort() < 0) {
            target = new HttpHost(target.getHostName(), route.getTargetHost().getPort(), target.getSchemeName());
        }
        boolean targetAuthRequested = this.authenticator.isAuthenticationRequested(target, response, this.targetAuthStrategy, targetAuthState, (HttpContext)context);
        HttpHost proxy = route.getProxyHost();
        if (proxy == null) {
            proxy = route.getTargetHost();
        }
        boolean proxyAuthRequested = this.authenticator.isAuthenticationRequested(proxy, response, this.proxyAuthStrategy, proxyAuthState, (HttpContext)context);
        if (targetAuthRequested) {
            return this.authenticator.handleAuthChallenge(target, response, this.targetAuthStrategy, targetAuthState, (HttpContext)context);
        }
        if (!proxyAuthRequested) return false;
        return this.authenticator.handleAuthChallenge(proxy, response, this.proxyAuthStrategy, proxyAuthState, (HttpContext)context);
    }
}
