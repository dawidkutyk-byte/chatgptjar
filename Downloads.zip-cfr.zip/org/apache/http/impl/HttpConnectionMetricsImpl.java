/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.http.HttpConnectionMetrics
 *  org.apache.http.io.HttpTransportMetrics
 */
package org.apache.http.impl;

import java.util.HashMap;
import java.util.Map;
import org.apache.http.HttpConnectionMetrics;
import org.apache.http.io.HttpTransportMetrics;

public class HttpConnectionMetricsImpl
implements HttpConnectionMetrics {
    public static final String RECEIVED_BYTES_COUNT = "http.received-bytes-count";
    public static final String REQUEST_COUNT = "http.request-count";
    private long requestCount = 0L;
    private final HttpTransportMetrics inTransportMetric;
    public static final String RESPONSE_COUNT = "http.response-count";
    private long responseCount = 0L;
    public static final String SENT_BYTES_COUNT = "http.sent-bytes-count";
    private Map<String, Object> metricsCache;
    private final HttpTransportMetrics outTransportMetric;

    public void incrementResponseCount() {
        ++this.responseCount;
    }

    public Object getMetric(String metricName) {
        Object value = null;
        if (this.metricsCache != null) {
            value = this.metricsCache.get(metricName);
        }
        if (value != null) return value;
        if (REQUEST_COUNT.equals(metricName)) {
            value = this.requestCount;
        } else if (RESPONSE_COUNT.equals(metricName)) {
            value = this.responseCount;
        } else {
            if (RECEIVED_BYTES_COUNT.equals(metricName)) {
                return this.inTransportMetric != null ? Long.valueOf(this.inTransportMetric.getBytesTransferred()) : null;
            }
            if (!SENT_BYTES_COUNT.equals(metricName)) return value;
            return this.outTransportMetric != null ? Long.valueOf(this.outTransportMetric.getBytesTransferred()) : null;
        }
        return value;
    }

    public long getSentBytesCount() {
        return this.outTransportMetric != null ? this.outTransportMetric.getBytesTransferred() : -1L;
    }

    public long getResponseCount() {
        return this.responseCount;
    }

    public void reset() {
        if (this.outTransportMetric != null) {
            this.outTransportMetric.reset();
        }
        if (this.inTransportMetric != null) {
            this.inTransportMetric.reset();
        }
        this.requestCount = 0L;
        this.responseCount = 0L;
        this.metricsCache = null;
    }

    public void setMetric(String metricName, Object obj) {
        if (this.metricsCache == null) {
            this.metricsCache = new HashMap<String, Object>();
        }
        this.metricsCache.put(metricName, obj);
    }

    public void incrementRequestCount() {
        ++this.requestCount;
    }

    public long getReceivedBytesCount() {
        return this.inTransportMetric != null ? this.inTransportMetric.getBytesTransferred() : -1L;
    }

    public HttpConnectionMetricsImpl(HttpTransportMetrics inTransportMetric, HttpTransportMetrics outTransportMetric) {
        this.inTransportMetric = inTransportMetric;
        this.outTransportMetric = outTransportMetric;
    }

    public long getRequestCount() {
        return this.requestCount;
    }
}
