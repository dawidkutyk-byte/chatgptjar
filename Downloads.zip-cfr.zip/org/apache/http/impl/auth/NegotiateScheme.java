/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.logging.Log
 *  org.apache.commons.logging.LogFactory
 *  org.apache.http.Header
 *  org.apache.http.HttpRequest
 *  org.apache.http.auth.AuthenticationException
 *  org.apache.http.auth.Credentials
 *  org.apache.http.impl.auth.GGSSchemeBase
 *  org.apache.http.impl.auth.SpnegoTokenGenerator
 *  org.apache.http.protocol.HttpContext
 *  org.apache.http.util.Args
 */
package org.apache.http.impl.auth;

import java.io.IOException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.Header;
import org.apache.http.HttpRequest;
import org.apache.http.auth.AuthenticationException;
import org.apache.http.auth.Credentials;
import org.apache.http.impl.auth.GGSSchemeBase;
import org.apache.http.impl.auth.SpnegoTokenGenerator;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.Args;
import org.ietf.jgss.GSSException;
import org.ietf.jgss.Oid;

@Deprecated
public class NegotiateScheme
extends GGSSchemeBase {
    private static final String SPNEGO_OID = "1.3.6.1.5.5.2";
    private static final String KERBEROS_OID = "1.2.840.113554.1.2.2";
    private final Log log = LogFactory.getLog(((Object)((Object)this)).getClass());
    private final SpnegoTokenGenerator spengoGenerator;

    public String getRealm() {
        return null;
    }

    public NegotiateScheme(SpnegoTokenGenerator spengoGenerator) {
        this(spengoGenerator, false);
    }

    public Header authenticate(Credentials credentials, HttpRequest request, HttpContext context) throws AuthenticationException {
        return super.authenticate(credentials, request, context);
    }

    public Header authenticate(Credentials credentials, HttpRequest request) throws AuthenticationException {
        return this.authenticate(credentials, request, null);
    }

    public boolean isConnectionBased() {
        return true;
    }

    public NegotiateScheme() {
        this(null, false);
    }

    public String getParameter(String name) {
        Args.notNull((Object)name, (String)"Parameter name");
        return null;
    }

    protected byte[] generateToken(byte[] input, String authServer, Credentials credentials) throws GSSException {
        Oid negotiationOid = new Oid(SPNEGO_OID);
        byte[] token = input;
        boolean tryKerberos = false;
        try {
            token = this.generateGSSToken(token, negotiationOid, authServer, credentials);
        }
        catch (GSSException ex) {
            if (ex.getMajor() != 2) throw ex;
            this.log.debug((Object)"GSSException BAD_MECH, retry with Kerberos MECH");
            tryKerberos = true;
        }
        if (!tryKerberos) return token;
        this.log.debug((Object)"Using Kerberos MECH 1.2.840.113554.1.2.2");
        negotiationOid = new Oid(KERBEROS_OID);
        token = this.generateGSSToken(token, negotiationOid, authServer, credentials);
        if (token == null) return token;
        if (this.spengoGenerator == null) return token;
        try {
            token = this.spengoGenerator.generateSpnegoDERObject(token);
        }
        catch (IOException ex) {
            this.log.error((Object)ex.getMessage(), (Throwable)ex);
        }
        return token;
    }

    public NegotiateScheme(SpnegoTokenGenerator spengoGenerator, boolean stripPort) {
        super(stripPort);
        this.spengoGenerator = spengoGenerator;
    }

    protected byte[] generateToken(byte[] input, String authServer) throws GSSException {
        return super.generateToken(input, authServer);
    }

    public String getSchemeName() {
        return "Negotiate";
    }
}
