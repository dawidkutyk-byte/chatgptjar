/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.http.ExceptionLogger
 *  org.apache.http.HttpConnectionFactory
 *  org.apache.http.HttpServerConnection
 *  org.apache.http.config.SocketConfig
 *  org.apache.http.impl.DefaultBHttpServerConnection
 *  org.apache.http.impl.bootstrap.HttpServer$Status
 *  org.apache.http.impl.bootstrap.RequestListener
 *  org.apache.http.impl.bootstrap.SSLServerSetupHandler
 *  org.apache.http.impl.bootstrap.ThreadFactoryImpl
 *  org.apache.http.impl.bootstrap.Worker
 *  org.apache.http.impl.bootstrap.WorkerPoolExecutor
 *  org.apache.http.protocol.HttpService
 */
package org.apache.http.impl.bootstrap;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import javax.net.ServerSocketFactory;
import javax.net.ssl.SSLServerSocket;
import org.apache.http.ExceptionLogger;
import org.apache.http.HttpConnectionFactory;
import org.apache.http.HttpServerConnection;
import org.apache.http.config.SocketConfig;
import org.apache.http.impl.DefaultBHttpServerConnection;
import org.apache.http.impl.bootstrap.HttpServer;
import org.apache.http.impl.bootstrap.RequestListener;
import org.apache.http.impl.bootstrap.SSLServerSetupHandler;
import org.apache.http.impl.bootstrap.ThreadFactoryImpl;
import org.apache.http.impl.bootstrap.Worker;
import org.apache.http.impl.bootstrap.WorkerPoolExecutor;
import org.apache.http.protocol.HttpService;

public class HttpServer {
    private final ThreadGroup workerThreads;
    private final ExceptionLogger exceptionLogger;
    private final HttpService httpService;
    private final int port;
    private final WorkerPoolExecutor workerExecutorService;
    private volatile RequestListener requestListener;
    private final SSLServerSetupHandler sslSetupHandler;
    private final InetAddress ifAddress;
    private final ServerSocketFactory serverSocketFactory;
    private final SocketConfig socketConfig;
    private final ThreadPoolExecutor listenerExecutorService;
    private final HttpConnectionFactory<? extends DefaultBHttpServerConnection> connectionFactory;
    private volatile ServerSocket serverSocket;
    private final AtomicReference<Status> status;

    public int getLocalPort() {
        ServerSocket localSocket = this.serverSocket;
        return localSocket != null ? localSocket.getLocalPort() : -1;
    }

    public void start() throws IOException {
        if (!this.status.compareAndSet(Status.READY, Status.ACTIVE)) return;
        this.serverSocket = this.serverSocketFactory.createServerSocket(this.port, this.socketConfig.getBacklogSize(), this.ifAddress);
        this.serverSocket.setReuseAddress(this.socketConfig.isSoReuseAddress());
        if (this.socketConfig.getRcvBufSize() > 0) {
            this.serverSocket.setReceiveBufferSize(this.socketConfig.getRcvBufSize());
        }
        if (this.sslSetupHandler != null && this.serverSocket instanceof SSLServerSocket) {
            this.sslSetupHandler.initialize((SSLServerSocket)this.serverSocket);
        }
        this.requestListener = new RequestListener(this.socketConfig, this.serverSocket, this.httpService, this.connectionFactory, this.exceptionLogger, (ExecutorService)this.workerExecutorService);
        this.listenerExecutorService.execute((Runnable)this.requestListener);
    }

    public void shutdown(long gracePeriod, TimeUnit timeUnit) {
        this.stop();
        if (gracePeriod > 0L) {
            try {
                this.awaitTermination(gracePeriod, timeUnit);
            }
            catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
            }
        }
        Set workers = this.workerExecutorService.getWorkers();
        Iterator i$ = workers.iterator();
        while (i$.hasNext()) {
            Worker worker = (Worker)i$.next();
            HttpServerConnection conn = worker.getConnection();
            try {
                conn.shutdown();
            }
            catch (IOException ex) {
                this.exceptionLogger.log((Exception)ex);
            }
        }
    }

    public void awaitTermination(long timeout, TimeUnit timeUnit) throws InterruptedException {
        this.workerExecutorService.awaitTermination(timeout, timeUnit);
    }

    HttpServer(int port, InetAddress ifAddress, SocketConfig socketConfig, ServerSocketFactory serverSocketFactory, HttpService httpService, HttpConnectionFactory<? extends DefaultBHttpServerConnection> connectionFactory, SSLServerSetupHandler sslSetupHandler, ExceptionLogger exceptionLogger) {
        this.port = port;
        this.ifAddress = ifAddress;
        this.socketConfig = socketConfig;
        this.serverSocketFactory = serverSocketFactory;
        this.httpService = httpService;
        this.connectionFactory = connectionFactory;
        this.sslSetupHandler = sslSetupHandler;
        this.exceptionLogger = exceptionLogger;
        this.listenerExecutorService = new ThreadPoolExecutor(1, 1, 0L, TimeUnit.MILLISECONDS, new SynchronousQueue<Runnable>(), (ThreadFactory)new ThreadFactoryImpl("HTTP-listener-" + this.port));
        this.workerThreads = new ThreadGroup("HTTP-workers");
        this.workerExecutorService = new WorkerPoolExecutor(0, Integer.MAX_VALUE, 1L, TimeUnit.SECONDS, new SynchronousQueue(), (ThreadFactory)new ThreadFactoryImpl("HTTP-worker", this.workerThreads));
        this.status = new AtomicReference<Status>(Status.READY);
    }

    public void stop() {
        if (!this.status.compareAndSet(Status.ACTIVE, Status.STOPPING)) return;
        this.listenerExecutorService.shutdown();
        this.workerExecutorService.shutdown();
        RequestListener local = this.requestListener;
        if (local != null) {
            try {
                local.terminate();
            }
            catch (IOException ex) {
                this.exceptionLogger.log((Exception)ex);
            }
        }
        this.workerThreads.interrupt();
    }

    public InetAddress getInetAddress() {
        ServerSocket localSocket = this.serverSocket;
        return localSocket != null ? localSocket.getInetAddress() : null;
    }
}
