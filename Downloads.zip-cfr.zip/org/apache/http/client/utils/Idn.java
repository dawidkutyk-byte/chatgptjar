/*
 * Decompiled with CFR 0.152.
 */
package org.apache.http.client.utils;

@Deprecated
public interface Idn {
    public String toUnicode(String var1);
}
