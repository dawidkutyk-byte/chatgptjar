/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.http.HttpResponse
 */
package org.apache.http.client.methods;

import java.io.Closeable;
import org.apache.http.HttpResponse;

public interface CloseableHttpResponse
extends Closeable,
HttpResponse {
}
