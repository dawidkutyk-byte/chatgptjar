/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.http.Consts
 *  org.apache.http.Header
 *  org.apache.http.HeaderIterator
 *  org.apache.http.HttpEntity
 *  org.apache.http.HttpEntityEnclosingRequest
 *  org.apache.http.HttpRequest
 *  org.apache.http.NameValuePair
 *  org.apache.http.ProtocolVersion
 *  org.apache.http.client.config.RequestConfig
 *  org.apache.http.client.entity.UrlEncodedFormEntity
 *  org.apache.http.client.methods.Configurable
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.client.methods.RequestBuilder$InternalEntityEclosingRequest
 *  org.apache.http.client.methods.RequestBuilder$InternalRequest
 *  org.apache.http.client.utils.URIBuilder
 *  org.apache.http.client.utils.URLEncodedUtils
 *  org.apache.http.entity.ContentType
 *  org.apache.http.message.BasicHeader
 *  org.apache.http.message.BasicNameValuePair
 *  org.apache.http.message.HeaderGroup
 *  org.apache.http.protocol.HTTP
 *  org.apache.http.util.Args
 */
package org.apache.http.client.methods;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import org.apache.http.Consts;
import org.apache.http.Header;
import org.apache.http.HeaderIterator;
import org.apache.http.HttpEntity;
import org.apache.http.HttpEntityEnclosingRequest;
import org.apache.http.HttpRequest;
import org.apache.http.NameValuePair;
import org.apache.http.ProtocolVersion;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.Configurable;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.entity.ContentType;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.message.HeaderGroup;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.Args;

public class RequestBuilder {
    private String method;
    private RequestConfig config;
    private URI uri;
    private HttpEntity entity;
    private List<NameValuePair> parameters;
    private ProtocolVersion version;
    private Charset charset;
    private HeaderGroup headerGroup;

    public static RequestBuilder patch(String uri) {
        return new RequestBuilder("PATCH", uri);
    }

    public static RequestBuilder put(URI uri) {
        return new RequestBuilder("PUT", uri);
    }

    public String getMethod() {
        return this.method;
    }

    public static RequestBuilder head(URI uri) {
        return new RequestBuilder("HEAD", uri);
    }

    public RequestBuilder removeHeaders(String name) {
        if (name == null) return this;
        if (this.headerGroup == null) {
            return this;
        }
        HeaderIterator i = this.headerGroup.iterator();
        while (i.hasNext()) {
            Header header = i.nextHeader();
            if (!name.equalsIgnoreCase(header.getName())) continue;
            i.remove();
        }
        return this;
    }

    public static RequestBuilder delete() {
        return new RequestBuilder("DELETE");
    }

    public static RequestBuilder options(URI uri) {
        return new RequestBuilder("OPTIONS", uri);
    }

    public static RequestBuilder options(String uri) {
        return new RequestBuilder("OPTIONS", uri);
    }

    public static RequestBuilder head() {
        return new RequestBuilder("HEAD");
    }

    public HttpEntity getEntity() {
        return this.entity;
    }

    public static RequestBuilder patch() {
        return new RequestBuilder("PATCH");
    }

    public static RequestBuilder post(String uri) {
        return new RequestBuilder("POST", uri);
    }

    public HttpUriRequest build() {
        InternalRequest result;
        URI uriNotNull = this.uri != null ? this.uri : URI.create("/");
        HttpEntity entityCopy = this.entity;
        if (this.parameters != null && !this.parameters.isEmpty()) {
            if (entityCopy == null && ("POST".equalsIgnoreCase(this.method) || "PUT".equalsIgnoreCase(this.method))) {
                entityCopy = new UrlEncodedFormEntity(this.parameters, this.charset != null ? this.charset : HTTP.DEF_CONTENT_CHARSET);
            } else {
                try {
                    uriNotNull = new URIBuilder(uriNotNull).setCharset(this.charset).addParameters(this.parameters).build();
                }
                catch (URISyntaxException ex) {
                    // empty catch block
                }
            }
        }
        if (entityCopy == null) {
            result = new InternalRequest(this.method);
        } else {
            InternalEntityEclosingRequest request = new InternalEntityEclosingRequest(this.method);
            request.setEntity(entityCopy);
            result = request;
        }
        result.setProtocolVersion(this.version);
        result.setURI(uriNotNull);
        if (this.headerGroup != null) {
            result.setHeaders(this.headerGroup.getAllHeaders());
        }
        result.setConfig(this.config);
        return result;
    }

    public List<NameValuePair> getParameters() {
        return this.parameters != null ? new ArrayList<NameValuePair>(this.parameters) : new ArrayList();
    }

    public RequestBuilder setEntity(HttpEntity entity) {
        this.entity = entity;
        return this;
    }

    public static RequestBuilder trace(String uri) {
        return new RequestBuilder("TRACE", uri);
    }

    public static RequestBuilder trace(URI uri) {
        return new RequestBuilder("TRACE", uri);
    }

    public Charset getCharset() {
        return this.charset;
    }

    public static RequestBuilder create(String method) {
        Args.notBlank((CharSequence)method, (String)"HTTP method");
        return new RequestBuilder(method);
    }

    public RequestBuilder addParameter(NameValuePair nvp) {
        Args.notNull((Object)nvp, (String)"Name value pair");
        if (this.parameters == null) {
            this.parameters = new LinkedList<NameValuePair>();
        }
        this.parameters.add(nvp);
        return this;
    }

    RequestBuilder(String method, String uri) {
        this.method = method;
        this.uri = uri != null ? URI.create(uri) : null;
    }

    public RequestBuilder addHeader(Header header) {
        if (this.headerGroup == null) {
            this.headerGroup = new HeaderGroup();
        }
        this.headerGroup.addHeader(header);
        return this;
    }

    public static RequestBuilder get() {
        return new RequestBuilder("GET");
    }

    RequestBuilder(String method, URI uri) {
        this.method = method;
        this.uri = uri;
    }

    public RequestBuilder setConfig(RequestConfig config) {
        this.config = config;
        return this;
    }

    public RequestBuilder setUri(URI uri) {
        this.uri = uri;
        return this;
    }

    public RequestBuilder setCharset(Charset charset) {
        this.charset = charset;
        return this;
    }

    public static RequestBuilder options() {
        return new RequestBuilder("OPTIONS");
    }

    public RequestBuilder setHeader(Header header) {
        if (this.headerGroup == null) {
            this.headerGroup = new HeaderGroup();
        }
        this.headerGroup.updateHeader(header);
        return this;
    }

    private RequestBuilder doCopy(HttpRequest request) {
        if (request == null) {
            return this;
        }
        this.method = request.getRequestLine().getMethod();
        this.version = request.getRequestLine().getProtocolVersion();
        if (this.headerGroup == null) {
            this.headerGroup = new HeaderGroup();
        }
        this.headerGroup.clear();
        this.headerGroup.setHeaders(request.getAllHeaders());
        this.parameters = null;
        this.entity = null;
        if (request instanceof HttpEntityEnclosingRequest) {
            HttpEntity originalEntity = ((HttpEntityEnclosingRequest)request).getEntity();
            ContentType contentType = ContentType.get((HttpEntity)originalEntity);
            if (contentType != null && contentType.getMimeType().equals(ContentType.APPLICATION_FORM_URLENCODED.getMimeType())) {
                try {
                    List formParams = URLEncodedUtils.parse((HttpEntity)originalEntity);
                    if (!formParams.isEmpty()) {
                        this.parameters = formParams;
                    }
                }
                catch (IOException ignore) {}
            } else {
                this.entity = originalEntity;
            }
        }
        this.uri = request instanceof HttpUriRequest ? ((HttpUriRequest)request).getURI() : URI.create(request.getRequestLine().getUri());
        this.config = request instanceof Configurable ? ((Configurable)request).getConfig() : null;
        return this;
    }

    public RequestConfig getConfig() {
        return this.config;
    }

    public static RequestBuilder copy(HttpRequest request) {
        Args.notNull((Object)request, (String)"HTTP request");
        return new RequestBuilder().doCopy(request);
    }

    RequestBuilder(String method) {
        this.charset = Consts.UTF_8;
        this.method = method;
    }

    public static RequestBuilder post() {
        return new RequestBuilder("POST");
    }

    public RequestBuilder setVersion(ProtocolVersion version) {
        this.version = version;
        return this;
    }

    public URI getUri() {
        return this.uri;
    }

    public RequestBuilder setUri(String uri) {
        this.uri = uri != null ? URI.create(uri) : null;
        return this;
    }

    public RequestBuilder addParameters(NameValuePair ... nvps) {
        NameValuePair[] arr$ = nvps;
        int len$ = arr$.length;
        int i$ = 0;
        while (i$ < len$) {
            NameValuePair nvp = arr$[i$];
            this.addParameter(nvp);
            ++i$;
        }
        return this;
    }

    public static RequestBuilder trace() {
        return new RequestBuilder("TRACE");
    }

    public RequestBuilder addParameter(String name, String value) {
        return this.addParameter((NameValuePair)new BasicNameValuePair(name, value));
    }

    public RequestBuilder addHeader(String name, String value) {
        if (this.headerGroup == null) {
            this.headerGroup = new HeaderGroup();
        }
        this.headerGroup.addHeader((Header)new BasicHeader(name, value));
        return this;
    }

    public static RequestBuilder post(URI uri) {
        return new RequestBuilder("POST", uri);
    }

    public Header[] getHeaders(String name) {
        return this.headerGroup != null ? this.headerGroup.getHeaders(name) : null;
    }

    public static RequestBuilder patch(URI uri) {
        return new RequestBuilder("PATCH", uri);
    }

    public static RequestBuilder get(String uri) {
        return new RequestBuilder("GET", uri);
    }

    RequestBuilder() {
        this(null);
    }

    public ProtocolVersion getVersion() {
        return this.version;
    }

    public static RequestBuilder get(URI uri) {
        return new RequestBuilder("GET", uri);
    }

    public static RequestBuilder put() {
        return new RequestBuilder("PUT");
    }

    public RequestBuilder setHeader(String name, String value) {
        if (this.headerGroup == null) {
            this.headerGroup = new HeaderGroup();
        }
        this.headerGroup.updateHeader((Header)new BasicHeader(name, value));
        return this;
    }

    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("RequestBuilder [method=");
        builder.append(this.method);
        builder.append(", charset=");
        builder.append(this.charset);
        builder.append(", version=");
        builder.append(this.version);
        builder.append(", uri=");
        builder.append(this.uri);
        builder.append(", headerGroup=");
        builder.append(this.headerGroup);
        builder.append(", entity=");
        builder.append(this.entity);
        builder.append(", parameters=");
        builder.append(this.parameters);
        builder.append(", config=");
        builder.append(this.config);
        builder.append("]");
        return builder.toString();
    }

    public Header getFirstHeader(String name) {
        return this.headerGroup != null ? this.headerGroup.getFirstHeader(name) : null;
    }

    public Header getLastHeader(String name) {
        return this.headerGroup != null ? this.headerGroup.getLastHeader(name) : null;
    }

    public static RequestBuilder put(String uri) {
        return new RequestBuilder("PUT", uri);
    }

    public RequestBuilder removeHeader(Header header) {
        if (this.headerGroup == null) {
            this.headerGroup = new HeaderGroup();
        }
        this.headerGroup.removeHeader(header);
        return this;
    }

    public static RequestBuilder delete(URI uri) {
        return new RequestBuilder("DELETE", uri);
    }

    public static RequestBuilder delete(String uri) {
        return new RequestBuilder("DELETE", uri);
    }

    public static RequestBuilder head(String uri) {
        return new RequestBuilder("HEAD", uri);
    }
}
