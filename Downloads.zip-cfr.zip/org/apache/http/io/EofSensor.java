/*
 * Decompiled with CFR 0.152.
 */
package org.apache.http.io;

@Deprecated
public interface EofSensor {
    public boolean isEof();
}
