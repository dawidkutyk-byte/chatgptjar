/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.http.cookie.CookieAttributeHandler
 */
package org.apache.http.cookie;

import org.apache.http.cookie.CookieAttributeHandler;

public interface CommonCookieAttributeHandler
extends CookieAttributeHandler {
    public String getAttributeName();
}
