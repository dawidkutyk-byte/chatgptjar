/*
 * Decompiled with CFR 0.152.
 */
package org.apache.http;

public interface NameValuePair {
    public String getValue();

    public String getName();
}
