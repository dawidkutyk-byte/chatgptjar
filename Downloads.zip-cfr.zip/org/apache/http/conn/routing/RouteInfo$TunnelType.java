/*
 * Decompiled with CFR 0.152.
 */
package org.apache.http.conn.routing;

public static enum RouteInfo.TunnelType {
    PLAIN,
    TUNNELLED;

}
