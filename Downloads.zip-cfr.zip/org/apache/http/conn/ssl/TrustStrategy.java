/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.http.ssl.TrustStrategy
 */
package org.apache.http.conn.ssl;

public interface TrustStrategy
extends org.apache.http.ssl.TrustStrategy {
}
