/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.http.conn.scheme.SchemeSocketFactory
 */
package org.apache.http.conn.scheme;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import org.apache.http.conn.scheme.SchemeSocketFactory;

@Deprecated
public interface LayeredSchemeSocketFactory
extends SchemeSocketFactory {
    public Socket createLayeredSocket(Socket var1, String var2, int var3, boolean var4) throws UnknownHostException, IOException;
}
