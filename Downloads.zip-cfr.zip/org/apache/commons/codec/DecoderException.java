/*
 * Decompiled with CFR 0.152.
 */
package org.apache.commons.codec;

public class DecoderException
extends Exception {
    private static final long serialVersionUID = 1L;

    public DecoderException(String message) {
        super(message);
    }

    public DecoderException() {
    }

    public DecoderException(String message, Throwable cause) {
        super(message, cause);
    }

    public DecoderException(Throwable cause) {
        super(cause);
    }
}
