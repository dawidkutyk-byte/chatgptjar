/*
 * Decompiled with CFR 0.152.
 */
package org.apache.commons.codec.language.bm;

import org.apache.commons.codec.language.bm.Rule;

public static interface Rule.PhonemeExpr {
    public Iterable<Rule.Phoneme> getPhonemes();
}
