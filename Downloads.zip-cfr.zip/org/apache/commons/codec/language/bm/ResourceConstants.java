/*
 * Decompiled with CFR 0.152.
 */
package org.apache.commons.codec.language.bm;

class ResourceConstants {
    static final String CMT = "//";
    static final String EXT_CMT_START = "/*";
    static final String EXT_CMT_END = "*/";
    static final String ENCODING = "UTF-8";

    ResourceConstants() {
    }
}
