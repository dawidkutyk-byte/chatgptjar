/*
 * Decompiled with CFR 0.152.
 */
package org.intellij.lang.annotations;

public static @interface JdkConstants.PatternFlags {
}
