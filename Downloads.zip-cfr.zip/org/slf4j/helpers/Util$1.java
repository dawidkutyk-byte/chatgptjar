/*
 * Decompiled with CFR 0.152.
 */
package org.slf4j.helpers;

static class Util.1 {
}
