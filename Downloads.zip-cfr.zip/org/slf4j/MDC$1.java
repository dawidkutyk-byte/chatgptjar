/*
 * Decompiled with CFR 0.152.
 */
package org.slf4j;

static class MDC.1 {
}
