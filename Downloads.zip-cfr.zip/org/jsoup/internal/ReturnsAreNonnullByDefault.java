/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  h9\u0104\u0144
 */
package org.jsoup.internal;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@h9\u0104\u0144
@Retention(value=RetentionPolicy.RUNTIME)
@Documented
@Deprecated
public @interface ReturnsAreNonnullByDefault {
}
