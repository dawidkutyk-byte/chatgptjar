/*
 * Decompiled with CFR 0.152.
 */
package org.jsoup.safety;

static class Cleaner.1 {
}
