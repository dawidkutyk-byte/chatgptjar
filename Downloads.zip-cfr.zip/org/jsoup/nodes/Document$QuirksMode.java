/*
 * Decompiled with CFR 0.152.
 */
package org.jsoup.nodes;

public static enum Document.QuirksMode {
    noQuirks,
    quirks,
    limitedQuirks;

}
