/*
 * Decompiled with CFR 0.152.
 */
package org.java_websocket.drafts;

