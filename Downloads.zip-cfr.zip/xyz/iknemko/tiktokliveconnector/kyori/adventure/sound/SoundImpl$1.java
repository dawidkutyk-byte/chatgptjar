/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  xyz.iknemko.tiktokliveconnector.kyori.adventure.sound.Sound$Emitter
 */
package xyz.iknemko.tiktokliveconnector.kyori.adventure.sound;

import xyz.iknemko.tiktokliveconnector.kyori.adventure.sound.Sound;

class SoundImpl.1
implements Sound.Emitter {
    SoundImpl.1() {
    }

    public String toString() {
        return "SelfSoundEmitter";
    }
}
