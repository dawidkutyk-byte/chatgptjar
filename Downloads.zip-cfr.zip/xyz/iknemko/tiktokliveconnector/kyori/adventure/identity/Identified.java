/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  xyz.iknemko.tiktokliveconnector.kyori.adventure.identity.Identity
 */
package xyz.iknemko.tiktokliveconnector.kyori.adventure.identity;

import org.jetbrains.annotations.NotNull;
import xyz.iknemko.tiktokliveconnector.kyori.adventure.identity.Identity;

public interface Identified {
    @NotNull
    public Identity identity();
}
