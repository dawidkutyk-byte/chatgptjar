/*
 * Decompiled with CFR 0.152.
 */
@ApiStatus.Internal
package xyz.iknemko.tiktokliveconnector.kyori.adventure.text.minimessage.internal.parser;

import org.jetbrains.annotations.ApiStatus;

