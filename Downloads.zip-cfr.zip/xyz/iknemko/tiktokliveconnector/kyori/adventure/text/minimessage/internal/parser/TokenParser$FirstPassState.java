/*
 * Decompiled with CFR 0.152.
 */
package xyz.iknemko.tiktokliveconnector.kyori.adventure.text.minimessage.internal.parser;

static enum TokenParser.FirstPassState {
    NORMAL,
    TAG,
    STRING;

}
