/*
 * Decompiled with CFR 0.152.
 */
package xyz.iknemko.tiktokliveconnector.kyori.adventure.text;

final class ComponentInternals {
    static final String CHILDREN_PROPERTY = "children";

    private ComponentInternals() {
    }
}
