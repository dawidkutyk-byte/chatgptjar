/*
 * Decompiled with CFR 0.152.
 */
package xyz.iknemko.tiktokliveconnector.kyori.adventure.text;

public static enum BlockNBTComponent.WorldPos.Coordinate.Type {
    ABSOLUTE,
    RELATIVE;

}
