/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  xyz.iknemko.tiktokliveconnector.kyori.adventure.title.Title$Times
 *  xyz.iknemko.tiktokliveconnector.kyori.adventure.title.TitlePart
 */
package xyz.iknemko.tiktokliveconnector.kyori.adventure.title;

import xyz.iknemko.tiktokliveconnector.kyori.adventure.title.Title;
import xyz.iknemko.tiktokliveconnector.kyori.adventure.title.TitlePart;

class TitlePart.3
implements TitlePart<Title.Times> {
    TitlePart.3() {
    }

    public String toString() {
        return "TitlePart.TIMES";
    }
}
