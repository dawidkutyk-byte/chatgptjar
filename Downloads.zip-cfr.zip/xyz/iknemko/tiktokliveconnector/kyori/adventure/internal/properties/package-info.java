/*
 * Decompiled with CFR 0.152.
 */
@ApiStatus.Internal
package xyz.iknemko.tiktokliveconnector.kyori.adventure.internal.properties;

import org.jetbrains.annotations.ApiStatus;

