/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  xyz.iknemko.tiktokliveconnector.kyori.option.value.ValueType
 */
package xyz.iknemko.tiktokliveconnector.kyori.option.value;

import xyz.iknemko.tiktokliveconnector.kyori.option.value.ValueType;

static final class ValueTypeImpl.Types {
    static ValueType<String> STRING = new /* Unavailable Anonymous Inner Class!! */;
    static ValueType<Double> DOUBLE;
    static ValueType<Integer> INT;
    static ValueType<Boolean> BOOLEAN;

    static {
        BOOLEAN = new /* Unavailable Anonymous Inner Class!! */;
        INT = new /* Unavailable Anonymous Inner Class!! */;
        DOUBLE = new /* Unavailable Anonymous Inner Class!! */;
    }

    private ValueTypeImpl.Types() {
    }
}
