/*
 * Decompiled with CFR 0.152.
 */
/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
class AA5\u015a {
    private static String[] CRACKME_BITCH = new String[5];
    public final int D\u0106Mv;
    static long CRACKME_9140807e_0df4_45f5_9fc3_50f175b70164_bb73c3b3 = -4967453738245910279L;
    public final int \u0106s9V;
    public final int \u01063ep;
    public String ev\u0118\u0118;

    public int zn6iVfAFia7Wmp-r() {
        AA5\u015a CRACKME_18044fa8_b5c1_49bc_8e00_c43416d80cb71ab10b87;
        if (CRACKME_9140807e_0df4_45f5_9fc3_50f175b70164_bb73c3b3 == 3815535863150216984L >>> "\u0000\u0000".length()) {
            if ((991018341 - 1875867349 ^ (2795500345412245087L == 2795500345412245088L ? -721778144 : 0x1F76D619 ^ 0x608929E6)) != 0) {
                int cfr_ignored_0 = 0xD6CDF4BB ^ 0xD6CDF4BA;
            }
        } else {
            int cfr_ignored_1 = 0x3B126A93 ^ 0x3B126A93;
        }
        int n = -8795549585562785850L == -8795549585562785849L ? -1322215060 : 0x1669806 ^ 0x26079595;
        return CRACKME_18044fa8_b5c1_49bc_8e00_c43416d80cb71ab10b87.D\u0106Mv;
    }

    static {
        AA5\u015a.CRACKME_BITCH[0] = "\u2500\u2500\u2500\u2500\u2500\u2500\u2584\u258c\u2590\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u200b\u2580\u2580\u2580\u2580\u2580\u2580\u258c";
        AA5\u015a.CRACKME_BITCH[1] = "\u2500\u2500\u2500\u2584\u2584\u2588\u2588\u258c\u2588 BEEP BEEP";
        AA5\u015a.CRACKME_BITCH[2] = "\u2584\u2584\u2584\u258c\u2590\u2588\u2588\u258c\u2588 GAY PORN DELIVERY";
        AA5\u015a.CRACKME_BITCH[3] = "\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u258c\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u200b\u2584\u2584\u2584\u2584\u2584\u2584\u258c";
        AA5\u015a.CRACKME_BITCH[4] = "\u2580(@)\u2580\u2580\u2580\u2580\u2580\u2580\u2580(@)(@)\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u200b\u2580\u2580\u2580\u2580(@)\u2580";
    }

    public int yNVKW4KSJW9S6yXL() {
        AA5\u015a CRACKME_eb366e12_30c1_46a9_8dc6_be70bd28b617c5c90e30;
        if (CRACKME_9140807e_0df4_45f5_9fc3_50f175b70164_bb73c3b3 == -9088640862536574130L - 221110024814609854L) {
            if ((0xD5E36DA8 ^ 0x5F1026A4 ^ (0xB8EC685F ^ 0xC71397A0)) != 0) {
                int n = -8709280069234287365L == -8709280069234287364L ? -485973752 : 0x6FB4B49D ^ 0x6FB4B49C;
            }
        } else {
            int cfr_ignored_0 = 0x62599ED ^ 0x62599ED;
        }
        int cfr_ignored_1 = 0xB0E761DF ^ 0xD4975F7C;
        int cfr_ignored_2 = 0xC6369BB ^ 0x5136595F;
        return CRACKME_eb366e12_30c1_46a9_8dc6_be70bd28b617c5c90e30.\u0106s9V;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * WARNING - void declaration
     */
    public AA5\u015a(String string, int n, int n2, int n3) {
        void CRACKME_742b3893_9680_4862_a3ee_7f300059ab6adf6bd545;
        void CRACKME_742b3893_9680_4862_a3ee_7f300059ab6a5b066770;
        void CRACKME_742b3893_9680_4862_a3ee_7f300059ab6a4819bf38;
        void CRACKME_742b3893_9680_4862_a3ee_7f300059ab6aeaba3c89;
        AA5\u015a CRACKME_742b3893_9680_4862_a3ee_7f300059ab6a445f18da;
        if (CRACKME_9140807e_0df4_45f5_9fc3_50f175b70164_bb73c3b3 == -8372527725343798901L - 5404731121498721940L) {
            int cfr_ignored_2 = 0xDA60D22D ^ 0xDA60D22C;
        } else {
            int cfr_ignored_3 = 0x4A7838F ^ 0x4A7838F;
        }
        long l = CRACKME_9140807e_0df4_45f5_9fc3_50f175b70164_bb73c3b3;
        boolean bl = true;
        block16: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                long l3 = 0x75A0240569730869L ^ 0x85FC61AB58469302L;
                l = l2 / l3;
            }
            switch ((int)l) {
                case -1479267659: {
                    l2 = -6155115068428195094L - 9131779730958473291L;
                    continue block16;
                }
                case -844459783: {
                    break block16;
                }
                case -188772346: {
                    l2 = -3180073642780071272L >>> "\u0000\u0000".length();
                    continue block16;
                }
                case 828493524: {
                    l2 = 0xE612C986D6919C55L ^ 0xA7C787F40E01E80L;
                    continue block16;
                }
            }
            break;
        }
        int n4 = 0x854874AE ^ 0x6AC116A2;
        long l4 = CRACKME_9140807e_0df4_45f5_9fc3_50f175b70164_bb73c3b3;
        boolean bl2 = true;
        block17: while (true) {
            long l5;
            if (!bl2 || (bl2 = false) || !true) {
                l4 = l5 / (0x3491A4DBA340F71L ^ 0x9EFBC509A445CEFL);
            }
            switch ((int)l4) {
                case -844459783: {
                    break block17;
                }
                case -383610397: {
                    l5 = 0xFF61C41A47303DB1L ^ 0x72A691121092E997L;
                    continue block17;
                }
                case 226670313: {
                    l5 = 4201747808797430106L - 3091830897287651139L;
                    continue block17;
                }
                case 1011497404: {
                    l5 = 0xEDF8AC88F308A12L ^ 0xBDA73C081BF6BD71L;
                    continue block17;
                }
            }
            break;
        }
        CRACKME_742b3893_9680_4862_a3ee_7f300059ab6a445f18da.ev\u0118\u0118 = CRACKME_742b3893_9680_4862_a3ee_7f300059ab6aeaba3c89;
        int cfr_ignored_4 = -511871724 - 1404464576;
        int cfr_ignored_5 = 0x928C31BA ^ 0x708BF70;
        CRACKME_742b3893_9680_4862_a3ee_7f300059ab6a445f18da.\u0106s9V = CRACKME_742b3893_9680_4862_a3ee_7f300059ab6a4819bf38;
        CRACKME_742b3893_9680_4862_a3ee_7f300059ab6a445f18da.D\u0106Mv = CRACKME_742b3893_9680_4862_a3ee_7f300059ab6a5b066770;
        long l6 = CRACKME_9140807e_0df4_45f5_9fc3_50f175b70164_bb73c3b3;
        block18: while (true) {
            switch ((int)l6) {
                case -844459783: {
                    break block18;
                }
                case 117107753: {
                    l6 = (0xEC38760AE17A345EL ^ 0x1CD6C87DFB2DE41EL) / (0x872759D7FCBAA086L ^ 0x7E52C2FA611DFE66L);
                    continue block18;
                }
            }
            break;
        }
        CRACKME_742b3893_9680_4862_a3ee_7f300059ab6a445f18da.\u01063ep = CRACKME_742b3893_9680_4862_a3ee_7f300059ab6adf6bd545;
    }
}
