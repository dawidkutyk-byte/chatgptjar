/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal.bind;

import java.io.IOException;
import java.io.Reader;

static final class JsonTreeReader.1
extends Reader {
    @Override
    public int read(char[] buffer, int offset, int count) throws IOException {
        throw new AssertionError();
    }

    JsonTreeReader.1() {
    }

    @Override
    public void close() throws IOException {
        throw new AssertionError();
    }
}
