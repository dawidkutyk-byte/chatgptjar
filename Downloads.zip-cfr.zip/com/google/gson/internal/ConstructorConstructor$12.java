/*
 * Decompiled with CFR 0.152.
 */
package com.google.gson.internal;

import com.google.gson.internal.ObjectConstructor;
import java.util.LinkedHashMap;

class ConstructorConstructor.12
implements ObjectConstructor<T> {
    @Override
    public T construct() {
        return new LinkedHashMap();
    }

    ConstructorConstructor.12() {
    }
}
