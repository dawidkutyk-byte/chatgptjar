/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  0QZ8
 *  e4wV
 *  ev\u0118\u0118
 *  org.bukkit.Color
 *  org.bukkit.FireworkEffect
 *  org.bukkit.FireworkEffect$Type
 *  org.bukkit.Sound
 *  org.bukkit.entity.Firework
 *  org.bukkit.entity.Player
 *  org.bukkit.scheduler.BukkitRunnable
 *  \u015b\u0106\u0179G
 */
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.Sound;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

class 9qHE
extends BukkitRunnable {
    private static String[] CRACKME_BITCH = new String[15];
    static long CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32 = -171268085527770530L;
    final /* synthetic */ \u015b\u0106\u0179G \u0141Tj\u0143;

    static {
        9qHE.CRACKME_BITCH[0] = "\u2282_\u30fd";
        9qHE.CRACKME_BITCH[1] = "\u3000 \uff3c\uff3c\u3000\u3000\u3000";
        9qHE.CRACKME_BITCH[2] = "\u3000\u3000 \uff3c( \u0361\u00b0 \u035c\u0296 \u0361\u00b0)\u3000\u3000\u3000";
        9qHE.CRACKME_BITCH[3] = "\u3000\u3000\u3000 >\u3000\u2312\u30fd\u3000\u3000\u3000";
        9qHE.CRACKME_BITCH[4] = "\u3000\u3000\u3000/ \u3000 \u3078\uff3c\u3000\u3000\u3000";
        9qHE.CRACKME_BITCH[5] = "\u3000\u3000 /\u3000\u3000/\u3000\uff3c\uff3c\u3000\u3000\u3000";
        9qHE.CRACKME_BITCH[6] = "\u3000\u3000 \uff9a\u3000\u30ce\u3000\u3000 \u30fd_\u3064\u3000\u3000\u3000";
        9qHE.CRACKME_BITCH[7] = "\u3000\u3000/\u3000/\u3000\u3000\u3000";
        9qHE.CRACKME_BITCH[8] = "\u3000 /\u3000/|\u3000\u3000\u3000";
        9qHE.CRACKME_BITCH[9] = "\u3000(\u3000(\u30fd\u3000\u3000\u3000";
        9qHE.CRACKME_BITCH[10] = "\u3000|\u3000|\u3001\uff3c\u3000\u3000\u3000";
        9qHE.CRACKME_BITCH[11] = "\u3000| \u4e3f \uff3c \u2312)\u3000\u3000\u3000";
        9qHE.CRACKME_BITCH[12] = "\u3000| |\u3000\u3000) /\u3000\u3000\u3000";
        9qHE.CRACKME_BITCH[13] = "\u30ce )\u3000\u3000L\uff89\u3000\u3000\u3000";
        9qHE.CRACKME_BITCH[14] = "(_\uff0f\u3000\u3000\u3000\u3000\u3000\u3000";
    }

    /*
     * Unable to fully structure code
     */
    private /* synthetic */ void pno956YP3E8ebC8D(Player var1_1) {
        if (9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32 == (2861862301224042148L ^ 7897968575028492809L)) {
            v0 = 1442366884 ^ 705116763;
            if ((-344460876 >>> "\u0000\u0000".length() ^ v0) != 0) {
                -1185932570 ^ -1185932569;
            }
        } else {
            173005722 ^ 173005722;
        }
        var6_2 = new byte[-1815737457 ^ -1815737459];
        v1 = 866822740 ^ 0x33AAAA55;
        var6_2[v1] = 1693918428 ^ 1693918394;
        var6_2[-1102060515 ^ -1102060515] = -1023143726 ^ -1023143692;
        v2 = new StringBuilder().append(new String(var6_2, "UTF-8"));
        v3 = CRACKME_69beff4f_259e_4f50_a8ee_0688d3af433d22b5a256.\u0141Tj\u0143.oHuF;
        while (true) {
            block107: {
                if ((v4 = (cfr_temp_0 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32 - (7908023410543515102L ^ 4176282086954408349L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v4 != (1020194194 ^ -1020194195)) break block107;
                v5 = v2.append(e4wV.i26U-7u6v6ccWsho((String)v3));
                v6 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32;
                if (true) ** GOTO lbl39
            }
            v4 = -810037611 - -1684283039;
        }
        block71: while (true) {
            v6 = (3553320076660198368L ^ 2407580739536244658L) / v7;
lbl39:
            // 2 sources

            switch ((int)v6) {
                case 1757514334: {
                    break block71;
                }
                case 2086359860: {
                    v7 = 7129495815954862521L - -6541256309301505830L;
                    continue block71;
                }
            }
            break;
        }
        v8 = v5.toString();
        while (true) {
            if ((v9 = (cfr_temp_1 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32 - (-2841179031254386419L ^ 5034145806679781252L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v9 == (787441100 ^ 787441101)) break;
            v9 = 1147449876 - -897728985;
        }
        v10 = 0QZ8.1d9kfLKTTP4TVZYm((String)v8);
        var6_2 = new byte[-27564485 ^ -27564504];
        v11 = 365552614 ^ 365552631;
        var6_2[v11] = 1632435248 ^ 1632435292;
        var6_2[-366056698 ^ -366056690] = 1202690154 ^ 1202690052;
        var6_2[-322363268 ^ -322363265] = 280775801 ^ 280775690;
        var6_2[1797774469 ^ 1797774487] = 838412714 ^ 838412683;
        var6_2[650044448 ^ 650044464] = 2104685006 ^ 2104684971;
        var6_2[-1272631024 ^ -1272631011] = -649518149 ^ -649518124;
        var6_2[1241826909 ^ 1241826904] = 855578568 ^ -855578612;
        var6_2[1762727121 ^ 1762727135] = -601609131 ^ -601609099;
        v12 = -567999935 ^ -567999897;
        var6_2[-1850380420 ^ -1850380420] = v12;
        var6_2[1473820332 ^ 1473820325] = -1303803054 ^ -1303803077;
        v13 = -1816071851 ^ -1816071854;
        var6_2[v13] = 1403941581 ^ 1403941546;
        var6_2[-1326681896 ^ -1326681901] = 1454952755 - 1454952858;
        v14 = -1401808906 ^ -1401808902;
        var6_2[v14] = 388867025 ^ 388866981;
        var6_2[1160415926 ^ 1160415927] = -933738382 ^ -933738477;
        var6_2[387934793 ^ 387934797] = -111064639 ^ -111064664;
        var6_2[-1843346022 ^ -1843346020] = -699853318 ^ 699853439;
        var6_2[-577687572 ^ -577687578] = -1486001201 - -1486001141;
        v15 = 786982010 ^ 786982005;
        v16 = 1224219443 ^ 1224219472;
        var6_2[v15] = v16;
        v17 = -1264223472 ^ -1264223470;
        var6_2[v17] = 684532253 ^ 684532306;
        v18 = 0QZ8.1d9kfLKTTP4TVZYm((String)new String(var6_2, "UTF-8"));
        v19 = 21299602 ^ 21299602;
        while (true) {
            block108: {
                v20 = 2839471290450982181L ^ 6366701739246405763L;
                cfr_temp_2 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32 - v20;
                v21 = cfr_temp_2 == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1);
                if (v21 == false) continue;
                v22 = -888681704 ^ 888681703;
                if (v21 != v22) break block108;
                CRACKME_69beff4f_259e_4f50_a8ee_0688d3af433d3c2f9cfe.sendTitle(v10, v18, v19, -307413052 ^ -307413115, 1698305246 ^ 1698305236);
                v23 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32;
                if (true) ** GOTO lbl109
            }
            v21 = -2050156240 ^ -1828891646;
        }
        block74: while (true) {
            v23 = v24 / (8544232759043187935L ^ -530497769832162683L);
lbl109:
            // 2 sources

            switch ((int)v23) {
                case 520455585: {
                    v24 = 4006565814016511541L - -8969745220195141099L;
                    continue block74;
                }
                case 875674895: {
                    v24 = 2159285346270762105L - -8208839754802205667L;
                    continue block74;
                }
                case 1243081663: {
                    v24 = -258053015328271237L - 7214119927220379576L;
                    continue block74;
                }
                case 1757514334: {
                    break block74;
                }
            }
            break;
        }
        v25 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32;
        if (true) ** GOTO lbl125
        block75: while (true) {
            v25 = v26 / (8469771780399397417L - -7344568276211946340L);
lbl125:
            // 2 sources

            switch ((int)v25) {
                case -1613008773: {
                    v26 = -4923217139978292338L - 1067577689824579463L;
                    continue block75;
                }
                case 967120277: {
                    v26 = 3521929201707116681L - -6332402899116302120L;
                    continue block75;
                }
                case 1757514334: {
                    break block75;
                }
                case 1879539470: {
                    v26 = -820558887135119842L ^ -1332917391850475109L;
                    continue block75;
                }
            }
            break;
        }
        var6_2 = new byte[-2030656491 ^ -2030656449];
        var6_2[-908764266 ^ -908764260] = 112505147 ^ 112505181;
        var6_2[467390517 ^ 467390517] = 2026882652 ^ 2026882599;
        var6_2[-1960477305 ^ -1960477284] = -899058147 ^ -899058054;
        v27 = 1580209900 ^ 1580209907;
        v28 = -1477713850 ^ 1477713887;
        var6_2[v27] = v28;
        var6_2[1509099091 ^ 1509099072] = -932307376 ^ -932307344;
        var6_2[671744814 ^ 671744778] = -1369980311 ^ -1369980404;
        var6_2[1995547182 ^ 1995547181] = 564670802 ^ 564670759;
        var6_2[911991429 ^ 911991433] = 1610131142 ^ 1610131134;
        var6_2[762067737 ^ 762067715] = 1338449272 ^ -1338449155;
        v29 = -722749046 ^ -722749012;
        var6_2[2068012294 ^ 2068012306] = v29;
        v30 = -2085480613 ^ -2085480579;
        var6_2[763630388 ^ 763630395] = v30;
        var6_2[462946517 ^ 462946515] = -100766930 ^ -100766912;
        var6_2[926802950 ^ 926802977] = -197374623 ^ -197374655;
        var6_2[-1494764364 ^ -1494764363] = 1326387386 ^ 1326387402;
        var6_2[-1817671545 ^ -1817671531] = 1280088028 ^ 1280088034;
        v31 = -1571759551 ^ -1571759493;
        var6_2[-1622235971 ^ -1622236005] = v31;
        v32 = -1880014295 ^ -1880014284;
        var6_2[v32] = -195533543 ^ -195533456;
        v33 = 1653052588 ^ 1653052590;
        var6_2[v33] = 1054041588 ^ 1054041496;
        var6_2[1440301287 ^ 1440301292] = 1971644720 ^ 1971644761;
        var6_2[-554020977 ^ -554020961] = -818269512 ^ -818269568;
        v34 = -585653674 ^ -585653689;
        v35 = 1262026676 ^ 1262026634;
        var6_2[v34] = v35;
        var6_2[-120452714 ^ -120452719] = 2038762958 ^ 2038762910;
        var6_2[-1351233833 ^ -1351233794] = 1197759432 ^ 1197759402;
        v36 = 1700887432 ^ 1700887437;
        var6_2[v36] = 1228232028 ^ 1228231989;
        var6_2[691322106 ^ 691322075] = 1864010187 ^ 1864010148;
        var6_2[-1928453151 ^ -1928453137] = 1988629354 ^ 1988629322;
        var6_2[-485776675 ^ -485776693] = -1399066513 ^ -1399066592;
        v37 = 269595907 ^ 269596023;
        var6_2[1928078028 ^ 1928078060] = v37;
        var6_2[-257630902 ^ -257630890] = 885782511 ^ 885782401;
        v38 = 675294548 ^ 675294582;
        var6_2[v38] = 1305640354 ^ 1305640322;
        v39 = 1975854931 ^ 1975854942;
        var6_2[v39] = -937763232 ^ -937763299;
        v40 = -613620591 ^ -613620510;
        var6_2[1659899611 ^ 1659899596] = v40;
        v41 = 126843051 ^ 126843084;
        var6_2[170949663 ^ 170949659] = v41;
        var6_2[-887512383 ^ -887512359] = -1593852421 ^ -1593852526;
        var6_2[1583720015 ^ 1583720017] = 1250864051 ^ -1250864009;
        var6_2[-1932746204 ^ -1932746228] = -678284822 ^ -678284852;
        v42 = -131897312 ^ -131897291;
        var6_2[v42] = 785936366 ^ 785936271;
        var6_2[168626148 ^ 168626113] = -1827769711 ^ -1827769603;
        var6_2[935849804 ^ 935849839] = 677939981 ^ 677940078;
        var6_2[-1318727357 ^ -1318727334] = 632829411 ^ -632829401;
        v43 = 1605078212 ^ 1605078221;
        v44 = -1250908447 ^ -1250908540;
        var6_2[v43] = v44;
        v45 = 1638551555 ^ 1638551665;
        var6_2[-1834233088 ^ -1834233080] = v45;
        v46 = new StringBuilder().append(new String(var6_2, "UTF-8"));
        v47 = CRACKME_69beff4f_259e_4f50_a8ee_0688d3af433d22b5a256.\u0141Tj\u0143;
        while (true) {
            block109: {
                v48 = -6800159699601271759L ^ -2789852150087696856L;
                cfr_temp_3 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32 - v48;
                v49 = cfr_temp_3 == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1);
                if (v49 == false) continue;
                if (v49 != (1275348697 ^ -1275348698)) break block109;
                v50 = v47.oHuF;
                v51 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32;
                if (true) ** GOTO lbl223
            }
            v49 = 1459257808 ^ 1932697555;
        }
        block77: while (true) {
            v52 = -1339467087782533838L ^ 9172944777197433401L;
            v51 = v53 / v52;
lbl223:
            // 2 sources

            switch ((int)v51) {
                case -1446903643: {
                    v53 = -2523322415891974576L - 229998651949114680L;
                    continue block77;
                }
                case -925170397: {
                    v53 = 5442988894771145050L ^ 2646553515721408851L;
                    continue block77;
                }
                case 1268326319: {
                    v53 = -4328843437334346246L ^ -8005738447922806396L;
                    continue block77;
                }
                case 1757514334: {
                    break block77;
                }
            }
            break;
        }
        v54 = v46.append(v50);
        var6_2 = new byte[-118824947 ^ -118824945];
        var6_2[833905053 ^ 833905053] = -2107121115 ^ -2107121147;
        var6_2[-916471333 ^ -916471334] = 1331957118 ^ 1331957078;
        v55 = new String(var6_2, "UTF-8");
        while (true) {
            v56 = -778741316635501998L ^ 2820575730199246852L;
            cfr_temp_4 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32 - v56;
            v57 = cfr_temp_4 == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1);
            if (v57 == false) continue;
            if (v57 == (1846757667 ^ 1846757666)) break;
            v57 = 314917789 - 1178345462;
        }
        v58 = v54.append(v55);
        v59 = 1596059517 - 1075553138;
        v60 = CRACKME_69beff4f_259e_4f50_a8ee_0688d3af433d22b5a256.\u0141Tj\u0143;
        while (true) {
            if ((v61 = (cfr_temp_5 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32 - (4998993036850325029L ^ -3917936072252473858L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v61 == (-686312688 ^ -686312687)) break;
            v61 = 709658318 - 59254825;
        }
        v62 = ev\u0118\u0118.QTdQCbdTbgmW7EUx((double)v60.\u0144U\u0179f);
        while (true) {
            if ((v63 = (cfr_temp_6 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32 - (476517276101127364L ^ -6321453287529211572L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v63 == (1353508673 ^ 1353508672)) break;
            v63 = -404841379 ^ -835763240;
        }
        var6_2 = new byte[-1580467067 ^ -1580467068];
        v64 = -162314735 ^ -162314735;
        var6_2[v64] = 1965887698 ^ 1965887741;
        v65 = v58.append(v62).append(new String(var6_2, "UTF-8"));
        v66 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32;
        block81: while (true) {
            switch ((int)v66) {
                case -472686326: {
                    v66 = (1756222230723078792L ^ -5400737612247751043L) / (-7447068625291137093L - -3148309932089812353L);
                    continue block81;
                }
                case 1757514334: {
                    break block81;
                }
            }
            break;
        }
        v67 = CRACKME_69beff4f_259e_4f50_a8ee_0688d3af433d22b5a256.\u0141Tj\u0143;
        while (true) {
            if ((v68 = (cfr_temp_7 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32 - (-1299501855920092066L ^ -350738608429768059L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
            v69 = -1373686575 ^ 1373686574;
            if (v68 == v69) break;
            v68 = 39229453 - -198952307;
        }
        v70 = v67.wYe\u0143;
        v71 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32;
        block83: while (true) {
            switch ((int)v71) {
                case 21662631: {
                    v71 = (2819517337124889996L ^ -5896095015859045954L) / (4422311220973183615L - 3057133471311871664L);
                    continue block83;
                }
                case 1757514334: {
                    break block83;
                }
            }
            break;
        }
        v72 = ev\u0118\u0118.QTdQCbdTbgmW7EUx((double)v70);
        v73 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32;
        block84: while (true) {
            switch ((int)v73) {
                case 226659557: {
                    v73 = (3381911696549695939L - 755905462044303498L) / (-6822084723540924451L ^ -1127568308336949266L);
                    continue block84;
                }
                case 1757514334: {
                    break block84;
                }
            }
            break;
        }
        v74 = v65.append(v72);
        v75 = -1090217174 ^ -1090217170;
        var6_2 = new byte[v75];
        v76 = -596228283 ^ -596228253;
        var6_2[2039279017 ^ 2039279016] = v76;
        var6_2[-1210029010 ^ -1210029010] = -284452366 ^ -284452389;
        var6_2[-1884377917 ^ -1884377919] = 1779008871 ^ 1779008774;
        var6_2[2056671629 ^ 2056671630] = 742148147 ^ 742148114;
        v77 = new String(var6_2, "UTF-8");
        while (true) {
            if ((v78 = (cfr_temp_8 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32 - (4331127310423377991L ^ -6327387079920120832L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
            v79 = 417873297 ^ 417873296;
            if (v78 == v79) break;
            v78 = 157116798 ^ -1139407036;
        }
        v80 = v74.append(v77);
        while (true) {
            if ((v81 = (cfr_temp_9 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32 - (222461133033468900L - 5053442925582569553L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
            if (v81 == (745085039 ^ 745085038)) break;
            v81 = -126500283 ^ 55423797;
        }
        v82 = 0QZ8.1d9kfLKTTP4TVZYm((String)v80.toString());
        while (true) {
            if ((v83 = (cfr_temp_10 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32 - (-4607998313366457765L ^ -3371305354200001448L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
            if (v83 == (-546590155 ^ 546590154)) break;
            v83 = -352736007 - 880772158;
        }
        CRACKME_69beff4f_259e_4f50_a8ee_0688d3af433d3c2f9cfe.sendMessage(v82);
        v84 = CRACKME_69beff4f_259e_4f50_a8ee_0688d3af433d3c2f9cfe.getLocation();
        while (true) {
            if ((v85 = (cfr_temp_11 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32 - (-19194761720780362L - 3350160840042586391L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
            if (v85 == (-552369182 ^ -552369181)) break;
            v85 = -777817328 - 1675402348;
        }
        v86 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32;
        block89: while (true) {
            switch ((int)v86) {
                case -2123231910: {
                    v86 = (-5942454749085774014L ^ -794692945795228039L) / (7976633098662653519L - -788855406210491119L);
                    continue block89;
                }
                case 1757514334: {
                    break block89;
                }
            }
            break;
        }
        CRACKME_69beff4f_259e_4f50_a8ee_0688d3af433d3c2f9cfe.playSound(v84, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 5.0f, 1.0f);
        while (true) {
            block110: {
                if ((v87 = (cfr_temp_12 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32 - (802927660922334036L ^ 8618697596563583668L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
                if (v87 != (1635064213 ^ -1635064214)) break block110;
                CRACKME_69beff4f_259e_4f50_a8ee_0688d3af433dcb3f9464 = CRACKME_69beff4f_259e_4f50_a8ee_0688d3af433d3c2f9cfe.getLocation();
                v88 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32;
                if (true) ** GOTO lbl369
            }
            v87 = -1411731296 ^ 526726719;
        }
        block91: while (true) {
            v88 = v89 / (4196525480500036850L ^ 6414594171468967969L);
lbl369:
            // 2 sources

            switch ((int)v88) {
                case 111248418: {
                    v89 = -3534880356749615684L ^ 7384150570032150741L;
                    continue block91;
                }
                case 548195103: {
                    v89 = 2676686432973775610L ^ -1843757677128170495L;
                    continue block91;
                }
                case 1430234575: {
                    v89 = -7492438009629454884L - 4748314082784033763L;
                    continue block91;
                }
                case 1757514334: {
                    break block91;
                }
            }
            break;
        }
        v90 = CRACKME_69beff4f_259e_4f50_a8ee_0688d3af433d3c2f9cfe.getWorld();
        while (true) {
            v91 = -142574060971271708L >>> "\u0000\u0000".length();
            cfr_temp_13 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32 - v91;
            v92 = cfr_temp_13 == 0L ? 0 : (cfr_temp_13 < 0L ? -1 : 1);
            if (v92 == false) continue;
            if (v92 == (-1787982888 ^ 1787982887)) break;
            v92 = 856416817 ^ -1035146919;
        }
        CRACKME_69beff4f_259e_4f50_a8ee_0688d3af433da253b849 = (Firework)v90.spawn(CRACKME_69beff4f_259e_4f50_a8ee_0688d3af433dcb3f9464, Firework.class);
        v93 = 485073832 ^ -939448652;
        CRACKME_69beff4f_259e_4f50_a8ee_0688d3af433d02035380 = CRACKME_69beff4f_259e_4f50_a8ee_0688d3af433da253b849.getFireworkMeta();
        while (true) {
            block111: {
                if ((v94 = (cfr_temp_14 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32 - (-4343548494416252227L ^ -7558871694131632956L)) == 0L ? 0 : (cfr_temp_14 < 0L ? -1 : 1)) == false) continue;
                if (v94 != (-1246318985 ^ 1246318984)) break block111;
                CRACKME_69beff4f_259e_4f50_a8ee_0688d3af433d02035380.setPower(1399636155 ^ 1399636155);
                v95 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32;
                if (true) ** GOTO lbl420
            }
            v94 = 1883903263 - 1878702699;
        }
        block94: while (true) {
            v95 = v96 / (-9170032218341737262L - 7310194034595592872L);
lbl420:
            // 2 sources

            switch ((int)v95) {
                case -1196154135: {
                    v96 = 277174117905839199L ^ -7808194743317078299L;
                    continue block94;
                }
                case 1757514334: {
                    break block94;
                }
                case 1849857087: {
                    v96 = -2493491752324696393L ^ -608226613979617783L;
                    continue block94;
                }
            }
            break;
        }
        v97 = FireworkEffect.builder();
        v98 = new Color[286735581 ^ 286735582];
        v99 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32;
        if (true) ** GOTO lbl443
        block95: while (true) {
            v99 = v100 / (8520493719218494136L ^ -8439755158842316307L);
lbl443:
            // 2 sources

            switch ((int)v99) {
                case 867794005: {
                    v100 = 6292752332455406038L - 6661885809598916909L;
                    continue block95;
                }
                case 1757514334: {
                    break block95;
                }
            }
            break;
        }
        v98[1279892830 ^ 1279892830] = Color.GREEN;
        v101 = -1356956920 ^ -1356956919;
        while (true) {
            if ((v102 = (cfr_temp_15 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32 - (-9013632568746885214L ^ -4551179286759747717L)) == 0L ? 0 : (cfr_temp_15 < 0L ? -1 : 1)) == false) continue;
            if (v102 == (853678586 ^ -853678587)) break;
            v102 = 987018240 ^ -513445855;
        }
        v98[v101] = Color.LIME;
        1571583985 ^ 1841393501;
        v98[-1954241857 ^ -1954241859] = Color.WHITE;
        while (true) {
            if ((v103 = (cfr_temp_16 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32 - (-8595443767273860600L - -2075159304226163991L)) == 0L ? 0 : (cfr_temp_16 < 0L ? -1 : 1)) == false) continue;
            if (v103 == (-406037581 ^ -406037582)) break;
            v103 = -1384927516 >>> "\u0000\u0000".length();
        }
        v104 = v97.withColor(v98);
        while (true) {
            block112: {
                if ((v105 = (cfr_temp_17 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32 - (-2618389404802991236L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_17 < 0L ? -1 : 1)) == false) continue;
                if (v105 != (-437162713 ^ 437162712)) break block112;
                v106 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32;
                if (true) ** GOTO lbl493
            }
            v105 = -1318110808 >>> "\u0000\u0000".length();
        }
        block99: while (true) {
            v106 = v107 / (414709935587046267L ^ 4920538769553236858L);
lbl493:
            // 2 sources

            switch ((int)v106) {
                case 546257539: {
                    v107 = -8236633467930910439L - 3849726974656466531L;
                    continue block99;
                }
                case 665563986: {
                    v107 = -3366795097621002024L ^ 3446258771096318903L;
                    continue block99;
                }
                case 1757514334: {
                    break block99;
                }
                case 1928059288: {
                    v107 = 6953374576301844188L - -6066744601827082840L;
                    continue block99;
                }
            }
            break;
        }
        v108 = v104.with(FireworkEffect.Type.BALL);
        v109 = 1736449458 - 1358425574;
        while (true) {
            block113: {
                if ((v110 = (cfr_temp_18 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32 - (-1034024731689210263L - 5432285691071805560L)) == 0L ? 0 : (cfr_temp_18 < 0L ? -1 : 1)) == false) continue;
                if (v110 != (210353207 ^ 210353206)) break block113;
                v111 = v108.trail((boolean)(831183976 ^ 831183977));
                v112 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32;
                if (true) ** GOTO lbl520
            }
            v110 = 1882468193 ^ -1050465915;
        }
        block101: while (true) {
            v112 = v113 / (-7111291440794141296L ^ 6603363312668832476L);
lbl520:
            // 2 sources

            switch ((int)v112) {
                case -1709083149: {
                    v113 = -6759061115704333146L ^ -2608076551047801465L;
                    continue block101;
                }
                case 1757514334: {
                    break block101;
                }
                case 1808591381: {
                    v113 = 6240966770223789616L ^ 4371358951024696417L;
                    continue block101;
                }
            }
            break;
        }
        v114 = v111.flicker((boolean)(-814328895 ^ -814328896));
        v115 = -953996961 ^ -1565271760;
        v116 = -640836185 ^ -1464228419;
        while (true) {
            block114: {
                if ((v117 = (cfr_temp_19 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32 - (39243843073223482L ^ -3455318666215818265L)) == 0L ? 0 : (cfr_temp_19 < 0L ? -1 : 1)) == false) continue;
                if (v117 != (803471887 ^ 803471886)) break block114;
                1308793155 - -1512332231;
                -955826746 - 119154374;
                CRACKME_69beff4f_259e_4f50_a8ee_0688d3af433d02035380.addEffect(v114.build());
                v118 = 9qHE.CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32;
                if (true) ** GOTO lbl559
            }
            v117 = 1651438908 ^ -126528301;
        }
        block103: while (true) {
            v118 = v119 / (3788448200436048178L ^ -5779646176842361511L);
lbl559:
            // 2 sources

            switch ((int)v118) {
                case 588536730: {
                    v119 = -8433119441940896512L >>> "\u0000\u0000".length();
                    continue block103;
                }
                case 888101092: {
                    v119 = 6193932198307945052L >>> "\u0000\u0000".length();
                    continue block103;
                }
                case 985541205: {
                    v119 = 2736465495059123437L ^ -3112796757903426571L;
                    continue block103;
                }
                case 1757514334: {
                    break block103;
                }
            }
            break;
        }
        CRACKME_69beff4f_259e_4f50_a8ee_0688d3af433da253b849.setFireworkMeta(CRACKME_69beff4f_259e_4f50_a8ee_0688d3af433d02035380);
    }

    /*
     * Exception decompiling
     */
    public void run() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 35[SWITCH]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doClass(Driver.java:84)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:78)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompile(CFRDecompiler.java:89)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompileToZip(CFRDecompiler.java:133)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.decompileSaveAll(ResourceDecompiling.java:261)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.lambda$decompileSaveAll$0(ResourceDecompiling.java:111)
         *     at java.base/java.lang.Thread.run(Thread.java:1575)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private static /* synthetic */ void brXT9P_tmhGYkyXw(Player player) {
        if (CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32 == (-5176796048245971420L == -5176796048245971419L ? -6308718197189001748L : 0x2228129CD2E188F8L ^ 0x1CC449C2D40D80F7L)) {
            if ((1321325646 - 1196892526 ^ (0xD9F63DDB ^ 0xA609C224)) != 0) {
                int cfr_ignored_2 = 0x887B3009 ^ 0x887B3008;
            }
        } else {
            int cfr_ignored_3 = 0x12241DC8 ^ 0x12241DC8;
        }
        int cfr_ignored_4 = 1798217060 >>> "\u0000\u0000".length();
        int cfr_ignored_5 = -1271583383 - -656395887;
        byte[] byArray = new byte[0xD82980CC ^ 0xD82980FE];
        byArray[0x26F5ECE8 ^ 0x26F5ECFC] = 0x145F0BA ^ 0x145F09C;
        byArray[-1523111728786703891L == -1523111728786703890L ? 1307009374 : 0x9A526E2A ^ 0x9A526E03] = 2991943302986053315L == 2991943302986053316L ? 344442324 : 0xF8B5842A ^ 0xF8B5844F;
        byArray[0x4F5236E ^ 0x4F52369] = 0xE525DA8B ^ 0xE525DADB;
        byArray[0x8FA9848D ^ 0x8FA98496] = 0xC87EF6E1 ^ 0xC87EF684;
        byArray[0xB532232E ^ 0xB532232B] = 0xEF4336DE ^ 0xEF4336B7;
        byArray[873555584515811318L == 873555584515811319L ? 1079927713 : 0xC861AEDD ^ 0xC861AEC7] = 9092128337882830946L == 9092128337882830947L ? 1597378576 : 0x91D8F90D ^ 0x91D8F977;
        byArray[0x1C35E187 ^ 0x1C35E195] = 0x821974F6 ^ 0x821974C8;
        byArray[0x81AB93C7 ^ 0x81AB93E7] = 0xD49C4667 ^ 0xD49C4608;
        byArray[0xF69C13BE ^ 0xF69C1391] = 0xC5164694 ^ 0xC51646F8;
        byArray[0xA37FA530 ^ 0xA37FA536] = 0xE6E67F42 ^ 0xE6E67F2C;
        byArray[-5401379484694930400L == -5401379484694930399L ? 2039915160 : 0xCEDB3602 ^ 0xCEDB360A] = 0x1063411F ^ 0x1063416D;
        byArray[0xB8915565 ^ 0xB8915567] = 0xFE97CA5E ^ 0xFE97CA32;
        byArray[0x49BA3F85 ^ 0x49BA3F84] = 0xD5C90C19 ^ 0xD5C90C69;
        byArray[-8252607537006959101L == -8252607537006959100L ? -141696948 : 0x4C6D3010 ^ 0x4C6D301C] = 4048145995613367410L == 4048145995613367411L ? 300154021 : 0x627E4895 ^ 0x627E48ED;
        byArray[-3507336056890414850L == -3507336056890414849L ? -579412296 : 0xD19352D9 ^ 0xD19352F5] = 0x5CE73DD ^ 0x5CE73FD;
        byArray[0xF25D8E73 ^ 0xF25D8E55] = 0x5507424B ^ 0x55074227;
        byArray[0x564CD299 ^ 0x564CD28F] = -3916579720019984491L == -3916579720019984490L ? -1547019079 : 0x1F6EC85A ^ 0x1F6EC814;
        byArray[0xCAEC14C4 ^ 0xCAEC14C7] = 617786959079129682L == 617786959079129683L ? 1901301682 : 0x1F438BE3 ^ 0x1F438B96;
        byArray[0x4AA337FF ^ 0x4AA337EF] = 0x60530196 ^ 0x605301AE;
        byArray[0x9BF991E ^ 0x9BF993B] = -7164580183147737510L == -7164580183147737509L ? -1662176514 : 0x14D63972 ^ 0x14D63913;
        byArray[-403666291918710332L == -403666291918710331L ? 1271895312 : 0x4499BEB9 ^ 0x4499BE98] = 7517028984924681609L == 7517028984924681610L ? 375720442 : 0x2A0A1A2F ^ 0x2A0A1A0F;
        byArray[0x7B6A24EF ^ 0x7B6A24C5] = 5557847012192538981L == 5557847012192538982L ? 1188402182 : 0xCFD58C12 ^ 0xCFD58C75;
        byArray[0x8E62C071 ^ 0x8E62C06E] = 5440967980646566474L == 5440967980646566475L ? -442923904 : 0x2D382B5C ^ 0x2D382B32;
        byArray[-5629527453809096938L == -5629527453809096937L ? 365278967 : 0xB90F6E81 ^ 0xB90F6E8F] = 0xBC01115C ^ 0xBC01117C;
        byArray[0xC178F0E5 ^ 0xC178F0E5] = 0x3BD31FA3 ^ 0x3BD31FD8;
        byArray[0x6CD9B190 ^ 0x6CD9B1A0] = 0x1D2486CD ^ 0x1D2486B8;
        byArray[0xE2BCBC0E ^ 0xE2BCBC25] = 0x45DC3D34 ^ 0x45DC3D5B;
        byArray[0xB9415E3B ^ 0xB9415E15] = 0x60A89E55 ^ 0x60A89E30;
        byArray[0xB47CF957 ^ 0xB47CF97F] = 0x47F16B54 ^ 0x47F16B3A;
        byArray[0x44BC8A87 ^ 0x44BC8AA0] = 0xAFD95B75 ^ 0xAFD95B1A;
        byArray[0xBB3EC353 ^ 0xBB3EC357] = 0x6BB13CA4 ^ 0x6BB13CC3;
        byArray[0xB5E8B226 ^ 0xB5E8B23B] = 0x157EA3EE ^ 0x157EA39C;
        byArray[0x10B6FAD2 ^ 0x10B6FAC5] = -1734018262833950883L == -1734018262833950882L ? 32349961 : 0x50782E06 ^ 0x50782E6F;
        byArray[0x3B9B272E ^ 0x3B9B2725] = 0xD0F24268 ^ 0xD0F24201;
        byArray[-7427235091284657206L == -7427235091284657205L ? -348565733 : 0x421137DA ^ 0x421137C6] = 0xEDE01C1 ^ 0xEDE01A3;
        byArray[0xAC5D7DA0 ^ 0xAC5D7D84] = 0xF2DED53D ^ 0xF2DED549;
        byArray[0x76A2C65C ^ 0x76A2C66D] = 4069368094232644385L == 4069368094232644386L ? 1665615647 : 0xE48D112F ^ 0xE48D110E;
        byArray[0xF92DB3D ^ 0xF92DB2C] = 0x9E89E0A3 ^ 0x9E89E09D;
        byArray[0x63250460 ^ 0x63250473] = 0xFC3A2BAD ^ 0xFC3A2B8D;
        byArray[3714202253239221391L == 3714202253239221392L ? -1749443209 : 0x7DF44585 ^ 0x7DF4458A] = 0xE8F100CC ^ 0xE8F100EA;
        byArray[0x239F5F63 ^ 0x239F5F41] = 0x1B674D0E ^ 0x1B674D7B;
        byArray[0xDD12C637 ^ 0xDD12C622] = 0x2E73AFE0 ^ 0x2E73AF83;
        byArray[2883379675474659538L == 2883379675474659539L ? 1949549764 : 0x9FC522C7 ^ 0x9FC522E4] = 0x467F2201 ^ 0x467F2272;
        byArray[0x39F26ECD ^ 0x39F26EC7] = 0x22E74A11 ^ 0x22E74A77;
        byArray[0x649984A7 ^ 0x649984B9] = 0xB5FAFE1E ^ 0xB5FAFE7F;
        byArray[0x861814A9 ^ 0x861814B1] = 1842884938022811430L == 1842884938022811431L ? 113044878 : 0x963EA059 ^ 0x963EA03C;
        byArray[8458951412101813774L == 8458951412101813775L ? 1401614027 : 0x66697593 ^ 0x6669758A] = 0x4EE1F22A ^ 0x4EE1F20A;
        byArray[0x96B1217F ^ 0x96B12172] = 0x2B5A0A88 ^ 0x2B5A0AF5;
        byArray[-1450616203025873413L == -1450616203025873412L ? -1265257738 : 0xE22C767 ^ 0xE22C74A] = 0x865AE35D ^ 0x865AE33E;
        byArray[1463641364522955882L == 1463641364522955883L ? -1249562192 : 0x931FB54E ^ 0x931FB547] = 0x454835E6 ^ 0x45483583;
        String string = new String(byArray, "UTF-8");
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32 - (-4416439960778072799L - -40178082733057977L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x3AC91DFC ^ 0x3AC91DFD)) break;
            l2 = 0xF6A35D66 ^ 0x81F54943;
        }
        String string2 = 0QZ8.1d9kfLKTTP4TVZYm((String)string);
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32 - (0x12FE0EF5A3AF84CFL ^ 0x18E8F9DB1FDBBA2AL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l3 == (0x1D43A999 ^ 0xE2BC5666)) {
                Player CRACKME_4ac36dc6_4863_4a5a_bba0_5008a6337a656e333aba;
                CRACKME_4ac36dc6_4863_4a5a_bba0_5008a6337a656e333aba.sendMessage(string2);
                int cfr_ignored_6 = 2037931454 - -1487729049;
                return;
            }
            l3 = -1746237424 - -479439174;
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * WARNING - void declaration
     */
    9qHE(\u015b\u0106\u0179G \u015b\u0106\u0179G2) {
        9qHE CRACKME_8e2668fc_bc48_4acd_a8c7_f70d57a146da5b870d15;
        void CRACKME_8e2668fc_bc48_4acd_a8c7_f70d57a146dabb062e55;
        long l = 1493214516255067619L - 5729176851552994902L;
        if (CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32 == l) {
            int n = -89075756 - 2058407893;
            if ((0xD3D72159 ^ 0xB3A4696A ^ n) != 0) {
                int n2 = 0xA1D826F6 ^ 0xA1D826F7;
            }
        } else {
            int cfr_ignored_1 = 0xEA50FA9 ^ 0xEA50FA9;
        }
        CRACKME_8e2668fc_bc48_4acd_a8c7_f70d57a146da5b870d15.\u0141Tj\u0143 = CRACKME_8e2668fc_bc48_4acd_a8c7_f70d57a146dabb062e55;
        long l2 = CRACKME_897858a1_02e0_4a3d_928c_0fc24b3ea9e6_fb1b9b32;
        boolean bl = true;
        block5: while (true) {
            long l3;
            if (!bl || (bl = false) || !true) {
                l2 = l3 / (0x5AFAE2B68A5D2F5AL ^ 0x28D6E61A149497B2L);
            }
            switch ((int)l2) {
                case -1926443176: {
                    l3 = 0xF703489B3D7CCA99L ^ 0x8F9B15AE67C27B96L;
                    continue block5;
                }
                case -321183925: {
                    l3 = 0xDED3FA40E8C30277L ^ 0x3DABAA9AC878AEAL;
                    continue block5;
                }
                case 1757514334: {
                    break block5;
                }
            }
            break;
        }
    }
}
