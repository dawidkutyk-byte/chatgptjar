/*
 * Decompiled with CFR 0.152.
 */
import java.util.Map;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
class 5fEW {
    final Map<String, Object> n8l\u0143;
    final String 8\u00f3HI;
    protected static long CRACKME_a393e3c1_e63d_4425_b583_27e912605c7d_11064e58 = -262369270042436677L;
    private static String[] CRACKME_BITCH = new String[15];

    /*
     * WARNING - void declaration
     */
    5fEW(Map<String, Object> map, String string) {
        void CRACKME_d5172ce1_36a2_4490_9213_914b815c45ea0dce5b78;
        block11: {
            int n;
            block10: {
                if (CRACKME_a393e3c1_e63d_4425_b583_27e912605c7d_11064e58 == (0xF8FDD47560B3873DL ^ 0xD847B879241A91BL)) {
                    if (((-1404630380979038414L == -1404630380979038413L ? 1709503675 : -1778009619 - 1861780179) ^ 328623445 - -1818860202) != 0) {
                        int n2 = 875902129339818571L == 875902129339818572L ? -641124631 : 0x5FD80E7E ^ 0x5FD80E7F;
                    }
                } else {
                    int cfr_ignored_3 = 0x921FFA15 ^ 0x921FFA15;
                }
                while (true) {
                    long l;
                    long l2;
                    if ((l2 = (l = CRACKME_a393e3c1_e63d_4425_b583_27e912605c7d_11064e58 - (279689045125246218L - 1800661546774327155L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
                    if (l2 == (515561746826192073L == 515561746826192074L ? -2087031607 : 0xA2AE6214 ^ 0xA2AE6215)) {
                        5fEW CRACKME_d5172ce1_36a2_4490_9213_914b815c45ea72f4c327;
                        if (5031113232253311074L == 5031113232253311075L) {
                            break;
                        }
                        break block10;
                    }
                    l2 = 0x449934AE ^ 0xE99A758;
                }
                n = 1742886056;
                break block11;
            }
            n = 0xF1A3FC10 ^ 0x8ACA0D43;
        }
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = CRACKME_a393e3c1_e63d_4425_b583_27e912605c7d_11064e58 - (0x563B8597801697FEL ^ 0x3B03D211AE16D8DAL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l3 == (0xAD22CBB8 ^ 0x52DD3447)) break;
            l3 = 0x360D0FE0 ^ 0xBED66E10;
        }
        CRACKME_d5172ce1_36a2_4490_9213_914b815c45ea72f4c327.n8l\u0143 = CRACKME_d5172ce1_36a2_4490_9213_914b815c45ea0dce5b78;
        while (true) {
            long l;
            long l4;
            if ((l4 = (l = CRACKME_a393e3c1_e63d_4425_b583_27e912605c7d_11064e58 - (2780021511728362184L >>> "\u0000\u0000".length())) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l4 == 1117319096 - 1117319097) {
                void CRACKME_d5172ce1_36a2_4490_9213_914b815c45eab3a057a4;
                CRACKME_d5172ce1_36a2_4490_9213_914b815c45ea72f4c327.8\u00f3HI = CRACKME_d5172ce1_36a2_4490_9213_914b815c45eab3a057a4;
                return;
            }
            if (9055769268805453618L == 9055769268805453619L) {
                l4 = 848877869;
                continue;
            }
            l4 = 0x6C7E02C0 ^ 0x30234470;
        }
    }

    static {
        5fEW.CRACKME_BITCH[0] = "\u2282_\u30fd";
        5fEW.CRACKME_BITCH[1] = "\u3000 \uff3c\uff3c\u3000\u3000\u3000";
        5fEW.CRACKME_BITCH[2] = "\u3000\u3000 \uff3c( \u0361\u00b0 \u035c\u0296 \u0361\u00b0)\u3000\u3000\u3000";
        5fEW.CRACKME_BITCH[3] = "\u3000\u3000\u3000 >\u3000\u2312\u30fd\u3000\u3000\u3000";
        5fEW.CRACKME_BITCH[4] = "\u3000\u3000\u3000/ \u3000 \u3078\uff3c\u3000\u3000\u3000";
        5fEW.CRACKME_BITCH[5] = "\u3000\u3000 /\u3000\u3000/\u3000\uff3c\uff3c\u3000\u3000\u3000";
        5fEW.CRACKME_BITCH[6] = "\u3000\u3000 \uff9a\u3000\u30ce\u3000\u3000 \u30fd_\u3064\u3000\u3000\u3000";
        5fEW.CRACKME_BITCH[7] = "\u3000\u3000/\u3000/\u3000\u3000\u3000";
        5fEW.CRACKME_BITCH[8] = "\u3000 /\u3000/|\u3000\u3000\u3000";
        5fEW.CRACKME_BITCH[9] = "\u3000(\u3000(\u30fd\u3000\u3000\u3000";
        5fEW.CRACKME_BITCH[10] = "\u3000|\u3000|\u3001\uff3c\u3000\u3000\u3000";
        5fEW.CRACKME_BITCH[11] = "\u3000| \u4e3f \uff3c \u2312)\u3000\u3000\u3000";
        5fEW.CRACKME_BITCH[12] = "\u3000| |\u3000\u3000) /\u3000\u3000\u3000";
        5fEW.CRACKME_BITCH[13] = "\u30ce )\u3000\u3000L\uff89\u3000\u3000\u3000";
        5fEW.CRACKME_BITCH[14] = "(_\uff0f\u3000\u3000\u3000\u3000\u3000\u3000";
    }
}
