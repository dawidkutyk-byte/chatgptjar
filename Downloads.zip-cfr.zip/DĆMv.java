/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 *  org.bukkit.map.MapCanvas
 *  org.bukkit.map.MapRenderer
 *  org.bukkit.map.MapView
 */
import java.awt.Image;
import java.awt.image.BufferedImage;
import org.bukkit.entity.Player;
import org.bukkit.map.MapCanvas;
import org.bukkit.map.MapRenderer;
import org.bukkit.map.MapView;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class D\u0106Mv
extends MapRenderer {
    private static String[] CRACKME_BITCH = new String[14];
    private boolean HNBz;
    private final BufferedImage 7Tz7;
    static long CRACKME_8ff9b460_ef13_4221_a59e_08c0d1d540c5_400020da = 214226320187595674L;

    /*
     * WARNING - void declaration
     */
    public D\u0106Mv(BufferedImage bufferedImage) {
        void CRACKME_73f85277_f7fc_4f7b_8f95_ef821649fe9ece256e23;
        block8: {
            int n;
            block7: {
                D\u0106Mv CRACKME_73f85277_f7fc_4f7b_8f95_ef821649fe9e46d492cb;
                if (CRACKME_8ff9b460_ef13_4221_a59e_08c0d1d540c5_400020da == (5323246459600108172L == 5323246459600108173L ? 101443944855391013L : 0x60E47E8B1C8FDF5CL ^ 0x8AA71E81C82D9F58L)) {
                    if ((-449685124 - 1249239359 ^ (0x78966059 ^ 0x7699FA6)) != 0) {
                        int n2 = -5472194348546657100L == -5472194348546657099L ? -304486698 : 0xEA0D3BA1 ^ 0xEA0D3BA0;
                    }
                } else {
                    int cfr_ignored_2 = 0xD57F86E7 ^ 0xD57F86E7;
                }
                int n3 = 2317122976552977034L == 2317122976552977035L ? -668041580 : 985461541 - -830710864;
                while (true) {
                    long l;
                    long l2;
                    if ((l2 = (l = CRACKME_8ff9b460_ef13_4221_a59e_08c0d1d540c5_400020da - (8026444373078392457L == 8026444373078392458L ? -8463533402524866041L : -6998793455258728028L >>> "\u0000\u0000".length())) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
                    if (l2 == (0xBE2C1654 ^ 0x41D3E9AB)) break;
                    l2 = -335197161 - -2020821625;
                }
                while (true) {
                    long l;
                    long l3;
                    if ((l3 = (l = CRACKME_8ff9b460_ef13_4221_a59e_08c0d1d540c5_400020da - (0xDB312E07D0581494L ^ 0x42FE30FCEF001986L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
                    if (l3 == (0xDFA3751C ^ 0xDFA3751D)) {
                        CRACKME_73f85277_f7fc_4f7b_8f95_ef821649fe9e46d492cb.HNBz = 0x4EAFB916 ^ 0x4EAFB916;
                        if (-9054943572358294929L == -9054943572358294928L) {
                            break;
                        }
                        break block7;
                    }
                    l3 = 0x4C6BE5DD ^ 0xF72DD258;
                }
                n = 1618917352;
                break block8;
            }
            n = 1054259477 - 243316952;
        }
        CRACKME_73f85277_f7fc_4f7b_8f95_ef821649fe9e46d492cb.7Tz7 = CRACKME_73f85277_f7fc_4f7b_8f95_ef821649fe9ece256e23;
        int n = -1137849351783325182L == -1137849351783325181L ? 619046052 : -1653885312 >>> "\u0000\u0000".length();
    }

    static {
        D\u0106Mv.CRACKME_BITCH[0] = "\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u283f\u283f\u28bf\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff";
        D\u0106Mv.CRACKME_BITCH[1] = "\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u281b\u28a9\u28f4\u28f6\u28f6\u28f6\u28cc\u2819\u282b\u281b\u288b\u28ed\u28e4\u28e4\u28e4\u28e4\u2859\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff";
        D\u0106Mv.CRACKME_BITCH[2] = "\u28ff\u28ff\u28ff\u28ff\u28ff\u285f\u28a1\u28fe\u28ff\u283f\u28db\u28db\u28db\u28db\u28db\u2873\u2806\u28bb\u28ff\u28ff\u28ff\u283f\u283f\u2837\u284c\u283b\u28ff\u28ff\u28ff\u28ff";
        D\u0106Mv.CRACKME_BITCH[3] = "\u28ff\u28ff\u28ff\u28ff\u280f\u28f0\u28ff\u28ff\u28f4\u28ff\u28ff\u28ff\u287f\u281f\u281b\u281b\u2812\u2804\u28b6\u28f6\u28f6\u28fe\u287f\u2836\u2812\u2832\u280c\u28bb\u28ff\u28ff";
        D\u0106Mv.CRACKME_BITCH[4] = "\u28ff\u28ff\u280f\u28e1\u28a8\u28dd\u287b\u283f\u28ff\u289b\u28e9\u2875\u281e\u286b\u282d\u282d\u28ed\u282d\u2824\u2808\u282d\u2812\u28d2\u2829\u282d\u282d\u28cd\u2812\u2808\u281b";
        D\u0106Mv.CRACKME_BITCH[5] = "\u287f\u2881\u28fe\u28ff\u28f8\u28ff\u28ff\u28f7\u28ec\u2849\u2801\u2804\u2801\u2804\u2804\u2804\u2804\u2804\u2804\u28f6\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2880";
        D\u0106Mv.CRACKME_BITCH[6] = "\u28a1\u28fe\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28e7\u2840\u2804\u2804\u2804\u2804\u2804\u2804\u2880\u28e0\u28ff\u28e6\u28e4\u28c0\u28c0\u28c0\u28c0\u2804\u28e4\u28fe";
        D\u0106Mv.CRACKME_BITCH[7] = "\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28f7\u28f6\u28f6\u2876\u2887\u28f0\u28ff\u28ff\u28df\u283f\u283f\u283f\u283f\u283f\u283f\u28fe\u28ff\u28ff";
        D\u0106Mv.CRACKME_BITCH[8] = "\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u28ff\u285f\u289b\u285b\u283f\u283f\u28ff\u28e7\u28f6\u28f6\u28ff\u28ff\u28ff\u28ff\u28ff\u28f7\u28fc\u28ff\u28ff\u28ff\u28e7\u2838\u28ff\u28ff";
        D\u0106Mv.CRACKME_BITCH[9] = "\u2818\u28bf\u28ff\u28ff\u28ff\u28ff\u28ff\u2847\u28bf\u287f\u283f\u2826\u28e4\u28c8\u28d9\u285b\u283f\u283f\u283f\u28ff\u28ff\u28ff\u28ff\u283f\u283f\u281f\u281b\u2840\u28bb\u28ff";
        D\u0106Mv.CRACKME_BITCH[10] = "\u2804\u2804\u2809\u283b\u28bf\u28ff\u28ff\u28f7\u28ec\u28d9\u2833\u2836\u28b6\u28e4\u28cd\u28d9\u285b\u2813\u2812\u2836\u2836\u2836\u2836\u2816\u2892\u28db\u28db\u2801\u28fe\u28ff";
        D\u0106Mv.CRACKME_BITCH[11] = "\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2808\u2809\u2809\u28fb\u28ff\u28ff\u28ff\u28ff\u287f\u283f\u281b\u2803\u2804\u2819\u281b\u283f\u28bf\u28ff";
        D\u0106Mv.CRACKME_BITCH[12] = "\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u28ac\u28ed\u28ed\u2876\u2816\u28e2\u28e6\u28c0\u2804\u2804\u2804\u2804\u2880\u28e4\u28fe\u28ff";
        D\u0106Mv.CRACKME_BITCH[13] = "\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2880\u28c0\u28c0\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2804\u2804";
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * WARNING - void declaration
     */
    public void render(MapView mapView, MapCanvas mapCanvas, Player player) {
        void CRACKME_ae26798e_efb6_4ce7_bf9d_6c9e8af9de1bc6bdfb10;
        D\u0106Mv CRACKME_ae26798e_efb6_4ce7_bf9d_6c9e8af9de1b3953111e;
        if (CRACKME_8ff9b460_ef13_4221_a59e_08c0d1d540c5_400020da == 6413431480026918088L - 9054036368317510454L) {
            int cfr_ignored_2 = 0x2A0DDABE ^ 0x2A0DDABF;
        } else {
            int cfr_ignored_3 = 0x553F84CB ^ 0x553F84CB;
        }
        if (CRACKME_ae26798e_efb6_4ce7_bf9d_6c9e8af9de1b3953111e.HNBz) {
            return;
        }
        int cfr_ignored_4 = -793847874 - 418020955;
        long l = CRACKME_8ff9b460_ef13_4221_a59e_08c0d1d540c5_400020da;
        boolean bl = true;
        block10: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x4C7964B92DF60C86L ^ 0x1BBFB23F60A5F1FAL);
            }
            switch ((int)l) {
                case -1896612120: {
                    l2 = 0x1B4B3351FB66A80FL ^ 0xDE0C7F4922C33380L;
                    continue block10;
                }
                case 72489882: {
                    break block10;
                }
                case 1685896536: {
                    l2 = 2407720932964446219L - 5987808518248011477L;
                    continue block10;
                }
                case 1934432231: {
                    l2 = 0x9FA5274AA776765FL ^ 0x6BA90F260C0B64A3L;
                    continue block10;
                }
            }
            break;
        }
        BufferedImage bufferedImage = CRACKME_ae26798e_efb6_4ce7_bf9d_6c9e8af9de1b3953111e.7Tz7;
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = CRACKME_8ff9b460_ef13_4221_a59e_08c0d1d540c5_400020da - (0xD1BACF1014BE3038L ^ 0x3D85E31708B417B4L)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
            if (l4 == (0x1225138A ^ 0x1225138B)) break;
            l4 = 1469497340 - -1906580219;
        }
        CRACKME_ae26798e_efb6_4ce7_bf9d_6c9e8af9de1bc6bdfb10.drawImage(0x1E5216DC ^ 0x1E5216DC, 0x1C73EB48 ^ 0x1C73EB48, (Image)bufferedImage);
        long l5 = CRACKME_8ff9b460_ef13_4221_a59e_08c0d1d540c5_400020da;
        block12: while (true) {
            switch ((int)l5) {
                case -894608804: {
                    l5 = (-4198637369533839512L >>> "\u0000\u0000".length()) / (0xEE9B8771438F0DEL ^ 0xE660A352A2FB597L);
                    continue block12;
                }
                case 72489882: {
                    break block12;
                }
            }
            break;
        }
        CRACKME_ae26798e_efb6_4ce7_bf9d_6c9e8af9de1b3953111e.HNBz = 0xC2F69B4A ^ 0xC2F69B4B;
    }
}
