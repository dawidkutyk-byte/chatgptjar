/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.comphenix.protocol.events.PacketEvent
 *  zNb\u015b
 */
import com.comphenix.protocol.events.PacketEvent;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class Vmei {
    private static String[] CRACKME_BITCH = new String[15];
    private final zNb\u015b HDf\u0104;
    protected static long CRACKME_92ffca44_4dda_4c72_8c68_c22c89a28e32_505c4c48 = -7124464225331273747L;

    /*
     * Handled impossible loop by adding 'first' condition
     * WARNING - void declaration
     */
    public Vmei(zNb\u015b zNb\u015b2) {
        void CRACKME_5ab386c2_6992_436b_bb04_96ed2522948902cdd6f0;
        Vmei CRACKME_5ab386c2_6992_436b_bb04_96ed25229489ca91d9b4;
        if (CRACKME_92ffca44_4dda_4c72_8c68_c22c89a28e32_505c4c48 == -7919817570237579558L - 1772278910349900535L) {
            int n = 0x8A5B65C9 ^ 0x8A5B65C8;
        } else {
            int cfr_ignored_1 = 0xC89046F9 ^ 0xC89046F9;
        }
        int cfr_ignored_2 = -1237519598 - -440896005;
        long l = CRACKME_92ffca44_4dda_4c72_8c68_c22c89a28e32_505c4c48;
        boolean bl = true;
        block4: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (7961847419189022778L - 3208336143826966839L);
            }
            switch ((int)l) {
                case -1171873811: {
                    break block4;
                }
                case 1548417724: {
                    l2 = -652502086051209301L - 49662716538985308L;
                    continue block4;
                }
            }
            break;
        }
        CRACKME_5ab386c2_6992_436b_bb04_96ed25229489ca91d9b4.HDf\u0104 = CRACKME_5ab386c2_6992_436b_bb04_96ed2522948902cdd6f0;
    }

    /*
     * Exception decompiling
     */
    public void J-XUqqF9KYweLCMt(PacketEvent var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Extractable last case doesn't follow previous, and can't clone.
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:611)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.rebuildSwitches(SwitchReplacer.java:406)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:601)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doClass(Driver.java:84)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:78)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompile(CFRDecompiler.java:89)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompileToZip(CFRDecompiler.java:133)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.decompileSaveAll(ResourceDecompiling.java:261)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.lambda$decompileSaveAll$0(ResourceDecompiling.java:111)
         *     at java.base/java.lang.Thread.run(Thread.java:1575)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    static {
        Vmei.CRACKME_BITCH[0] = "\u2282_\u30fd";
        Vmei.CRACKME_BITCH[1] = "\u3000 \uff3c\uff3c\u3000\u3000\u3000";
        Vmei.CRACKME_BITCH[2] = "\u3000\u3000 \uff3c( \u0361\u00b0 \u035c\u0296 \u0361\u00b0)\u3000\u3000\u3000";
        Vmei.CRACKME_BITCH[3] = "\u3000\u3000\u3000 >\u3000\u2312\u30fd\u3000\u3000\u3000";
        Vmei.CRACKME_BITCH[4] = "\u3000\u3000\u3000/ \u3000 \u3078\uff3c\u3000\u3000\u3000";
        Vmei.CRACKME_BITCH[5] = "\u3000\u3000 /\u3000\u3000/\u3000\uff3c\uff3c\u3000\u3000\u3000";
        Vmei.CRACKME_BITCH[6] = "\u3000\u3000 \uff9a\u3000\u30ce\u3000\u3000 \u30fd_\u3064\u3000\u3000\u3000";
        Vmei.CRACKME_BITCH[7] = "\u3000\u3000/\u3000/\u3000\u3000\u3000";
        Vmei.CRACKME_BITCH[8] = "\u3000 /\u3000/|\u3000\u3000\u3000";
        Vmei.CRACKME_BITCH[9] = "\u3000(\u3000(\u30fd\u3000\u3000\u3000";
        Vmei.CRACKME_BITCH[10] = "\u3000|\u3000|\u3001\uff3c\u3000\u3000\u3000";
        Vmei.CRACKME_BITCH[11] = "\u3000| \u4e3f \uff3c \u2312)\u3000\u3000\u3000";
        Vmei.CRACKME_BITCH[12] = "\u3000| |\u3000\u3000) /\u3000\u3000\u3000";
        Vmei.CRACKME_BITCH[13] = "\u30ce )\u3000\u3000L\uff89\u3000\u3000\u3000";
        Vmei.CRACKME_BITCH[14] = "(_\uff0f\u3000\u3000\u3000\u3000\u3000\u3000";
    }
}
