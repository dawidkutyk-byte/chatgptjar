/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  LrGH
 *  com.comphenix.protocol.PacketType
 *  com.comphenix.protocol.PacketType$Play$Server
 *  com.comphenix.protocol.ProtocolLibrary
 *  com.comphenix.protocol.ProtocolManager
 *  com.comphenix.protocol.events.ListenerPriority
 *  com.comphenix.protocol.events.PacketListener
 *  ihx
 *  org.bukkit.plugin.Plugin
 *  zNb\u015b
 */
import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.ListenerPriority;
import com.comphenix.protocol.events.PacketListener;
import java.util.ArrayList;
import org.bukkit.plugin.Plugin;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class \u0141p9p {
    private final zNb\u015b nt5c;
    private final LrGH DC\u0105o;
    private static String[] CRACKME_BITCH = new String[13];
    static long CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95 = -2009304193877019292L;
    private final ProtocolManager ZX\u00f3v;

    /*
     * Unable to fully structure code
     */
    private void yhaHmY4sVmzX4lH2() {
        block140: {
            block133: {
                block139: {
                    block138: {
                        block137: {
                            block136: {
                                if (\u0141p9p.CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95 == -1951736723258123442L - -9091553289809250308L) {
                                    if ((-415932484 ^ 1125401663 ^ 953993710 - -1193489937) != 0) {
                                        -498887278 ^ -498887277;
                                    }
                                } else {
                                    -1797016660 ^ -1797016660;
                                }
                                v0 = \u0141p9p.CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95;
                                if (true) ** GOTO lbl15
                                block91: while (true) {
                                    v0 = v1 / (-6982344074407587333L ^ 5497861514977013722L);
lbl15:
                                    // 2 sources

                                    switch ((int)v0) {
                                        case -432592401: {
                                            v1 = -2126493417501209649L ^ 3153412935784839220L;
                                            continue block91;
                                        }
                                        case 1044510052: {
                                            break block91;
                                        }
                                        case 1602327313: {
                                            v1 = 5793816055705637090L - -6029361978810448588L;
                                            continue block91;
                                        }
                                    }
                                    break;
                                }
                                CRACKME_0fa9eca2_bed0_404e_8d0d_2515c439b1bcff4b073e = new ArrayList<PacketType>();
                                v2 = \u0141p9p.CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95;
                                if (true) ** GOTO lbl36
                                block92: while (true) {
                                    v2 = v3 / (-3349806895939857322L ^ 5144133429914078194L);
lbl36:
                                    // 2 sources

                                    switch ((int)v2) {
                                        case 1044510052: {
                                            break block92;
                                        }
                                        case 1507777087: {
                                            if (4073271641170982510L == 4073271641170982511L) {
                                                v3 = -2713837522338474241L;
                                                continue block92;
                                            }
                                            v3 = 453395878733832610L - 4330151100181929249L;
                                            continue block92;
                                        }
                                        case 1803250974: {
                                            v3 = -5830784240725895737L ^ 4902884107102822332L;
                                            continue block92;
                                        }
                                    }
                                    break;
                                }
                                CRACKME_0fa9eca2_bed0_404e_8d0d_2515c439b1bcff4b073e.add(PacketType.Play.Server.CHAT);
                                while (true) {
                                    if ((v4 = (cfr_temp_0 = \u0141p9p.CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95 - (-1098763417633908086L ^ 1645533556598927161L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                                    if (v4 == (-76129840 ^ 76129839)) break;
                                    v4 = 531632555 ^ 964106683;
                                }
                                while (true) {
                                    block134: {
                                        if ((v5 = (cfr_temp_1 = \u0141p9p.CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95 - (-8696816973753509975L == -8696816973753509974L ? 3455047325171435581L : -1284051541118438524L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                                        if (v5 != (-1014011049 ^ 1014011048)) break block134;
                                        CRACKME_0fa9eca2_bed0_404e_8d0d_2515c439b1bcff4b073e.add(PacketType.Play.Server.SCOREBOARD_OBJECTIVE);
                                        v6 = \u0141p9p.CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95;
                                        if (true) ** GOTO lbl70
                                    }
                                    v5 = -1115323848 ^ 869610700;
                                }
                                block95: while (true) {
                                    v6 = v7 / (-1288386839401317968L == -1288386839401317967L ? -1049329030409096621L : -5316161699596975589L ^ 1511932169229720154L);
lbl70:
                                    // 2 sources

                                    switch ((int)v6) {
                                        case 298074316: {
                                            if (-1520477755301918675L == -1520477755301918674L) {
                                                v7 = -1678516563637661502L;
                                                continue block95;
                                            }
                                            v7 = 9088918238635236533L ^ -2343429414264572042L;
                                            continue block95;
                                        }
                                        case 1044510052: {
                                            break block95;
                                        }
                                    }
                                    break;
                                }
                                v8 = \u0141p9p.CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95;
                                if (true) ** GOTO lbl85
                                block96: while (true) {
                                    v8 = v9 / (1976521892230715532L ^ -6617363851418195603L);
lbl85:
                                    // 2 sources

                                    switch ((int)v8) {
                                        case -533171677: {
                                            v9 = -2593248778354966298L ^ -7657661326106262834L;
                                            continue block96;
                                        }
                                        case 784862126: {
                                            v9 = -739131139635942641L ^ 5375905351848558672L;
                                            continue block96;
                                        }
                                        case 1044510052: {
                                            break block96;
                                        }
                                    }
                                    break;
                                }
                                CRACKME_0fa9eca2_bed0_404e_8d0d_2515c439b1bcff4b073e.add(PacketType.Play.Server.SCOREBOARD_TEAM);
                                1407317091 ^ 1512064357;
                                v10 = \u0141p9p.CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95;
                                if (true) ** GOTO lbl109
                                block97: while (true) {
                                    v10 = v11 / (-5855466371056148947L ^ -1287508859661017990L);
lbl109:
                                    // 2 sources

                                    switch ((int)v10) {
                                        case -1181769491: {
                                            v11 = 4131449530215134318L ^ 712602538745626788L;
                                            continue block97;
                                        }
                                        case 858355821: {
                                            if (6227210768234517229L == 6227210768234517230L) {
                                                v11 = 4663075195657114464L;
                                                continue block97;
                                            }
                                            v11 = 5460589174242860253L ^ -6045509378581291731L;
                                            continue block97;
                                        }
                                        case 1044510052: {
                                            break block97;
                                        }
                                        case 1187266027: {
                                            if (-8991857955855614388L == -8991857955855614387L) {
                                                v11 = 2691657859629692522L;
                                                continue block97;
                                            }
                                            v11 = -3294532479951148032L - 8742831568367341464L;
                                            continue block97;
                                        }
                                    }
                                    break;
                                }
                                CRACKME_0fa9eca2_bed0_404e_8d0d_2515c439b1bcff4b073e.add(PacketType.Play.Server.ENTITY_METADATA);
                                while (true) {
                                    if ((v12 = (cfr_temp_2 = \u0141p9p.CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95 - (-9028024774618281766L ^ 5430823494074901414L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                                    if (v12 == (-3801611555673583442L == -3801611555673583441L ? 806191524 : -1779484479 ^ -1779484480)) break;
                                    v12 = 1867680704 >>> "\u0000\u0000".length();
                                }
                                CRACKME_0fa9eca2_bed0_404e_8d0d_2515c439b1bcff4b073e.add(PacketType.Play.Server.BOSS);
                                while (true) {
                                    block135: {
                                        if ((v13 = (cfr_temp_3 = \u0141p9p.CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95 - (559897683330304012L - -1568767018128452118L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                                        if (v13 != 1700205457 - 1700205458) break block135;
                                        v14 = CRACKME_0fa9eca2_bed0_404e_8d0d_2515c439b1bc462a7c2d.DC\u0105o;
                                        v15 = \u0141p9p.CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95;
                                        if (true) ** GOTO lbl153
                                    }
                                    v13 = 1914377438 ^ -156661516;
                                }
                                block100: while (true) {
                                    v15 = v16 / (-5140739653911052433L - 8035179763107930092L);
lbl153:
                                    // 2 sources

                                    switch ((int)v15) {
                                        case 20062970: {
                                            v16 = 811092705079722505L ^ -5641276062485280143L;
                                            continue block100;
                                        }
                                        case 1044510052: {
                                            break block100;
                                        }
                                        case 1263154849: {
                                            if (-7873644048734139748L == -7873644048734139747L) {
                                                v16 = -2965178296212095359L;
                                                continue block100;
                                            }
                                            v16 = 688729664246738348L - -4511872901124060313L;
                                            continue block100;
                                        }
                                    }
                                    break;
                                }
                                var2_2 = v14.9pkINEus8kmPOgKl();
                                var4_3 = new byte[-73814002 ^ -73814006];
                                var4_3[2031956221 ^ 2031956223] = -1454972257 ^ -1454972242;
                                var4_3[791264482 ^ 791264483] = -1490086642 ^ -1490086624;
                                var4_3[2140164154 ^ 2140164154] = 429181184 ^ 429181233;
                                var4_3[500948084 ^ 500948087] = 906383953 ^ 906383974;
                                if (CRACKME_0fa9eca2_bed0_404e_8d0d_2515c439b1bca8615457.startsWith(new String(var4_3, "UTF-8"))) break block136;
                                var4_3 = new byte[1402049653 ^ 1402049649];
                                var4_3[837446031 ^ 837446031] = -1344002282 ^ -1344002265;
                                var4_3[-31682948 ^ -31682946] = -207369821 ^ -207369838;
                                var4_3[-5631727884811757595L == -5631727884811757594L ? -1774906787 : 1405303439 ^ 1405303436] = 2387954979040089505L == 2387954979040089506L ? 1738048574 : -472368584 ^ -472368640;
                                var4_3[-113707430 ^ -113707429] = -3833228350973304385L == -3833228350973304384L ? -488807326 : -2034758324 ^ -2034758302;
                                v17 = new String(var4_3, "UTF-8");
                                v18 = \u0141p9p.CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95;
                                if (true) ** GOTO lbl199
                                block101: while (true) {
                                    v18 = v19 / (-3090583929819791744L >>> "\u0000\u0000".length());
lbl199:
                                    // 2 sources

                                    switch ((int)v18) {
                                        case -1142585919: {
                                            if (8436777024994655010L == 8436777024994655011L) {
                                                v19 = 6039661785428008764L;
                                                continue block101;
                                            }
                                            v19 = -7452208660286063376L ^ 3269603563942946531L;
                                            continue block101;
                                        }
                                        case 447174960: {
                                            v19 = -6242520049102021148L ^ -3682600328627315080L;
                                            continue block101;
                                        }
                                        case 939575645: {
                                            if (-7668234485964510980L == -7668234485964510979L) {
                                                v19 = -459529971268750541L;
                                                continue block101;
                                            }
                                            v19 = 5912032983472746771L ^ -1437630659786894370L;
                                            continue block101;
                                        }
                                        case 1044510052: {
                                            break block101;
                                        }
                                    }
                                    break;
                                }
                                if (CRACKME_0fa9eca2_bed0_404e_8d0d_2515c439b1bca8615457.startsWith(v17)) break block136;
                                var4_3 = new byte[-9146767415116369725L == -9146767415116369724L ? -963997055 : -1796255806 ^ -1796255802];
                                var4_3[-381879239581146506L == -381879239581146505L ? 134709793 : -539563569 ^ -539563572] = 6714807974970059311L == 6714807974970059312L ? -1435610972 : -52132224 ^ -52132167;
                                var4_3[1104436057 ^ 1104436059] = 404813561 ^ 404813512;
                                var4_3[301174729 ^ 301174729] = 4452078920679711205L == 4452078920679711206L ? -1865297064 : 1501906231 ^ 1501906182;
                                var4_3[-547070285 ^ -547070286] = -171825028 ^ -171825070;
                                -1182742804 ^ 1402607324;
                                if (CRACKME_0fa9eca2_bed0_404e_8d0d_2515c439b1bca8615457.startsWith(new String(var4_3, "UTF-8"))) break block136;
                                var4_3 = new byte[-1494507267 ^ -1494507271];
                                var4_3[-139543175 ^ -139543176] = 1505363901 ^ 1505363859;
                                var4_3[1485675711 ^ 1485675708] = -997235631 ^ -997235615;
                                var4_3[-3072389934316684624L == -3072389934316684623L ? 1115500053 : 1196063398 ^ 0x474A7AA4] = 193223002 ^ 193223016;
                                var4_3[-1647340914 ^ -1647340914] = -294443850 ^ -294443897;
                                if (CRACKME_0fa9eca2_bed0_404e_8d0d_2515c439b1bca8615457.startsWith(new String(var4_3, "UTF-8"))) break block136;
                                var4_3 = new byte[182101267 ^ 182101271];
                                var4_3[1247397982 ^ 1247397981] = -594517873 ^ -594517826;
                                var4_3[2642897790597729835L == 2642897790597729836L ? 1873400228 : -2052070405 ^ -2052070405] = 8721425 ^ 8721440;
                                var4_3[-2980682808749843825L == -2980682808749843824L ? 1095399913 : -1882170238 ^ -1882170237] = 3562617575713982981L == 3562617575713982982L ? 1609426504 : -828060233 ^ -828060263;
                                v20 = var4_3[-626387080 ^ -626387078] = 3793750539346390278L == 3793750539346390279L ? -834362857 : 1510546273 ^ 1510546259;
                                if (!CRACKME_0fa9eca2_bed0_404e_8d0d_2515c439b1bca8615457.startsWith(new String(var4_3, "UTF-8"))) break block137;
                            }
                            v21 = \u0141p9p.CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95;
                            if (true) ** GOTO lbl258
                            block102: while (true) {
                                v21 = v22 / (-973012254112237982L == -973012254112237981L ? 7075498182020920639L : -8209354054462033019L - 5791662156066733121L);
lbl258:
                                // 2 sources

                                switch ((int)v21) {
                                    case 1044510052: {
                                        break block102;
                                    }
                                    case 1131575253: {
                                        v22 = 1036225627723510516L >>> "\u0000\u0000".length();
                                        continue block102;
                                    }
                                    case 2061100359: {
                                        v22 = -695189721703482286L ^ 7254876091824301035L;
                                        continue block102;
                                    }
                                    case 2070735720: {
                                        if (-8420652792972869429L == -8420652792972869428L) {
                                            v22 = 4213028261588010358L;
                                            continue block102;
                                        }
                                        v22 = -792183282470993056L ^ -8434818051060784163L;
                                        continue block102;
                                    }
                                }
                                break;
                            }
                            CRACKME_0fa9eca2_bed0_404e_8d0d_2515c439b1bcff4b073e.add(PacketType.Play.Server.SET_TITLE_TEXT);
                            v23 = \u0141p9p.CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95;
                            if (true) ** GOTO lbl288
                            block103: while (true) {
                                v23 = v24 / (-8672826977885832863L - 6399312081604444140L);
lbl288:
                                // 2 sources

                                switch ((int)v23) {
                                    case -1281585005: {
                                        v24 = 6708227395817034348L >>> "\u0000\u0000".length();
                                        continue block103;
                                    }
                                    case 377258450: {
                                        if (-3391731790304661427L == -3391731790304661426L) {
                                            v24 = -4439488285336349299L;
                                            continue block103;
                                        }
                                        v24 = 3592967739536586428L ^ 4112781653636114769L;
                                        continue block103;
                                    }
                                    case 1004359359: {
                                        if (-5363974639795159724L == -5363974639795159723L) {
                                            v24 = 7701365178386447234L;
                                            continue block103;
                                        }
                                        v24 = 8286684319084951089L ^ -5250445243267855773L;
                                        continue block103;
                                    }
                                    case 1044510052: {
                                        break block103;
                                    }
                                }
                                break;
                            }
                            v25 = \u0141p9p.CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95;
                            if (true) ** GOTO lbl312
                            block104: while (true) {
                                v25 = v26 / (8618483570364599296L >>> "\u0000\u0000".length());
lbl312:
                                // 2 sources

                                switch ((int)v25) {
                                    case -1632301294: {
                                        if (7201175274155967750L == 7201175274155967751L) {
                                            v26 = 4773047185791893383L;
                                            continue block104;
                                        }
                                        v26 = 3620036930852934568L - -7781403353204829950L;
                                        continue block104;
                                    }
                                    case -1152160837: {
                                        v26 = -7109737684840405052L - -3337600337864061047L;
                                        continue block104;
                                    }
                                    case 1044510052: {
                                        break block104;
                                    }
                                }
                                break;
                            }
                            CRACKME_0fa9eca2_bed0_404e_8d0d_2515c439b1bcff4b073e.add(PacketType.Play.Server.SET_SUBTITLE_TEXT);
                            862890959 - 1734100484;
                            1427349332 ^ -1349359898;
                            v27 = \u0141p9p.CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95;
                            if (true) ** GOTO lbl348
                            block105: while (true) {
                                v27 = v28 / (-7596875625049604183L ^ 4697058242031993705L);
lbl348:
                                // 2 sources

                                switch ((int)v27) {
                                    case -2115827806: {
                                        v28 = 2495610936325134425L ^ 5275225812137373016L;
                                        continue block105;
                                    }
                                    case -126823452: {
                                        v28 = -4005106699511623985L ^ 2686661602202945104L;
                                        continue block105;
                                    }
                                    case 1044510052: {
                                        break block105;
                                    }
                                }
                                break;
                            }
                            v29 = \u0141p9p.CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95;
                            if (true) ** GOTO lbl362
                            block106: while (true) {
                                v29 = v30 / (-7824050207511635201L == -7824050207511635200L ? 1074930581065477421L : -6161191196346622269L ^ 831330446292605691L);
lbl362:
                                // 2 sources

                                switch ((int)v29) {
                                    case -1514132708: {
                                        if (-2073215548487612201L == -2073215548487612200L) {
                                            v30 = -6183188616401435971L;
                                            continue block106;
                                        }
                                        v30 = 8529505242511134808L >>> "\u0000\u0000".length();
                                        continue block106;
                                    }
                                    case -1228628687: {
                                        v30 = -4534431929529366697L - -8553214165222899766L;
                                        continue block106;
                                    }
                                    case -437787480: {
                                        v30 = -4683923882354999784L ^ 7795642245266113197L;
                                        continue block106;
                                    }
                                    case 1044510052: {
                                        break block106;
                                    }
                                }
                                break;
                            }
                            CRACKME_0fa9eca2_bed0_404e_8d0d_2515c439b1bcff4b073e.add(PacketType.Play.Server.SET_ACTION_BAR_TEXT);
                        }
                        -1708590360 >>> "\u0000\u0000".length();
                        v31 = 8530746387308259180L == 8530746387308259181L ? -1590780198 : 414783381 ^ 1672996204;
                        var4_3 = new byte[7707809659192735847L == 7707809659192735848L ? 1084115711 : 2143166564 ^ 2143166560];
                        var4_3[-123520466765921176L == -123520466765921175L ? 1413693761 : 326516015 ^ 326516013] = 7308600048981974896L == 7308600048981974897L ? 350736283 : 220210408 ^ 220210393;
                        var4_3[-1904165549 ^ -1904165550] = 1787930198 ^ 1787930232;
                        var4_3[2116476664 ^ 2116476667] = 1224810309 ^ 1224810364;
                        var4_3[1582413896 ^ 1582413896] = 3261231757386448326L == 3261231757386448327L ? -490127094 : 388619453 ^ 388619404;
                        v32 = new String(var4_3, "UTF-8");
                        v33 = \u0141p9p.CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95;
                        if (true) ** GOTO lbl399
                        block107: while (true) {
                            v33 = v34 / (8184358172607804713L ^ 1759346377032241241L);
lbl399:
                            // 2 sources

                            switch ((int)v33) {
                                case -1685579447: {
                                    v34 = 8488828324010542143L ^ -3715061935933980106L;
                                    continue block107;
                                }
                                case -1666165124: {
                                    v34 = -2406157664248937146L ^ -5060151553873365341L;
                                    continue block107;
                                }
                                case 1044510052: {
                                    break block107;
                                }
                            }
                            break;
                        }
                        if (CRACKME_0fa9eca2_bed0_404e_8d0d_2515c439b1bca8615457.startsWith(v32)) break block138;
                        var4_3 = new byte[2557472364055613932L == 2557472364055613933L ? 1634398235 : 1298942663 ^ 1298942659];
                        var4_3[-6709334677582006550L == -6709334677582006549L ? -231549730 : 556658173 ^ 556658175] = 1821344937 ^ 1821344923;
                        var4_3[4258484418270163868L == 4258484418270163869L ? -215555776 : -1437800159 ^ -1437800158] = 87029952 ^ 87030000;
                        var4_3[8945246118505114098L == 8945246118505114099L ? -2060572148 : -615316726 ^ -615316725] = -1597684778695840826L == -1597684778695840825L ? 680445426 : 1852074046 ^ 1852074000;
                        var4_3[982229539 ^ 982229539] = -554010172 ^ -554010123;
                        v35 = new String(var4_3, "UTF-8");
                        v36 = \u0141p9p.CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95;
                        if (true) ** GOTO lbl424
                        block108: while (true) {
                            v36 = v37 / (6764858038928568782L ^ -7093099969396251733L);
lbl424:
                            // 2 sources

                            switch ((int)v36) {
                                case -1568721120: {
                                    v37 = -8115291477979820272L ^ 4879507937609880321L;
                                    continue block108;
                                }
                                case -437744928: {
                                    v37 = 8068714479848734248L - -6308766495701974625L;
                                    continue block108;
                                }
                                case 550726057: {
                                    v37 = -6646877991065399390L ^ -762910529883901006L;
                                    continue block108;
                                }
                                case 1044510052: {
                                    break block108;
                                }
                            }
                            break;
                        }
                        if (CRACKME_0fa9eca2_bed0_404e_8d0d_2515c439b1bca8615457.startsWith(v35)) break block138;
                        var4_3 = new byte[-1750787735 ^ -1750787731];
                        var4_3[5582482061108729014L == 5582482061108729015L ? -1129755246 : -58783036 ^ -58783033] = 8811777704418183830L == 8811777704418183831L ? -456800204 : 1180328609 ^ 1180328592;
                        var4_3[1027235094 ^ 1027235095] = -1961588944 ^ -1961588962;
                        var4_3[-1615063115 ^ -1615063115] = -1529057973 ^ -1529057926;
                        v38 = var4_3[-4555871104940180689L == -4555871104940180688L ? -39987718 : 1245779111 ^ 1245779109] = 1669228346830414913L == 1669228346830414914L ? 315332984 : 1361066438 ^ 1361066484;
                        if (!CRACKME_0fa9eca2_bed0_404e_8d0d_2515c439b1bca8615457.startsWith(new String(var4_3, "UTF-8"))) break block139;
                    }
                    969836816 - 108378435;
                    v39 = \u0141p9p.CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95;
                    if (true) ** GOTO lbl456
                    block109: while (true) {
                        v39 = v40 / (-8059552525641423808L == -8059552525641423807L ? 4563667428891876988L : 1770294165779628051L - -5336225143959098017L);
lbl456:
                        // 2 sources

                        switch ((int)v39) {
                            case -1537675216: {
                                v40 = 3587662387027346988L - 838983003456707407L;
                                continue block109;
                            }
                            case -1359448867: {
                                v40 = 4945096110732548505L - -1592888293890719036L;
                                continue block109;
                            }
                            case 1044510052: {
                                break block109;
                            }
                        }
                        break;
                    }
                    while (true) {
                        if ((v41 = (cfr_temp_4 = \u0141p9p.CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95 - (5702999946021796122L - -2975119627664358915L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                        if (v41 == (7957447091783016079L == 7957447091783016080L ? 679160617 : -809873781 ^ 809873780)) {
                            CRACKME_0fa9eca2_bed0_404e_8d0d_2515c439b1bcff4b073e.add(PacketType.Play.Server.SYSTEM_CHAT);
                            break;
                        }
                        v41 = 100255330 ^ 1567270836;
                    }
                }
                while (true) {
                    if ((v42 = (cfr_temp_5 = \u0141p9p.CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95 - (1245972985254526436L == 1245972985254526437L ? 5641151398832721190L : 6940290154236960645L ^ -8330642702578747336L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                    if (v42 == (-2125379687 ^ 2125379686)) break;
                    v42 = -1243543391 ^ -1521518796;
                }
                v43 = CRACKME_0fa9eca2_bed0_404e_8d0d_2515c439b1bc462a7c2d.ZX\u00f3v;
                1318278449 ^ -2064974703;
                while (true) {
                    if ((v44 = (cfr_temp_6 = \u0141p9p.CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95 - (1154946330365950720L ^ 4252012143338285587L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                    if (v44 == (203809111 ^ -203809112)) {
                        v45 = CRACKME_0fa9eca2_bed0_404e_8d0d_2515c439b1bc462a7c2d.nt5c;
                        if (4392316645712000635L == 4392316645712000636L) {
                            break;
                        }
                        break block133;
                    }
                    v44 = 1184098295 ^ -298844466;
                }
                v46 = -19032969;
                break block140;
            }
            v46 = 1789415481 ^ 1789415481;
        }
        v47 = \u0141p9p.CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95;
        if (true) ** GOTO lbl520
        block113: while (true) {
            v47 = v48 / (4245732790326407521L ^ -3084128008732822979L);
lbl520:
            // 2 sources

            switch ((int)v47) {
                case -188299615: {
                    v48 = -7295646712950045449L ^ -2913792118158099161L;
                    continue block113;
                }
                case 159460171: {
                    v48 = -6219063196390224402L ^ 4046881856101289747L;
                    continue block113;
                }
                case 1044510052: {
                    break block113;
                }
            }
            break;
        }
        v49 = new ihx(CRACKME_0fa9eca2_bed0_404e_8d0d_2515c439b1bc462a7c2d, (Plugin)v45, ListenerPriority.HIGHEST, CRACKME_0fa9eca2_bed0_404e_8d0d_2515c439b1bcff4b073e.toArray(new PacketType[v46]));
        -286661033 ^ 1984709713;
        v50 = \u0141p9p.CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95;
        if (true) ** GOTO lbl542
        block114: while (true) {
            v50 = v51 / (1100320125793563142L == 1100320125793563143L ? -330187654109452310L : 4401226040370567506L - 6368114334134096982L);
lbl542:
            // 2 sources

            switch ((int)v50) {
                case -75860369: {
                    v51 = 3429229532535403769L ^ -4873400009916756245L;
                    continue block114;
                }
                case 1044510052: {
                    break block114;
                }
                case 1328882735: {
                    v51 = 4721186658605441025L - -7810651852742315493L;
                    continue block114;
                }
                case 1687791614: {
                    v51 = -8501297132718240271L ^ -3798353677984856426L;
                    continue block114;
                }
            }
            break;
        }
        v43.addPacketListener((PacketListener)v49);
    }

    static {
        \u0141p9p.CRACKME_BITCH[0] = "\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800    ";
        \u0141p9p.CRACKME_BITCH[1] = "\u2800\u2800\u2800\u2800\u28e0\u28f6\u287e\u280f\u2809\u2819\u2833\u28a6\u2840\u2800\u2800\u2800\u28a0\u281e\u2809\u2819\u2832\u2840\u2800    ";
        \u0141p9p.CRACKME_BITCH[2] = "\u2800\u2800\u2800\u28f4\u283f\u280f\u2800\u2800\u2800\u2800\u2800\u2800\u28b3\u2840\u2800\u284f\u2800\u2800\u2800\u2800\u2800\u28b7     ";
        \u0141p9p.CRACKME_BITCH[3] = "\u2800\u2800\u28a0\u28df\u28cb\u2840\u2880\u28c0\u28c0\u2840\u2800\u28c0\u2840\u28e7\u2800\u28b8\u2800\u2800\u2800\u2800\u2800 \u2847    ";
        \u0141p9p.CRACKME_BITCH[4] = "\u2800\u2800\u28b8\u28ef\u286d\u2801\u2838\u28db\u28df\u2806\u2874\u28fb\u2872\u28ff\u2800\u28f8\u2800\u2800OK\u2800 \u2847    ";
        \u0141p9p.CRACKME_BITCH[5] = "\u2800\u2800\u28df\u28ff\u286d\u2800\u2800\u2800\u2800\u2800\u28b1\u2800\u2800\u28ff\u2800\u28b9\u2800\u2800\u2800\u2800\u2800 \u2847    ";
        \u0141p9p.CRACKME_BITCH[6] = "\u2800\u2800\u2819\u28bf\u28ef\u2804\u2800\u2800\u2800\u2880\u2840\u2800\u2800\u287f\u2800\u2800\u2847\u2800\u2800\u2800\u2800\u287c     ";
        \u0141p9p.CRACKME_BITCH[7] = "\u2800\u2800\u2800\u2800\u2839\u28f6\u2806\u2800\u2800\u2800\u2800\u2800\u2874\u2803\u2800\u2800\u2818\u2824\u28c4\u28e0\u281e\u2800     ";
        \u0141p9p.CRACKME_BITCH[8] = "\u2800\u2800\u2800\u2800\u2800\u28b8\u28f7\u2866\u28a4\u2864\u28a4\u28de\u28c1\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800    ";
        \u0141p9p.CRACKME_BITCH[9] = "\u2800\u2800\u2880\u28e4\u28f4\u28ff\u28cf\u2801\u2800\u2800\u2838\u28cf\u28af\u28f7\u28d6\u28e6\u2840\u2800\u2800\u2800\u2800\u2800\u2800    ";
        \u0141p9p.CRACKME_BITCH[10] = "\u2880\u28fe\u28fd\u28ff\u28ff\u28ff\u28ff\u281b\u28b2\u28f6\u28fe\u2889\u2877\u28ff\u28ff\u2835\u28ff\u2800\u2800\u2800\u2800\u2800\u2800    ";
        \u0141p9p.CRACKME_BITCH[11] = "\u28fc\u28ff\u280d\u2809\u28ff\u286d\u2809\u2819\u28ba\u28c7\u28fc\u284f\u2800\u2800\u2800\u28c4\u28b8\u2800\u2800\u2800\u2800\u2800\u2800    ";
        \u0141p9p.CRACKME_BITCH[12] = "\u28ff\u28ff\u28e7\u28c0\u28ff.........\u28c0\u28f0\u28cf\u28d8\u28c6\u28c0\u2800\u2800       ";
    }

    /*
     * WARNING - void declaration
     */
    public \u0141p9p(zNb\u015b zNb\u015b2) {
        void CRACKME_8c3dae63_d882_4d54_878d_f8687f479ad036588e05;
        \u0141p9p CRACKME_8c3dae63_d882_4d54_878d_f8687f479ad0f97d4eb9;
        if (CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95 == -1040686118187386324L - -2636687970029611938L) {
            if ((0x60FFABD5 ^ 0x2EE976DB ^ (0xD7C2284B ^ 0xA83DD7B4)) != 0) {
                int cfr_ignored_1 = 0x15487625 ^ 0x15487624;
            }
        } else {
            int n = -5843450213518800096L == -5843450213518800095L ? 662732637 : 0x47C1EBEA ^ 0x47C1EBEA;
        }
        CRACKME_8c3dae63_d882_4d54_878d_f8687f479ad0f97d4eb9.nt5c = CRACKME_8c3dae63_d882_4d54_878d_f8687f479ad036588e05;
        ProtocolManager protocolManager = ProtocolLibrary.getProtocolManager();
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95 - (-2574974536245767086L == -2574974536245767085L ? -9091472578901610068L : 0xC32C97E022ED6EFAL ^ 0xC4EF3B3F93448954L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == -938303314 - -938303313) break;
            l2 = 0x8C86BC1 ^ 0xC936B82F;
        }
        CRACKME_8c3dae63_d882_4d54_878d_f8687f479ad0f97d4eb9.ZX\u00f3v = protocolManager;
        int cfr_ignored_2 = 0xA4E5DEEC ^ 0x20E11684;
        long l = CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95;
        block9: while (true) {
            switch ((int)l) {
                case -1074558624: {
                    l = (0x3C946A9F2823DF3BL ^ 0xCAD3C693B1CD1E6BL) / (-1296014749143598708L - -5805486629993521162L);
                    continue block9;
                }
                case 1044510052: {
                    break block9;
                }
            }
            break;
        }
        LrGH lrGH = new LrGH();
        long l3 = CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95;
        block10: while (true) {
            switch ((int)l3) {
                case -1097329321: {
                    l3 = (2290080683152176190L - -8875898334263938486L) / (0x5B06860C36DDC689L ^ 0xA0FB272F4A57B556L);
                    continue block10;
                }
                case 1044510052: {
                    break block10;
                }
            }
            break;
        }
        CRACKME_8c3dae63_d882_4d54_878d_f8687f479ad0f97d4eb9.DC\u0105o = lrGH;
        int cfr_ignored_3 = 1427724576 - -78047000;
        CRACKME_8c3dae63_d882_4d54_878d_f8687f479ad0f97d4eb9.yhaHmY4sVmzX4lH2();
    }

    static /* synthetic */ zNb\u015b 4eUldfF_cjvUJ51H(\u0141p9p \u0142p9p) {
        if (CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95 == (0x29E0FC76EC6EA997L ^ 0xFC1EA9C529D1FDB9L)) {
            if (((-5745517133283971442L == -5745517133283971441L ? -1648489771 : -1031746160 >>> "\u0000\u0000".length()) ^ (0x6E124074 ^ 0x11EDBF8B)) != 0) {
                int n = 9145097523360141483L == 9145097523360141484L ? 1491731398 : 0x8E9E4691 ^ 0x8E9E4690;
            }
        } else {
            int n = 6406689191747140297L == 6406689191747140298L ? -1628314934 : 0x6791393F ^ 0x6791393F;
        }
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95 - (1392675297285985074L == 1392675297285985075L ? -3925638449458549472L : 0xDF3A1E7C3B0CEBFBL ^ 0x3DF052230046EC96L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0xD413E887 ^ 0xD413E886)) {
                \u0141p9p CRACKME_03a9a6e0_1e82_4f5a_979f_860c6f7de55c894ea34f;
                return CRACKME_03a9a6e0_1e82_4f5a_979f_860c6f7de55c894ea34f.nt5c;
            }
            l2 = 12373380 >>> "\u0000\u0000".length();
        }
    }

    static /* synthetic */ LrGH o4kGqrg53Vv-dNVK(\u0141p9p \u0142p9p) {
        \u0141p9p CRACKME_875ff3fd_12db_40bd_af5c_0824f0373826619e9ffc;
        if (CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95 == (8616439725956527887L == 8616439725956527888L ? -3439525475477534112L : -4344999093738670326L - -6864778020258490584L)) {
            if ((0x1D3379F9 ^ 0xA4496ECA ^ (0x3A4C486C ^ 0x45B3B793)) != 0) {
                int cfr_ignored_0 = 0x5B8B4B94 ^ 0x5B8B4B95;
            }
        } else {
            int cfr_ignored_1 = 0x4488E6FD ^ 0x4488E6FD;
        }
        long l = CRACKME_08eadca7_29d6_438d_86e3_fa728e5f64ea_89081f95;
        block4: while (true) {
            switch ((int)l) {
                case -18635775: {
                    l = (0xDB259175CDF0BDDBL ^ 0xCDF1DFFDC290DD5BL) / (0x3BDA12196164C608L ^ 0x599F01F397C223F3L);
                    continue block4;
                }
                case 1044510052: {
                    break block4;
                }
            }
            break;
        }
        return CRACKME_875ff3fd_12db_40bd_af5c_0824f0373826619e9ffc.DC\u0105o;
    }
}
